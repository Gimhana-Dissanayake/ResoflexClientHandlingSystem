﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ResoflexClientHandlingSystem.ScheduleForms.ScheduleReports
{
    public partial class ScheduleReportForm : MetroFramework.Forms.MetroForm
    {
        public ScheduleReportForm()
        {
            InitializeComponent();
        }
    }
}
