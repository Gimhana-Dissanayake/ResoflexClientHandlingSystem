﻿namespace ResoflexClientHandlingSystem.ScheduleForms.Reports
{
}

namespace ResoflexClientHandlingSystem.ScheduleForms.Reports
{


    public partial class ScheduleDataset
    {
    }
}
namespace ResoflexClientHandlingSystem.ScheduleForms.Reports {
    
    
    public partial class ScheduleDataset {
    }
}
