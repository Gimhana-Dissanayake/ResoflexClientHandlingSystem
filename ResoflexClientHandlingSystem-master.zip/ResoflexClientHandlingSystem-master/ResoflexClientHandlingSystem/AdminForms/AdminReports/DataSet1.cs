﻿namespace ResoflexClientHandlingSystem.AdminForms.AdminReports
{


    partial class DataSet1
    {
        partial class UserDSetDataTable
        {
        }
    }
}
