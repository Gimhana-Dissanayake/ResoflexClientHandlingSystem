﻿namespace ResoflexClientHandlingSystem
{
    partial class EvaluateEmployeeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EvaluateEmployeeForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            this.metroTabControl1 = new MetroFramework.Controls.MetroTabControl();
            this.metroTabPage1 = new MetroFramework.Controls.MetroTabPage();
            this.metroTabControl2 = new MetroFramework.Controls.MetroTabControl();
            this.metroTabPage5 = new MetroFramework.Controls.MetroTabPage();
            this.metroButton10 = new MetroFramework.Controls.MetroButton();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.eventTxtbox = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.deadlineDateTime = new MetroFramework.Controls.MetroDateTime();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.searchProjectTxtBox = new MetroFramework.Controls.MetroTextBox();
            this.startEventDateTime = new MetroFramework.Controls.MetroDateTime();
            this.projectDataGrid = new MetroFramework.Controls.MetroGrid();
            this.metroTabPage6 = new MetroFramework.Controls.MetroTabPage();
            this.searchProjectTxtBox1 = new MetroFramework.Controls.MetroTextBox();
            this.EventId = new MetroFramework.Controls.MetroLabel();
            this.gradeETaskLbl = new MetroFramework.Controls.MetroLabel();
            this.gradeDTaskLbl = new MetroFramework.Controls.MetroLabel();
            this.gradeCTaskLbl = new MetroFramework.Controls.MetroLabel();
            this.gradeBTaskLbl = new MetroFramework.Controls.MetroLabel();
            this.gradeATaskLbl = new MetroFramework.Controls.MetroLabel();
            this.metroLink6 = new MetroFramework.Controls.MetroLink();
            this.metroLink7 = new MetroFramework.Controls.MetroLink();
            this.metroLink8 = new MetroFramework.Controls.MetroLink();
            this.metroLink9 = new MetroFramework.Controls.MetroLink();
            this.metroLink10 = new MetroFramework.Controls.MetroLink();
            this.metroLabel53 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel54 = new MetroFramework.Controls.MetroLabel();
            this.eventTxtbox1 = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel20 = new MetroFramework.Controls.MetroLabel();
            this.tasksDataGrid = new MetroFramework.Controls.MetroGrid();
            this.metroTabPage7 = new MetroFramework.Controls.MetroTabPage();
            this.metroTile21 = new MetroFramework.Controls.MetroTile();
            this.EventIdTxtbox = new MetroFramework.Controls.MetroTextBox();
            this.projectIdTxtbox = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel16 = new MetroFramework.Controls.MetroLabel();
            this.descriptionTxtbox = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel15 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel14 = new MetroFramework.Controls.MetroLabel();
            this.metroTile20 = new MetroFramework.Controls.MetroTile();
            this.metroTile19 = new MetroFramework.Controls.MetroTile();
            this.metroTile18 = new MetroFramework.Controls.MetroTile();
            this.projectShortcomingsGrid = new MetroFramework.Controls.MetroGrid();
            this.metroTabPage2 = new MetroFramework.Controls.MetroTabPage();
            this.metroTabControl3 = new MetroFramework.Controls.MetroTabControl();
            this.metroTabPage8 = new MetroFramework.Controls.MetroTabPage();
            this.metroButton9 = new MetroFramework.Controls.MetroButton();
            this.metroLabel32 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel30 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel29 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel28 = new MetroFramework.Controls.MetroLabel();
            this.metroTile10 = new MetroFramework.Controls.MetroTile();
            this.metroTile4 = new MetroFramework.Controls.MetroTile();
            this.circularProgressBar2 = new CircularProgressBar.CircularProgressBar();
            this.metroLabel27 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel25 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel26 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel24 = new MetroFramework.Controls.MetroLabel();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.metroComboBox2 = new MetroFramework.Controls.MetroComboBox();
            this.metroComboBox1 = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel21 = new MetroFramework.Controls.MetroLabel();
            this.circularProgressBar1 = new CircularProgressBar.CircularProgressBar();
            this.chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.metroTabPage9 = new MetroFramework.Controls.MetroTabPage();
            this.metroButton8 = new MetroFramework.Controls.MetroButton();
            this.metroLabel50 = new MetroFramework.Controls.MetroLabel();
            this.metroButton2 = new MetroFramework.Controls.MetroButton();
            this.metroLabel38 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel34 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel35 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel36 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel37 = new MetroFramework.Controls.MetroLabel();
            this.metroTile11 = new MetroFramework.Controls.MetroTile();
            this.metroTile12 = new MetroFramework.Controls.MetroTile();
            this.circularProgressBar3 = new CircularProgressBar.CircularProgressBar();
            this.circularProgressBar4 = new CircularProgressBar.CircularProgressBar();
            this.metroComboBox3 = new MetroFramework.Controls.MetroComboBox();
            this.metroComboBox4 = new MetroFramework.Controls.MetroComboBox();
            this.chart3 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.metroTabPage10 = new MetroFramework.Controls.MetroTabPage();
            this.metroButton7 = new MetroFramework.Controls.MetroButton();
            this.wecom2 = new MetroFramework.Controls.MetroComboBox();
            this.wecom1 = new MetroFramework.Controls.MetroComboBox();
            this.chart10 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.metroLabel51 = new MetroFramework.Controls.MetroLabel();
            this.metroButton3 = new MetroFramework.Controls.MetroButton();
            this.metroLabel39 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel40 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel41 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel42 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel43 = new MetroFramework.Controls.MetroLabel();
            this.metroTile8 = new MetroFramework.Controls.MetroTile();
            this.metroTile13 = new MetroFramework.Controls.MetroTile();
            this.circularProgressBar5 = new CircularProgressBar.CircularProgressBar();
            this.circularProgressBar6 = new CircularProgressBar.CircularProgressBar();
            this.metroTabPage11 = new MetroFramework.Controls.MetroTabPage();
            this.metroButton6 = new MetroFramework.Controls.MetroButton();
            this.metroLabel52 = new MetroFramework.Controls.MetroLabel();
            this.metroButton4 = new MetroFramework.Controls.MetroButton();
            this.metroLabel44 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel45 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel46 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel47 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel48 = new MetroFramework.Controls.MetroLabel();
            this.metroTile15 = new MetroFramework.Controls.MetroTile();
            this.metroTile16 = new MetroFramework.Controls.MetroTile();
            this.circularProgressBar7 = new CircularProgressBar.CircularProgressBar();
            this.circularProgressBar8 = new CircularProgressBar.CircularProgressBar();
            this.metroComboBox7 = new MetroFramework.Controls.MetroComboBox();
            this.metroComboBox8 = new MetroFramework.Controls.MetroComboBox();
            this.chart8 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.metroTabPage4 = new MetroFramework.Controls.MetroTabPage();
            this.metroButton11 = new MetroFramework.Controls.MetroButton();
            this.metroButton5 = new MetroFramework.Controls.MetroButton();
            this.metroLabel13 = new MetroFramework.Controls.MetroLabel();
            this.attendanceOfEmployeeDateTime2 = new MetroFramework.Controls.MetroDateTime();
            this.attendanceOfEmployeeDateTime = new MetroFramework.Controls.MetroDateTime();
            this.metroLabel12 = new MetroFramework.Controls.MetroLabel();
            this.attendanceDataGrid = new MetroFramework.Controls.MetroGrid();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.shortComingsTimer = new System.Windows.Forms.Timer(this.components);
            this.metroTabControl1.SuspendLayout();
            this.metroTabPage1.SuspendLayout();
            this.metroTabControl2.SuspendLayout();
            this.metroTabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataGrid)).BeginInit();
            this.metroTabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tasksDataGrid)).BeginInit();
            this.metroTabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.projectShortcomingsGrid)).BeginInit();
            this.metroTabPage2.SuspendLayout();
            this.metroTabControl3.SuspendLayout();
            this.metroTabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).BeginInit();
            this.metroTabPage9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).BeginInit();
            this.metroTabPage10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart10)).BeginInit();
            this.metroTabPage11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart8)).BeginInit();
            this.metroTabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.attendanceDataGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // metroTabControl1
            // 
            this.metroTabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroTabControl1.Controls.Add(this.metroTabPage1);
            this.metroTabControl1.Controls.Add(this.metroTabPage2);
            this.metroTabControl1.Controls.Add(this.metroTabPage4);
            this.metroTabControl1.Location = new System.Drawing.Point(12, 82);
            this.metroTabControl1.Name = "metroTabControl1";
            this.metroTabControl1.SelectedIndex = 1;
            this.metroTabControl1.Size = new System.Drawing.Size(770, 500);
            this.metroTabControl1.TabIndex = 1;
            this.metroTabControl1.UseSelectable = true;
            // 
            // metroTabPage1
            // 
            this.metroTabPage1.Controls.Add(this.metroTabControl2);
            this.metroTabPage1.HorizontalScrollbarBarColor = true;
            this.metroTabPage1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage1.HorizontalScrollbarSize = 10;
            this.metroTabPage1.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage1.Name = "metroTabPage1";
            this.metroTabPage1.Size = new System.Drawing.Size(762, 458);
            this.metroTabPage1.TabIndex = 0;
            this.metroTabPage1.Text = "Performance Report";
            this.metroTabPage1.VerticalScrollbarBarColor = true;
            this.metroTabPage1.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage1.VerticalScrollbarSize = 10;
            // 
            // metroTabControl2
            // 
            this.metroTabControl2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroTabControl2.Controls.Add(this.metroTabPage5);
            this.metroTabControl2.Controls.Add(this.metroTabPage6);
            this.metroTabControl2.Controls.Add(this.metroTabPage7);
            this.metroTabControl2.Location = new System.Drawing.Point(7, 3);
            this.metroTabControl2.Name = "metroTabControl2";
            this.metroTabControl2.SelectedIndex = 0;
            this.metroTabControl2.Size = new System.Drawing.Size(752, 452);
            this.metroTabControl2.TabIndex = 2;
            this.metroTabControl2.UseSelectable = true;
            // 
            // metroTabPage5
            // 
            this.metroTabPage5.Controls.Add(this.metroButton10);
            this.metroTabPage5.Controls.Add(this.metroLabel5);
            this.metroTabPage5.Controls.Add(this.metroLabel4);
            this.metroTabPage5.Controls.Add(this.metroLabel2);
            this.metroTabPage5.Controls.Add(this.metroLabel3);
            this.metroTabPage5.Controls.Add(this.eventTxtbox);
            this.metroTabPage5.Controls.Add(this.metroLabel6);
            this.metroTabPage5.Controls.Add(this.deadlineDateTime);
            this.metroTabPage5.Controls.Add(this.metroLabel7);
            this.metroTabPage5.Controls.Add(this.searchProjectTxtBox);
            this.metroTabPage5.Controls.Add(this.startEventDateTime);
            this.metroTabPage5.Controls.Add(this.projectDataGrid);
            this.metroTabPage5.HorizontalScrollbarBarColor = true;
            this.metroTabPage5.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage5.HorizontalScrollbarSize = 10;
            this.metroTabPage5.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage5.Name = "metroTabPage5";
            this.metroTabPage5.Size = new System.Drawing.Size(744, 410);
            this.metroTabPage5.TabIndex = 0;
            this.metroTabPage5.Text = "Projects";
            this.metroTabPage5.VerticalScrollbarBarColor = true;
            this.metroTabPage5.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage5.VerticalScrollbarSize = 10;
            this.metroTabPage5.Click += new System.EventHandler(this.metroTabPage5_Click);
            // 
            // metroButton10
            // 
            this.metroButton10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.metroButton10.Location = new System.Drawing.Point(639, 6);
            this.metroButton10.Name = "metroButton10";
            this.metroButton10.Size = new System.Drawing.Size(75, 23);
            this.metroButton10.TabIndex = 27;
            this.metroButton10.Text = "All";
            this.metroButton10.UseSelectable = true;
            this.metroButton10.Click += new System.EventHandler(this.metroButton10_Click);
            // 
            // metroLabel5
            // 
            this.metroLabel5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(405, 56);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(107, 19);
            this.metroLabel5.TabIndex = 3;
            this.metroLabel5.Text = "Commencement";
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(36, 56);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(107, 19);
            this.metroLabel4.TabIndex = 4;
            this.metroLabel4.Text = "Commencement";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(3, 10);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(55, 19);
            this.metroLabel2.TabIndex = 3;
            this.metroLabel2.Text = "Event Id";
            this.metroLabel2.Click += new System.EventHandler(this.metroLabel2_Click);
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(-1, 56);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(40, 19);
            this.metroLabel3.TabIndex = 3;
            this.metroLabel3.Text = "Event";
            this.metroLabel3.Click += new System.EventHandler(this.metroLabel3_Click);
            // 
            // eventTxtbox
            // 
            // 
            // 
            // 
            this.eventTxtbox.CustomButton.Image = null;
            this.eventTxtbox.CustomButton.Location = new System.Drawing.Point(101, 1);
            this.eventTxtbox.CustomButton.Name = "";
            this.eventTxtbox.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.eventTxtbox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.eventTxtbox.CustomButton.TabIndex = 1;
            this.eventTxtbox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.eventTxtbox.CustomButton.UseSelectable = true;
            this.eventTxtbox.CustomButton.Visible = false;
            this.eventTxtbox.Lines = new string[0];
            this.eventTxtbox.Location = new System.Drawing.Point(147, 6);
            this.eventTxtbox.MaxLength = 32767;
            this.eventTxtbox.Name = "eventTxtbox";
            this.eventTxtbox.PasswordChar = '\0';
            this.eventTxtbox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.eventTxtbox.SelectedText = "";
            this.eventTxtbox.SelectionLength = 0;
            this.eventTxtbox.SelectionStart = 0;
            this.eventTxtbox.ShortcutsEnabled = true;
            this.eventTxtbox.Size = new System.Drawing.Size(123, 23);
            this.eventTxtbox.TabIndex = 26;
            this.eventTxtbox.UseSelectable = true;
            this.eventTxtbox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.eventTxtbox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.eventTxtbox.TextChanged += new System.EventHandler(this.eventTxtbox_TextChanged);
            // 
            // metroLabel6
            // 
            this.metroLabel6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(369, 10);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(65, 19);
            this.metroLabel6.TabIndex = 24;
            this.metroLabel6.Text = "project Id";
            // 
            // deadlineDateTime
            // 
            this.deadlineDateTime.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.deadlineDateTime.Location = new System.Drawing.Point(514, 44);
            this.deadlineDateTime.MinimumSize = new System.Drawing.Size(4, 29);
            this.deadlineDateTime.Name = "deadlineDateTime";
            this.deadlineDateTime.Size = new System.Drawing.Size(200, 29);
            this.deadlineDateTime.TabIndex = 3;
            this.deadlineDateTime.ValueChanged += new System.EventHandler(this.deadlineDateTime_ValueChanged);
            // 
            // metroLabel7
            // 
            this.metroLabel7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(369, 56);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(40, 19);
            this.metroLabel7.TabIndex = 21;
            this.metroLabel7.Text = "Event";
            // 
            // searchProjectTxtBox
            // 
            this.searchProjectTxtBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            this.searchProjectTxtBox.CustomButton.Image = null;
            this.searchProjectTxtBox.CustomButton.Location = new System.Drawing.Point(86, 1);
            this.searchProjectTxtBox.CustomButton.Name = "";
            this.searchProjectTxtBox.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.searchProjectTxtBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.searchProjectTxtBox.CustomButton.TabIndex = 1;
            this.searchProjectTxtBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.searchProjectTxtBox.CustomButton.UseSelectable = true;
            this.searchProjectTxtBox.CustomButton.Visible = false;
            this.searchProjectTxtBox.Lines = new string[0];
            this.searchProjectTxtBox.Location = new System.Drawing.Point(514, 6);
            this.searchProjectTxtBox.MaxLength = 32767;
            this.searchProjectTxtBox.Name = "searchProjectTxtBox";
            this.searchProjectTxtBox.PasswordChar = '\0';
            this.searchProjectTxtBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.searchProjectTxtBox.SelectedText = "";
            this.searchProjectTxtBox.SelectionLength = 0;
            this.searchProjectTxtBox.SelectionStart = 0;
            this.searchProjectTxtBox.ShortcutsEnabled = true;
            this.searchProjectTxtBox.Size = new System.Drawing.Size(108, 23);
            this.searchProjectTxtBox.TabIndex = 19;
            this.searchProjectTxtBox.UseSelectable = true;
            this.searchProjectTxtBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.searchProjectTxtBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.searchProjectTxtBox.TextChanged += new System.EventHandler(this.metroTextBox1_TextChanged);
            this.searchProjectTxtBox.Click += new System.EventHandler(this.searchProjectTxtBox_Click);
            // 
            // startEventDateTime
            // 
            this.startEventDateTime.Location = new System.Drawing.Point(147, 46);
            this.startEventDateTime.MinimumSize = new System.Drawing.Size(4, 29);
            this.startEventDateTime.Name = "startEventDateTime";
            this.startEventDateTime.Size = new System.Drawing.Size(199, 29);
            this.startEventDateTime.TabIndex = 16;
            this.startEventDateTime.ValueChanged += new System.EventHandler(this.metroDateTime1_ValueChanged);
            // 
            // projectDataGrid
            // 
            this.projectDataGrid.AllowUserToResizeRows = false;
            this.projectDataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.projectDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.projectDataGrid.BackgroundColor = System.Drawing.Color.White;
            this.projectDataGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.projectDataGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.projectDataGrid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.projectDataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.projectDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.projectDataGrid.DefaultCellStyle = dataGridViewCellStyle2;
            this.projectDataGrid.EnableHeadersVisualStyles = false;
            this.projectDataGrid.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.projectDataGrid.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.projectDataGrid.Location = new System.Drawing.Point(0, 142);
            this.projectDataGrid.Name = "projectDataGrid";
            this.projectDataGrid.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.projectDataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.projectDataGrid.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.projectDataGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.projectDataGrid.Size = new System.Drawing.Size(741, 228);
            this.projectDataGrid.TabIndex = 12;
            // 
            // metroTabPage6
            // 
            this.metroTabPage6.Controls.Add(this.searchProjectTxtBox1);
            this.metroTabPage6.Controls.Add(this.EventId);
            this.metroTabPage6.Controls.Add(this.gradeETaskLbl);
            this.metroTabPage6.Controls.Add(this.gradeDTaskLbl);
            this.metroTabPage6.Controls.Add(this.gradeCTaskLbl);
            this.metroTabPage6.Controls.Add(this.gradeBTaskLbl);
            this.metroTabPage6.Controls.Add(this.gradeATaskLbl);
            this.metroTabPage6.Controls.Add(this.metroLink6);
            this.metroTabPage6.Controls.Add(this.metroLink7);
            this.metroTabPage6.Controls.Add(this.metroLink8);
            this.metroTabPage6.Controls.Add(this.metroLink9);
            this.metroTabPage6.Controls.Add(this.metroLink10);
            this.metroTabPage6.Controls.Add(this.metroLabel53);
            this.metroTabPage6.Controls.Add(this.metroLabel54);
            this.metroTabPage6.Controls.Add(this.eventTxtbox1);
            this.metroTabPage6.Controls.Add(this.metroLabel20);
            this.metroTabPage6.Controls.Add(this.tasksDataGrid);
            this.metroTabPage6.HorizontalScrollbarBarColor = true;
            this.metroTabPage6.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage6.HorizontalScrollbarSize = 10;
            this.metroTabPage6.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage6.Name = "metroTabPage6";
            this.metroTabPage6.Size = new System.Drawing.Size(744, 410);
            this.metroTabPage6.TabIndex = 1;
            this.metroTabPage6.Text = "Tasks";
            this.metroTabPage6.VerticalScrollbarBarColor = true;
            this.metroTabPage6.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage6.VerticalScrollbarSize = 10;
            this.metroTabPage6.Click += new System.EventHandler(this.metroTabPage6_Click);
            // 
            // searchProjectTxtBox1
            // 
            // 
            // 
            // 
            this.searchProjectTxtBox1.CustomButton.Image = null;
            this.searchProjectTxtBox1.CustomButton.Location = new System.Drawing.Point(61, 1);
            this.searchProjectTxtBox1.CustomButton.Name = "";
            this.searchProjectTxtBox1.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.searchProjectTxtBox1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.searchProjectTxtBox1.CustomButton.TabIndex = 1;
            this.searchProjectTxtBox1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.searchProjectTxtBox1.CustomButton.UseSelectable = true;
            this.searchProjectTxtBox1.CustomButton.Visible = false;
            this.searchProjectTxtBox1.Lines = new string[0];
            this.searchProjectTxtBox1.Location = new System.Drawing.Point(88, 13);
            this.searchProjectTxtBox1.MaxLength = 32767;
            this.searchProjectTxtBox1.Name = "searchProjectTxtBox1";
            this.searchProjectTxtBox1.PasswordChar = '\0';
            this.searchProjectTxtBox1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.searchProjectTxtBox1.SelectedText = "";
            this.searchProjectTxtBox1.SelectionLength = 0;
            this.searchProjectTxtBox1.SelectionStart = 0;
            this.searchProjectTxtBox1.ShortcutsEnabled = true;
            this.searchProjectTxtBox1.Size = new System.Drawing.Size(83, 23);
            this.searchProjectTxtBox1.TabIndex = 52;
            this.searchProjectTxtBox1.UseSelectable = true;
            this.searchProjectTxtBox1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.searchProjectTxtBox1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.searchProjectTxtBox1.TextChanged += new System.EventHandler(this.searchProjectTxtBox1_TextChanged);
            // 
            // EventId
            // 
            this.EventId.AutoSize = true;
            this.EventId.Location = new System.Drawing.Point(182, 17);
            this.EventId.Name = "EventId";
            this.EventId.Size = new System.Drawing.Size(55, 19);
            this.EventId.TabIndex = 51;
            this.EventId.Text = "Event Id";
            // 
            // gradeETaskLbl
            // 
            this.gradeETaskLbl.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.gradeETaskLbl.AutoSize = true;
            this.gradeETaskLbl.Location = new System.Drawing.Point(714, 314);
            this.gradeETaskLbl.Name = "gradeETaskLbl";
            this.gradeETaskLbl.Size = new System.Drawing.Size(0, 0);
            this.gradeETaskLbl.TabIndex = 50;
            // 
            // gradeDTaskLbl
            // 
            this.gradeDTaskLbl.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.gradeDTaskLbl.AutoSize = true;
            this.gradeDTaskLbl.Location = new System.Drawing.Point(714, 257);
            this.gradeDTaskLbl.Name = "gradeDTaskLbl";
            this.gradeDTaskLbl.Size = new System.Drawing.Size(0, 0);
            this.gradeDTaskLbl.TabIndex = 49;
            // 
            // gradeCTaskLbl
            // 
            this.gradeCTaskLbl.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.gradeCTaskLbl.AutoSize = true;
            this.gradeCTaskLbl.Location = new System.Drawing.Point(714, 203);
            this.gradeCTaskLbl.Name = "gradeCTaskLbl";
            this.gradeCTaskLbl.Size = new System.Drawing.Size(0, 0);
            this.gradeCTaskLbl.TabIndex = 48;
            // 
            // gradeBTaskLbl
            // 
            this.gradeBTaskLbl.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.gradeBTaskLbl.AutoSize = true;
            this.gradeBTaskLbl.Location = new System.Drawing.Point(714, 153);
            this.gradeBTaskLbl.Name = "gradeBTaskLbl";
            this.gradeBTaskLbl.Size = new System.Drawing.Size(0, 0);
            this.gradeBTaskLbl.TabIndex = 47;
            // 
            // gradeATaskLbl
            // 
            this.gradeATaskLbl.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.gradeATaskLbl.AutoSize = true;
            this.gradeATaskLbl.Location = new System.Drawing.Point(714, 100);
            this.gradeATaskLbl.Name = "gradeATaskLbl";
            this.gradeATaskLbl.Size = new System.Drawing.Size(0, 0);
            this.gradeATaskLbl.TabIndex = 46;
            // 
            // metroLink6
            // 
            this.metroLink6.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.metroLink6.BackColor = System.Drawing.Color.White;
            this.metroLink6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroLink6.BackgroundImage")));
            this.metroLink6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.metroLink6.Location = new System.Drawing.Point(646, 298);
            this.metroLink6.Name = "metroLink6";
            this.metroLink6.Size = new System.Drawing.Size(51, 47);
            this.metroLink6.TabIndex = 45;
            this.metroLink6.UseSelectable = true;
            // 
            // metroLink7
            // 
            this.metroLink7.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.metroLink7.BackColor = System.Drawing.Color.White;
            this.metroLink7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroLink7.BackgroundImage")));
            this.metroLink7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.metroLink7.Location = new System.Drawing.Point(646, 245);
            this.metroLink7.Name = "metroLink7";
            this.metroLink7.Size = new System.Drawing.Size(51, 47);
            this.metroLink7.TabIndex = 44;
            this.metroLink7.UseSelectable = true;
            // 
            // metroLink8
            // 
            this.metroLink8.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.metroLink8.BackColor = System.Drawing.Color.White;
            this.metroLink8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroLink8.BackgroundImage")));
            this.metroLink8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.metroLink8.Location = new System.Drawing.Point(646, 192);
            this.metroLink8.Name = "metroLink8";
            this.metroLink8.Size = new System.Drawing.Size(51, 47);
            this.metroLink8.TabIndex = 43;
            this.metroLink8.UseSelectable = true;
            // 
            // metroLink9
            // 
            this.metroLink9.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.metroLink9.BackColor = System.Drawing.Color.White;
            this.metroLink9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroLink9.BackgroundImage")));
            this.metroLink9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.metroLink9.Location = new System.Drawing.Point(646, 139);
            this.metroLink9.Name = "metroLink9";
            this.metroLink9.Size = new System.Drawing.Size(51, 47);
            this.metroLink9.TabIndex = 42;
            this.metroLink9.UseSelectable = true;
            // 
            // metroLink10
            // 
            this.metroLink10.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.metroLink10.BackColor = System.Drawing.Color.White;
            this.metroLink10.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroLink10.BackgroundImage")));
            this.metroLink10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.metroLink10.Location = new System.Drawing.Point(646, 86);
            this.metroLink10.Name = "metroLink10";
            this.metroLink10.Size = new System.Drawing.Size(51, 47);
            this.metroLink10.TabIndex = 41;
            this.metroLink10.UseSelectable = true;
            // 
            // metroLabel53
            // 
            this.metroLabel53.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel53.AutoSize = true;
            this.metroLabel53.Location = new System.Drawing.Point(660, 61);
            this.metroLabel53.Name = "metroLabel53";
            this.metroLabel53.Size = new System.Drawing.Size(74, 19);
            this.metroLabel53.TabIndex = 40;
            this.metroLabel53.Text = "Satisfaction";
            // 
            // metroLabel54
            // 
            this.metroLabel54.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel54.AutoSize = true;
            this.metroLabel54.Location = new System.Drawing.Point(660, 42);
            this.metroLabel54.Name = "metroLabel54";
            this.metroLabel54.Size = new System.Drawing.Size(70, 19);
            this.metroLabel54.TabIndex = 39;
            this.metroLabel54.Text = "Customer ";
            // 
            // eventTxtbox1
            // 
            // 
            // 
            // 
            this.eventTxtbox1.CustomButton.Image = null;
            this.eventTxtbox1.CustomButton.Location = new System.Drawing.Point(61, 1);
            this.eventTxtbox1.CustomButton.Name = "";
            this.eventTxtbox1.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.eventTxtbox1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.eventTxtbox1.CustomButton.TabIndex = 1;
            this.eventTxtbox1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.eventTxtbox1.CustomButton.UseSelectable = true;
            this.eventTxtbox1.CustomButton.Visible = false;
            this.eventTxtbox1.Lines = new string[0];
            this.eventTxtbox1.Location = new System.Drawing.Point(243, 13);
            this.eventTxtbox1.MaxLength = 32767;
            this.eventTxtbox1.Name = "eventTxtbox1";
            this.eventTxtbox1.PasswordChar = '\0';
            this.eventTxtbox1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.eventTxtbox1.SelectedText = "";
            this.eventTxtbox1.SelectionLength = 0;
            this.eventTxtbox1.SelectionStart = 0;
            this.eventTxtbox1.ShortcutsEnabled = true;
            this.eventTxtbox1.Size = new System.Drawing.Size(83, 23);
            this.eventTxtbox1.TabIndex = 37;
            this.eventTxtbox1.UseSelectable = true;
            this.eventTxtbox1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.eventTxtbox1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.eventTxtbox1.TextChanged += new System.EventHandler(this.eventTxtbox1_TextChanged);
            // 
            // metroLabel20
            // 
            this.metroLabel20.AutoSize = true;
            this.metroLabel20.Location = new System.Drawing.Point(17, 16);
            this.metroLabel20.Name = "metroLabel20";
            this.metroLabel20.Size = new System.Drawing.Size(65, 19);
            this.metroLabel20.TabIndex = 35;
            this.metroLabel20.Text = "project Id";
            // 
            // tasksDataGrid
            // 
            this.tasksDataGrid.AllowUserToResizeRows = false;
            this.tasksDataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tasksDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.tasksDataGrid.BackgroundColor = System.Drawing.Color.White;
            this.tasksDataGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tasksDataGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.tasksDataGrid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.tasksDataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.tasksDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.tasksDataGrid.DefaultCellStyle = dataGridViewCellStyle5;
            this.tasksDataGrid.EnableHeadersVisualStyles = false;
            this.tasksDataGrid.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.tasksDataGrid.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tasksDataGrid.Location = new System.Drawing.Point(17, 42);
            this.tasksDataGrid.Name = "tasksDataGrid";
            this.tasksDataGrid.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.tasksDataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.tasksDataGrid.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.tasksDataGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.tasksDataGrid.Size = new System.Drawing.Size(620, 357);
            this.tasksDataGrid.TabIndex = 34;
            // 
            // metroTabPage7
            // 
            this.metroTabPage7.Controls.Add(this.metroTile21);
            this.metroTabPage7.Controls.Add(this.EventIdTxtbox);
            this.metroTabPage7.Controls.Add(this.projectIdTxtbox);
            this.metroTabPage7.Controls.Add(this.metroLabel16);
            this.metroTabPage7.Controls.Add(this.descriptionTxtbox);
            this.metroTabPage7.Controls.Add(this.metroLabel15);
            this.metroTabPage7.Controls.Add(this.metroLabel14);
            this.metroTabPage7.Controls.Add(this.metroTile20);
            this.metroTabPage7.Controls.Add(this.metroTile19);
            this.metroTabPage7.Controls.Add(this.metroTile18);
            this.metroTabPage7.Controls.Add(this.projectShortcomingsGrid);
            this.metroTabPage7.HorizontalScrollbarBarColor = true;
            this.metroTabPage7.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage7.HorizontalScrollbarSize = 10;
            this.metroTabPage7.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage7.Name = "metroTabPage7";
            this.metroTabPage7.Size = new System.Drawing.Size(744, 410);
            this.metroTabPage7.TabIndex = 2;
            this.metroTabPage7.Text = "Project Shortcomings";
            this.metroTabPage7.VerticalScrollbarBarColor = true;
            this.metroTabPage7.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage7.VerticalScrollbarSize = 10;
            this.metroTabPage7.Click += new System.EventHandler(this.metroTabPage7_Click);
            // 
            // metroTile21
            // 
            this.metroTile21.ActiveControl = null;
            this.metroTile21.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.metroTile21.Location = new System.Drawing.Point(399, 367);
            this.metroTile21.Name = "metroTile21";
            this.metroTile21.Size = new System.Drawing.Size(72, 40);
            this.metroTile21.TabIndex = 14;
            this.metroTile21.Text = "Clear";
            this.metroTile21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTile21.UseSelectable = true;
            this.metroTile21.Click += new System.EventHandler(this.metroTile21_Click);
            // 
            // EventIdTxtbox
            // 
            this.EventIdTxtbox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            this.EventIdTxtbox.CustomButton.Image = null;
            this.EventIdTxtbox.CustomButton.Location = new System.Drawing.Point(108, 1);
            this.EventIdTxtbox.CustomButton.Name = "";
            this.EventIdTxtbox.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.EventIdTxtbox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.EventIdTxtbox.CustomButton.TabIndex = 1;
            this.EventIdTxtbox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.EventIdTxtbox.CustomButton.UseSelectable = true;
            this.EventIdTxtbox.CustomButton.Visible = false;
            this.EventIdTxtbox.Lines = new string[0];
            this.EventIdTxtbox.Location = new System.Drawing.Point(601, 84);
            this.EventIdTxtbox.MaxLength = 32767;
            this.EventIdTxtbox.Name = "EventIdTxtbox";
            this.EventIdTxtbox.PasswordChar = '\0';
            this.EventIdTxtbox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.EventIdTxtbox.SelectedText = "";
            this.EventIdTxtbox.SelectionLength = 0;
            this.EventIdTxtbox.SelectionStart = 0;
            this.EventIdTxtbox.ShortcutsEnabled = true;
            this.EventIdTxtbox.Size = new System.Drawing.Size(130, 23);
            this.EventIdTxtbox.TabIndex = 13;
            this.EventIdTxtbox.UseSelectable = true;
            this.EventIdTxtbox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.EventIdTxtbox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // projectIdTxtbox
            // 
            this.projectIdTxtbox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            this.projectIdTxtbox.CustomButton.Image = null;
            this.projectIdTxtbox.CustomButton.Location = new System.Drawing.Point(108, 1);
            this.projectIdTxtbox.CustomButton.Name = "";
            this.projectIdTxtbox.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.projectIdTxtbox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.projectIdTxtbox.CustomButton.TabIndex = 1;
            this.projectIdTxtbox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.projectIdTxtbox.CustomButton.UseSelectable = true;
            this.projectIdTxtbox.CustomButton.Visible = false;
            this.projectIdTxtbox.Lines = new string[0];
            this.projectIdTxtbox.Location = new System.Drawing.Point(601, 40);
            this.projectIdTxtbox.MaxLength = 32767;
            this.projectIdTxtbox.Name = "projectIdTxtbox";
            this.projectIdTxtbox.PasswordChar = '\0';
            this.projectIdTxtbox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.projectIdTxtbox.SelectedText = "";
            this.projectIdTxtbox.SelectionLength = 0;
            this.projectIdTxtbox.SelectionStart = 0;
            this.projectIdTxtbox.ShortcutsEnabled = true;
            this.projectIdTxtbox.Size = new System.Drawing.Size(130, 23);
            this.projectIdTxtbox.TabIndex = 12;
            this.projectIdTxtbox.UseSelectable = true;
            this.projectIdTxtbox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.projectIdTxtbox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel16
            // 
            this.metroLabel16.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel16.AutoSize = true;
            this.metroLabel16.Location = new System.Drawing.Point(530, 137);
            this.metroLabel16.Name = "metroLabel16";
            this.metroLabel16.Size = new System.Drawing.Size(74, 19);
            this.metroLabel16.TabIndex = 11;
            this.metroLabel16.Text = "Description";
            // 
            // descriptionTxtbox
            // 
            this.descriptionTxtbox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            this.descriptionTxtbox.CustomButton.Image = null;
            this.descriptionTxtbox.CustomButton.Location = new System.Drawing.Point(87, 2);
            this.descriptionTxtbox.CustomButton.Name = "";
            this.descriptionTxtbox.CustomButton.Size = new System.Drawing.Size(111, 111);
            this.descriptionTxtbox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.descriptionTxtbox.CustomButton.TabIndex = 1;
            this.descriptionTxtbox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.descriptionTxtbox.CustomButton.UseSelectable = true;
            this.descriptionTxtbox.CustomButton.Visible = false;
            this.descriptionTxtbox.Lines = new string[0];
            this.descriptionTxtbox.Location = new System.Drawing.Point(530, 159);
            this.descriptionTxtbox.MaxLength = 32767;
            this.descriptionTxtbox.Multiline = true;
            this.descriptionTxtbox.Name = "descriptionTxtbox";
            this.descriptionTxtbox.PasswordChar = '\0';
            this.descriptionTxtbox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.descriptionTxtbox.SelectedText = "";
            this.descriptionTxtbox.SelectionLength = 0;
            this.descriptionTxtbox.SelectionStart = 0;
            this.descriptionTxtbox.ShortcutsEnabled = true;
            this.descriptionTxtbox.Size = new System.Drawing.Size(201, 116);
            this.descriptionTxtbox.TabIndex = 10;
            this.descriptionTxtbox.UseSelectable = true;
            this.descriptionTxtbox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.descriptionTxtbox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel15
            // 
            this.metroLabel15.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel15.AutoSize = true;
            this.metroLabel15.Location = new System.Drawing.Point(530, 88);
            this.metroLabel15.Name = "metroLabel15";
            this.metroLabel15.Size = new System.Drawing.Size(55, 19);
            this.metroLabel15.TabIndex = 9;
            this.metroLabel15.Text = "Event Id";
            // 
            // metroLabel14
            // 
            this.metroLabel14.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel14.AutoSize = true;
            this.metroLabel14.Location = new System.Drawing.Point(530, 44);
            this.metroLabel14.Name = "metroLabel14";
            this.metroLabel14.Size = new System.Drawing.Size(65, 19);
            this.metroLabel14.TabIndex = 8;
            this.metroLabel14.Text = "Project Id";
            // 
            // metroTile20
            // 
            this.metroTile20.ActiveControl = null;
            this.metroTile20.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.metroTile20.Location = new System.Drawing.Point(647, 367);
            this.metroTile20.Name = "metroTile20";
            this.metroTile20.Size = new System.Drawing.Size(84, 40);
            this.metroTile20.TabIndex = 7;
            this.metroTile20.Text = "Delete";
            this.metroTile20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTile20.UseSelectable = true;
            this.metroTile20.Click += new System.EventHandler(this.metroTile20_Click);
            // 
            // metroTile19
            // 
            this.metroTile19.ActiveControl = null;
            this.metroTile19.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.metroTile19.Location = new System.Drawing.Point(561, 367);
            this.metroTile19.Name = "metroTile19";
            this.metroTile19.Size = new System.Drawing.Size(80, 40);
            this.metroTile19.TabIndex = 6;
            this.metroTile19.Text = "Update";
            this.metroTile19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTile19.UseSelectable = true;
            this.metroTile19.Click += new System.EventHandler(this.metroTile19_Click);
            // 
            // metroTile18
            // 
            this.metroTile18.ActiveControl = null;
            this.metroTile18.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.metroTile18.Location = new System.Drawing.Point(477, 367);
            this.metroTile18.Name = "metroTile18";
            this.metroTile18.Size = new System.Drawing.Size(78, 40);
            this.metroTile18.TabIndex = 5;
            this.metroTile18.Text = "Add ";
            this.metroTile18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTile18.UseSelectable = true;
            this.metroTile18.Click += new System.EventHandler(this.metroTile18_Click);
            // 
            // projectShortcomingsGrid
            // 
            this.projectShortcomingsGrid.AllowUserToResizeRows = false;
            this.projectShortcomingsGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.projectShortcomingsGrid.BackgroundColor = System.Drawing.Color.White;
            this.projectShortcomingsGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.projectShortcomingsGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.projectShortcomingsGrid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.projectShortcomingsGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.projectShortcomingsGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.projectShortcomingsGrid.DefaultCellStyle = dataGridViewCellStyle8;
            this.projectShortcomingsGrid.EnableHeadersVisualStyles = false;
            this.projectShortcomingsGrid.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.projectShortcomingsGrid.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.projectShortcomingsGrid.Location = new System.Drawing.Point(3, 14);
            this.projectShortcomingsGrid.Name = "projectShortcomingsGrid";
            this.projectShortcomingsGrid.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.projectShortcomingsGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.projectShortcomingsGrid.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.projectShortcomingsGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.projectShortcomingsGrid.Size = new System.Drawing.Size(506, 323);
            this.projectShortcomingsGrid.TabIndex = 2;
            this.projectShortcomingsGrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.projectShortcomingsGrid_CellContentClick);
            this.projectShortcomingsGrid.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.projectShortcomingsGrid_RowHeaderMouseClick);
            // 
            // metroTabPage2
            // 
            this.metroTabPage2.Controls.Add(this.metroTabControl3);
            this.metroTabPage2.HorizontalScrollbarBarColor = true;
            this.metroTabPage2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage2.HorizontalScrollbarSize = 10;
            this.metroTabPage2.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage2.Name = "metroTabPage2";
            this.metroTabPage2.Size = new System.Drawing.Size(762, 458);
            this.metroTabPage2.TabIndex = 1;
            this.metroTabPage2.Text = "Evaluation";
            this.metroTabPage2.VerticalScrollbarBarColor = true;
            this.metroTabPage2.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage2.VerticalScrollbarSize = 10;
            // 
            // metroTabControl3
            // 
            this.metroTabControl3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroTabControl3.Controls.Add(this.metroTabPage8);
            this.metroTabControl3.Controls.Add(this.metroTabPage9);
            this.metroTabControl3.Controls.Add(this.metroTabPage10);
            this.metroTabControl3.Controls.Add(this.metroTabPage11);
            this.metroTabControl3.Location = new System.Drawing.Point(4, 2);
            this.metroTabControl3.Name = "metroTabControl3";
            this.metroTabControl3.SelectedIndex = 0;
            this.metroTabControl3.Size = new System.Drawing.Size(752, 452);
            this.metroTabControl3.TabIndex = 5;
            this.metroTabControl3.UseSelectable = true;
            this.metroTabControl3.SelectedIndexChanged += new System.EventHandler(this.metroTabControl3_SelectedIndexChanged);
            // 
            // metroTabPage8
            // 
            this.metroTabPage8.Controls.Add(this.metroButton9);
            this.metroTabPage8.Controls.Add(this.metroLabel32);
            this.metroTabPage8.Controls.Add(this.metroLabel30);
            this.metroTabPage8.Controls.Add(this.metroLabel29);
            this.metroTabPage8.Controls.Add(this.metroLabel28);
            this.metroTabPage8.Controls.Add(this.metroTile10);
            this.metroTabPage8.Controls.Add(this.metroTile4);
            this.metroTabPage8.Controls.Add(this.circularProgressBar2);
            this.metroTabPage8.Controls.Add(this.metroLabel27);
            this.metroTabPage8.Controls.Add(this.metroLabel25);
            this.metroTabPage8.Controls.Add(this.metroLabel26);
            this.metroTabPage8.Controls.Add(this.metroLabel24);
            this.metroTabPage8.Controls.Add(this.metroButton1);
            this.metroTabPage8.Controls.Add(this.metroComboBox2);
            this.metroTabPage8.Controls.Add(this.metroComboBox1);
            this.metroTabPage8.Controls.Add(this.metroLabel21);
            this.metroTabPage8.Controls.Add(this.circularProgressBar1);
            this.metroTabPage8.Controls.Add(this.chart2);
            this.metroTabPage8.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroTabPage8.HorizontalScrollbarBarColor = true;
            this.metroTabPage8.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage8.HorizontalScrollbarSize = 10;
            this.metroTabPage8.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage8.Name = "metroTabPage8";
            this.metroTabPage8.Size = new System.Drawing.Size(744, 410);
            this.metroTabPage8.TabIndex = 0;
            this.metroTabPage8.Text = "Job Performance";
            this.metroTabPage8.VerticalScrollbarBarColor = true;
            this.metroTabPage8.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage8.VerticalScrollbarSize = 10;
            this.metroTabPage8.Click += new System.EventHandler(this.metroTabPage8_Click);
            // 
            // metroButton9
            // 
            this.metroButton9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.metroButton9.Location = new System.Drawing.Point(566, 323);
            this.metroButton9.Name = "metroButton9";
            this.metroButton9.Size = new System.Drawing.Size(75, 23);
            this.metroButton9.TabIndex = 32;
            this.metroButton9.Text = "Add";
            this.metroButton9.UseSelectable = true;
            this.metroButton9.Click += new System.EventHandler(this.metroButton9_Click);
            // 
            // metroLabel32
            // 
            this.metroLabel32.AutoSize = true;
            this.metroLabel32.Location = new System.Drawing.Point(566, 77);
            this.metroLabel32.Name = "metroLabel32";
            this.metroLabel32.Size = new System.Drawing.Size(0, 0);
            this.metroLabel32.TabIndex = 31;
            // 
            // metroLabel30
            // 
            this.metroLabel30.AutoSize = true;
            this.metroLabel30.Location = new System.Drawing.Point(566, 33);
            this.metroLabel30.Name = "metroLabel30";
            this.metroLabel30.Size = new System.Drawing.Size(60, 19);
            this.metroLabel30.TabIndex = 29;
            this.metroLabel30.Text = "Progress";
            // 
            // metroLabel29
            // 
            this.metroLabel29.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel29.AutoSize = true;
            this.metroLabel29.Location = new System.Drawing.Point(566, 49);
            this.metroLabel29.Name = "metroLabel29";
            this.metroLabel29.Size = new System.Drawing.Size(71, 19);
            this.metroLabel29.TabIndex = 28;
            this.metroLabel29.Text = "Retrogress";
            // 
            // metroLabel28
            // 
            this.metroLabel28.AutoSize = true;
            this.metroLabel28.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel28.Location = new System.Drawing.Point(580, 14);
            this.metroLabel28.Name = "metroLabel28";
            this.metroLabel28.Size = new System.Drawing.Size(34, 19);
            this.metroLabel28.TabIndex = 27;
            this.metroLabel28.Text = "Key";
            this.metroLabel28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // metroTile10
            // 
            this.metroTile10.ActiveControl = null;
            this.metroTile10.Location = new System.Drawing.Point(677, 39);
            this.metroTile10.Name = "metroTile10";
            this.metroTile10.Size = new System.Drawing.Size(15, 10);
            this.metroTile10.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTile10.TabIndex = 26;
            this.metroTile10.Text = "metroTile10";
            this.metroTile10.UseSelectable = true;
            // 
            // metroTile4
            // 
            this.metroTile4.ActiveControl = null;
            this.metroTile4.Location = new System.Drawing.Point(677, 54);
            this.metroTile4.Name = "metroTile4";
            this.metroTile4.Size = new System.Drawing.Size(15, 10);
            this.metroTile4.Style = MetroFramework.MetroColorStyle.Red;
            this.metroTile4.TabIndex = 25;
            this.metroTile4.Text = "metroTile4";
            this.metroTile4.UseSelectable = true;
            // 
            // circularProgressBar2
            // 
            this.circularProgressBar2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.circularProgressBar2.AnimationFunction = WinFormAnimation.KnownAnimationFunctions.CubicEaseIn;
            this.circularProgressBar2.AnimationSpeed = 500;
            this.circularProgressBar2.BackColor = System.Drawing.Color.Transparent;
            this.circularProgressBar2.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold);
            this.circularProgressBar2.ForeColor = System.Drawing.Color.Black;
            this.circularProgressBar2.InnerColor = System.Drawing.Color.White;
            this.circularProgressBar2.InnerMargin = 2;
            this.circularProgressBar2.InnerWidth = -1;
            this.circularProgressBar2.Location = new System.Drawing.Point(589, 115);
            this.circularProgressBar2.MarqueeAnimationSpeed = 2000;
            this.circularProgressBar2.Name = "circularProgressBar2";
            this.circularProgressBar2.OuterColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.circularProgressBar2.OuterMargin = -25;
            this.circularProgressBar2.OuterWidth = 26;
            this.circularProgressBar2.ProgressColor = System.Drawing.Color.DodgerBlue;
            this.circularProgressBar2.ProgressWidth = 25;
            this.circularProgressBar2.SecondaryFont = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
            this.circularProgressBar2.Size = new System.Drawing.Size(140, 140);
            this.circularProgressBar2.StartAngle = 270;
            this.circularProgressBar2.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.circularProgressBar2.SubscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.circularProgressBar2.SubscriptMargin = new System.Windows.Forms.Padding(10, -35, 0, 0);
            this.circularProgressBar2.SubscriptText = "%";
            this.circularProgressBar2.SuperscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.circularProgressBar2.SuperscriptMargin = new System.Windows.Forms.Padding(10, 35, 0, 0);
            this.circularProgressBar2.SuperscriptText = "";
            this.circularProgressBar2.TabIndex = 24;
            this.circularProgressBar2.Text = "0";
            this.circularProgressBar2.TextMargin = new System.Windows.Forms.Padding(-3, 8, 0, 0);
            this.circularProgressBar2.Value = 1;
            // 
            // metroLabel27
            // 
            this.metroLabel27.AutoSize = true;
            this.metroLabel27.Location = new System.Drawing.Point(584, 11);
            this.metroLabel27.Name = "metroLabel27";
            this.metroLabel27.Size = new System.Drawing.Size(0, 0);
            this.metroLabel27.TabIndex = 23;
            // 
            // metroLabel25
            // 
            this.metroLabel25.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.metroLabel25.AutoSize = true;
            this.metroLabel25.Location = new System.Drawing.Point(123, 376);
            this.metroLabel25.Name = "metroLabel25";
            this.metroLabel25.Size = new System.Drawing.Size(90, 19);
            this.metroLabel25.TabIndex = 22;
            this.metroLabel25.Text = "metroLabel25";
            // 
            // metroLabel26
            // 
            this.metroLabel26.AutoSize = true;
            this.metroLabel26.Location = new System.Drawing.Point(118, 371);
            this.metroLabel26.Name = "metroLabel26";
            this.metroLabel26.Size = new System.Drawing.Size(0, 0);
            this.metroLabel26.TabIndex = 21;
            // 
            // metroLabel24
            // 
            this.metroLabel24.AutoSize = true;
            this.metroLabel24.Location = new System.Drawing.Point(118, 371);
            this.metroLabel24.Name = "metroLabel24";
            this.metroLabel24.Size = new System.Drawing.Size(0, 0);
            this.metroLabel24.TabIndex = 19;
            // 
            // metroButton1
            // 
            this.metroButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.metroButton1.Location = new System.Drawing.Point(566, 294);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(175, 23);
            this.metroButton1.TabIndex = 17;
            this.metroButton1.Text = "Improvement Percentage";
            this.metroButton1.UseSelectable = true;
            this.metroButton1.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // metroComboBox2
            // 
            this.metroComboBox2.FormattingEnabled = true;
            this.metroComboBox2.ItemHeight = 23;
            this.metroComboBox2.Location = new System.Drawing.Point(316, 23);
            this.metroComboBox2.Name = "metroComboBox2";
            this.metroComboBox2.Size = new System.Drawing.Size(132, 29);
            this.metroComboBox2.TabIndex = 15;
            this.metroComboBox2.UseSelectable = true;
            this.metroComboBox2.SelectedIndexChanged += new System.EventHandler(this.metroComboBox2_SelectedIndexChanged);
            // 
            // metroComboBox1
            // 
            this.metroComboBox1.FormattingEnabled = true;
            this.metroComboBox1.ItemHeight = 23;
            this.metroComboBox1.Items.AddRange(new object[] {
            "2017",
            "2018"});
            this.metroComboBox1.Location = new System.Drawing.Point(18, 23);
            this.metroComboBox1.Name = "metroComboBox1";
            this.metroComboBox1.Size = new System.Drawing.Size(132, 29);
            this.metroComboBox1.TabIndex = 14;
            this.metroComboBox1.UseSelectable = true;
            this.metroComboBox1.SelectedIndexChanged += new System.EventHandler(this.metroComboBox1_SelectedIndexChanged);
            // 
            // metroLabel21
            // 
            this.metroLabel21.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.metroLabel21.AutoSize = true;
            this.metroLabel21.Location = new System.Drawing.Point(47, 376);
            this.metroLabel21.Name = "metroLabel21";
            this.metroLabel21.Size = new System.Drawing.Size(70, 19);
            this.metroLabel21.TabIndex = 12;
            this.metroLabel21.Text = "percentile ";
            this.metroLabel21.Click += new System.EventHandler(this.metroLabel21_Click);
            // 
            // circularProgressBar1
            // 
            this.circularProgressBar1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.circularProgressBar1.AnimationFunction = WinFormAnimation.KnownAnimationFunctions.CubicEaseIn;
            this.circularProgressBar1.AnimationSpeed = 500;
            this.circularProgressBar1.BackColor = System.Drawing.Color.Transparent;
            this.circularProgressBar1.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold);
            this.circularProgressBar1.ForeColor = System.Drawing.Color.Black;
            this.circularProgressBar1.InnerColor = System.Drawing.Color.White;
            this.circularProgressBar1.InnerMargin = 2;
            this.circularProgressBar1.InnerWidth = -1;
            this.circularProgressBar1.Location = new System.Drawing.Point(589, 115);
            this.circularProgressBar1.MarqueeAnimationSpeed = 2000;
            this.circularProgressBar1.Name = "circularProgressBar1";
            this.circularProgressBar1.OuterColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.circularProgressBar1.OuterMargin = -25;
            this.circularProgressBar1.OuterWidth = 26;
            this.circularProgressBar1.ProgressColor = System.Drawing.Color.Crimson;
            this.circularProgressBar1.ProgressWidth = 25;
            this.circularProgressBar1.SecondaryFont = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
            this.circularProgressBar1.Size = new System.Drawing.Size(140, 140);
            this.circularProgressBar1.StartAngle = 270;
            this.circularProgressBar1.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.circularProgressBar1.SubscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.circularProgressBar1.SubscriptMargin = new System.Windows.Forms.Padding(10, -35, 0, 0);
            this.circularProgressBar1.SubscriptText = "%";
            this.circularProgressBar1.SuperscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.circularProgressBar1.SuperscriptMargin = new System.Windows.Forms.Padding(10, 35, 0, 0);
            this.circularProgressBar1.SuperscriptText = "";
            this.circularProgressBar1.TabIndex = 11;
            this.circularProgressBar1.Text = "0";
            this.circularProgressBar1.TextMargin = new System.Windows.Forms.Padding(-3, 8, 0, 0);
            this.circularProgressBar1.Value = 10;
            this.circularProgressBar1.Click += new System.EventHandler(this.circularProgressBar1_Click);
            // 
            // chart2
            // 
            this.chart2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            chartArea1.AxisX.TextOrientation = System.Windows.Forms.DataVisualization.Charting.TextOrientation.Horizontal;
            chartArea1.Name = "ChartArea1";
            this.chart2.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart2.Legends.Add(legend1);
            this.chart2.Location = new System.Drawing.Point(-12, 58);
            this.chart2.Name = "chart2";
            this.chart2.Size = new System.Drawing.Size(572, 315);
            this.chart2.TabIndex = 8;
            this.chart2.Text = "chart2";
            // 
            // metroTabPage9
            // 
            this.metroTabPage9.Controls.Add(this.metroButton8);
            this.metroTabPage9.Controls.Add(this.metroLabel50);
            this.metroTabPage9.Controls.Add(this.metroButton2);
            this.metroTabPage9.Controls.Add(this.metroLabel38);
            this.metroTabPage9.Controls.Add(this.metroLabel34);
            this.metroTabPage9.Controls.Add(this.metroLabel35);
            this.metroTabPage9.Controls.Add(this.metroLabel36);
            this.metroTabPage9.Controls.Add(this.metroLabel37);
            this.metroTabPage9.Controls.Add(this.metroTile11);
            this.metroTabPage9.Controls.Add(this.metroTile12);
            this.metroTabPage9.Controls.Add(this.circularProgressBar3);
            this.metroTabPage9.Controls.Add(this.circularProgressBar4);
            this.metroTabPage9.Controls.Add(this.metroComboBox3);
            this.metroTabPage9.Controls.Add(this.metroComboBox4);
            this.metroTabPage9.Controls.Add(this.chart3);
            this.metroTabPage9.HorizontalScrollbarBarColor = true;
            this.metroTabPage9.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage9.HorizontalScrollbarSize = 10;
            this.metroTabPage9.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage9.Name = "metroTabPage9";
            this.metroTabPage9.Size = new System.Drawing.Size(744, 410);
            this.metroTabPage9.TabIndex = 1;
            this.metroTabPage9.Text = "Client Relations";
            this.metroTabPage9.VerticalScrollbarBarColor = true;
            this.metroTabPage9.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage9.VerticalScrollbarSize = 10;
            this.metroTabPage9.Click += new System.EventHandler(this.metroTabPage9_Click);
            // 
            // metroButton8
            // 
            this.metroButton8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.metroButton8.Location = new System.Drawing.Point(566, 323);
            this.metroButton8.Name = "metroButton8";
            this.metroButton8.Size = new System.Drawing.Size(75, 23);
            this.metroButton8.TabIndex = 43;
            this.metroButton8.Text = "Add";
            this.metroButton8.UseSelectable = true;
            this.metroButton8.Click += new System.EventHandler(this.metroButton8_Click);
            // 
            // metroLabel50
            // 
            this.metroLabel50.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.metroLabel50.AutoSize = true;
            this.metroLabel50.Location = new System.Drawing.Point(123, 376);
            this.metroLabel50.Name = "metroLabel50";
            this.metroLabel50.Size = new System.Drawing.Size(90, 19);
            this.metroLabel50.TabIndex = 42;
            this.metroLabel50.Text = "metroLabel50";
            // 
            // metroButton2
            // 
            this.metroButton2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.metroButton2.Location = new System.Drawing.Point(566, 294);
            this.metroButton2.Name = "metroButton2";
            this.metroButton2.Size = new System.Drawing.Size(175, 23);
            this.metroButton2.TabIndex = 41;
            this.metroButton2.Text = "Improvement Percentage";
            this.metroButton2.UseSelectable = true;
            this.metroButton2.Click += new System.EventHandler(this.metroButton2_Click);
            // 
            // metroLabel38
            // 
            this.metroLabel38.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.metroLabel38.AutoSize = true;
            this.metroLabel38.Location = new System.Drawing.Point(47, 376);
            this.metroLabel38.Name = "metroLabel38";
            this.metroLabel38.Size = new System.Drawing.Size(70, 19);
            this.metroLabel38.TabIndex = 40;
            this.metroLabel38.Text = "percentile ";
            // 
            // metroLabel34
            // 
            this.metroLabel34.AutoSize = true;
            this.metroLabel34.Location = new System.Drawing.Point(566, 77);
            this.metroLabel34.Name = "metroLabel34";
            this.metroLabel34.Size = new System.Drawing.Size(0, 0);
            this.metroLabel34.TabIndex = 39;
            // 
            // metroLabel35
            // 
            this.metroLabel35.AutoSize = true;
            this.metroLabel35.Location = new System.Drawing.Point(566, 33);
            this.metroLabel35.Name = "metroLabel35";
            this.metroLabel35.Size = new System.Drawing.Size(60, 19);
            this.metroLabel35.TabIndex = 38;
            this.metroLabel35.Text = "Progress";
            // 
            // metroLabel36
            // 
            this.metroLabel36.AutoSize = true;
            this.metroLabel36.Location = new System.Drawing.Point(566, 49);
            this.metroLabel36.Name = "metroLabel36";
            this.metroLabel36.Size = new System.Drawing.Size(71, 19);
            this.metroLabel36.TabIndex = 37;
            this.metroLabel36.Text = "Retrogress";
            // 
            // metroLabel37
            // 
            this.metroLabel37.AutoSize = true;
            this.metroLabel37.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel37.Location = new System.Drawing.Point(580, 14);
            this.metroLabel37.Name = "metroLabel37";
            this.metroLabel37.Size = new System.Drawing.Size(34, 19);
            this.metroLabel37.TabIndex = 36;
            this.metroLabel37.Text = "Key";
            this.metroLabel37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // metroTile11
            // 
            this.metroTile11.ActiveControl = null;
            this.metroTile11.Location = new System.Drawing.Point(677, 39);
            this.metroTile11.Name = "metroTile11";
            this.metroTile11.Size = new System.Drawing.Size(15, 10);
            this.metroTile11.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTile11.TabIndex = 35;
            this.metroTile11.Text = "metroTile11";
            this.metroTile11.UseSelectable = true;
            // 
            // metroTile12
            // 
            this.metroTile12.ActiveControl = null;
            this.metroTile12.Location = new System.Drawing.Point(677, 54);
            this.metroTile12.Name = "metroTile12";
            this.metroTile12.Size = new System.Drawing.Size(15, 10);
            this.metroTile12.Style = MetroFramework.MetroColorStyle.Red;
            this.metroTile12.TabIndex = 34;
            this.metroTile12.Text = "metroTile12";
            this.metroTile12.UseSelectable = true;
            // 
            // circularProgressBar3
            // 
            this.circularProgressBar3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.circularProgressBar3.AnimationFunction = WinFormAnimation.KnownAnimationFunctions.CubicEaseIn;
            this.circularProgressBar3.AnimationSpeed = 500;
            this.circularProgressBar3.BackColor = System.Drawing.Color.Transparent;
            this.circularProgressBar3.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold);
            this.circularProgressBar3.ForeColor = System.Drawing.Color.Black;
            this.circularProgressBar3.InnerColor = System.Drawing.Color.White;
            this.circularProgressBar3.InnerMargin = 2;
            this.circularProgressBar3.InnerWidth = -1;
            this.circularProgressBar3.Location = new System.Drawing.Point(589, 115);
            this.circularProgressBar3.MarqueeAnimationSpeed = 2000;
            this.circularProgressBar3.Name = "circularProgressBar3";
            this.circularProgressBar3.OuterColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.circularProgressBar3.OuterMargin = -25;
            this.circularProgressBar3.OuterWidth = 26;
            this.circularProgressBar3.ProgressColor = System.Drawing.Color.DodgerBlue;
            this.circularProgressBar3.ProgressWidth = 25;
            this.circularProgressBar3.SecondaryFont = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
            this.circularProgressBar3.Size = new System.Drawing.Size(140, 140);
            this.circularProgressBar3.StartAngle = 270;
            this.circularProgressBar3.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.circularProgressBar3.SubscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.circularProgressBar3.SubscriptMargin = new System.Windows.Forms.Padding(10, -35, 0, 0);
            this.circularProgressBar3.SubscriptText = "%";
            this.circularProgressBar3.SuperscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.circularProgressBar3.SuperscriptMargin = new System.Windows.Forms.Padding(10, 35, 0, 0);
            this.circularProgressBar3.SuperscriptText = "";
            this.circularProgressBar3.TabIndex = 33;
            this.circularProgressBar3.Text = "0";
            this.circularProgressBar3.TextMargin = new System.Windows.Forms.Padding(-3, 8, 0, 0);
            this.circularProgressBar3.Value = 1;
            this.circularProgressBar3.Click += new System.EventHandler(this.circularProgressBar3_Click);
            // 
            // circularProgressBar4
            // 
            this.circularProgressBar4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.circularProgressBar4.AnimationFunction = WinFormAnimation.KnownAnimationFunctions.CubicEaseIn;
            this.circularProgressBar4.AnimationSpeed = 500;
            this.circularProgressBar4.BackColor = System.Drawing.Color.Transparent;
            this.circularProgressBar4.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold);
            this.circularProgressBar4.ForeColor = System.Drawing.Color.Black;
            this.circularProgressBar4.InnerColor = System.Drawing.Color.White;
            this.circularProgressBar4.InnerMargin = 2;
            this.circularProgressBar4.InnerWidth = -1;
            this.circularProgressBar4.Location = new System.Drawing.Point(589, 115);
            this.circularProgressBar4.MarqueeAnimationSpeed = 2000;
            this.circularProgressBar4.Name = "circularProgressBar4";
            this.circularProgressBar4.OuterColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.circularProgressBar4.OuterMargin = -25;
            this.circularProgressBar4.OuterWidth = 26;
            this.circularProgressBar4.ProgressColor = System.Drawing.Color.Crimson;
            this.circularProgressBar4.ProgressWidth = 25;
            this.circularProgressBar4.SecondaryFont = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
            this.circularProgressBar4.Size = new System.Drawing.Size(140, 140);
            this.circularProgressBar4.StartAngle = 270;
            this.circularProgressBar4.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.circularProgressBar4.SubscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.circularProgressBar4.SubscriptMargin = new System.Windows.Forms.Padding(10, -35, 0, 0);
            this.circularProgressBar4.SubscriptText = "%";
            this.circularProgressBar4.SuperscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.circularProgressBar4.SuperscriptMargin = new System.Windows.Forms.Padding(10, 35, 0, 0);
            this.circularProgressBar4.SuperscriptText = "";
            this.circularProgressBar4.TabIndex = 32;
            this.circularProgressBar4.Text = "0";
            this.circularProgressBar4.TextMargin = new System.Windows.Forms.Padding(-3, 8, 0, 0);
            this.circularProgressBar4.Value = 10;
            // 
            // metroComboBox3
            // 
            this.metroComboBox3.FormattingEnabled = true;
            this.metroComboBox3.ItemHeight = 23;
            this.metroComboBox3.Location = new System.Drawing.Point(316, 23);
            this.metroComboBox3.Name = "metroComboBox3";
            this.metroComboBox3.Size = new System.Drawing.Size(132, 29);
            this.metroComboBox3.TabIndex = 17;
            this.metroComboBox3.UseSelectable = true;
            this.metroComboBox3.SelectedIndexChanged += new System.EventHandler(this.metroComboBox3_SelectedIndexChanged);
            // 
            // metroComboBox4
            // 
            this.metroComboBox4.FormattingEnabled = true;
            this.metroComboBox4.ItemHeight = 23;
            this.metroComboBox4.Items.AddRange(new object[] {
            "2017",
            "2018"});
            this.metroComboBox4.Location = new System.Drawing.Point(18, 23);
            this.metroComboBox4.Name = "metroComboBox4";
            this.metroComboBox4.Size = new System.Drawing.Size(132, 29);
            this.metroComboBox4.TabIndex = 16;
            this.metroComboBox4.UseSelectable = true;
            this.metroComboBox4.SelectedIndexChanged += new System.EventHandler(this.metroComboBox4_SelectedIndexChanged);
            // 
            // chart3
            // 
            this.chart3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            chartArea2.AxisX.TextOrientation = System.Windows.Forms.DataVisualization.Charting.TextOrientation.Rotated90;
            chartArea2.Name = "ChartArea1";
            this.chart3.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.chart3.Legends.Add(legend2);
            this.chart3.Location = new System.Drawing.Point(-12, 58);
            this.chart3.Name = "chart3";
            this.chart3.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.SeaGreen;
            this.chart3.Size = new System.Drawing.Size(572, 315);
            this.chart3.TabIndex = 9;
            this.chart3.Text = "chart3";
            // 
            // metroTabPage10
            // 
            this.metroTabPage10.Controls.Add(this.metroButton7);
            this.metroTabPage10.Controls.Add(this.wecom2);
            this.metroTabPage10.Controls.Add(this.wecom1);
            this.metroTabPage10.Controls.Add(this.chart10);
            this.metroTabPage10.Controls.Add(this.metroLabel51);
            this.metroTabPage10.Controls.Add(this.metroButton3);
            this.metroTabPage10.Controls.Add(this.metroLabel39);
            this.metroTabPage10.Controls.Add(this.metroLabel40);
            this.metroTabPage10.Controls.Add(this.metroLabel41);
            this.metroTabPage10.Controls.Add(this.metroLabel42);
            this.metroTabPage10.Controls.Add(this.metroLabel43);
            this.metroTabPage10.Controls.Add(this.metroTile8);
            this.metroTabPage10.Controls.Add(this.metroTile13);
            this.metroTabPage10.Controls.Add(this.circularProgressBar5);
            this.metroTabPage10.Controls.Add(this.circularProgressBar6);
            this.metroTabPage10.HorizontalScrollbarBarColor = true;
            this.metroTabPage10.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage10.HorizontalScrollbarSize = 10;
            this.metroTabPage10.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage10.Name = "metroTabPage10";
            this.metroTabPage10.Size = new System.Drawing.Size(744, 410);
            this.metroTabPage10.TabIndex = 2;
            this.metroTabPage10.Text = "Communication Skills";
            this.metroTabPage10.VerticalScrollbarBarColor = true;
            this.metroTabPage10.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage10.VerticalScrollbarSize = 10;
            // 
            // metroButton7
            // 
            this.metroButton7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.metroButton7.Location = new System.Drawing.Point(566, 323);
            this.metroButton7.Name = "metroButton7";
            this.metroButton7.Size = new System.Drawing.Size(75, 23);
            this.metroButton7.TabIndex = 63;
            this.metroButton7.Text = "Add";
            this.metroButton7.UseSelectable = true;
            this.metroButton7.Click += new System.EventHandler(this.metroButton7_Click);
            // 
            // wecom2
            // 
            this.wecom2.FormattingEnabled = true;
            this.wecom2.ItemHeight = 23;
            this.wecom2.Location = new System.Drawing.Point(316, 23);
            this.wecom2.Name = "wecom2";
            this.wecom2.Size = new System.Drawing.Size(132, 29);
            this.wecom2.TabIndex = 62;
            this.wecom2.UseSelectable = true;
            this.wecom2.SelectedIndexChanged += new System.EventHandler(this.wecom2_SelectedIndexChanged);
            // 
            // wecom1
            // 
            this.wecom1.FormattingEnabled = true;
            this.wecom1.ItemHeight = 23;
            this.wecom1.Location = new System.Drawing.Point(18, 23);
            this.wecom1.Name = "wecom1";
            this.wecom1.Size = new System.Drawing.Size(132, 29);
            this.wecom1.TabIndex = 61;
            this.wecom1.UseSelectable = true;
            this.wecom1.SelectedIndexChanged += new System.EventHandler(this.wecom1_SelectedIndexChanged);
            // 
            // chart10
            // 
            this.chart10.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            chartArea3.AxisX.TextOrientation = System.Windows.Forms.DataVisualization.Charting.TextOrientation.Rotated90;
            chartArea3.Name = "ChartArea1";
            this.chart10.ChartAreas.Add(chartArea3);
            legend3.Name = "Legend1";
            this.chart10.Legends.Add(legend3);
            this.chart10.Location = new System.Drawing.Point(-12, 77);
            this.chart10.Name = "chart10";
            this.chart10.Size = new System.Drawing.Size(572, 296);
            this.chart10.TabIndex = 58;
            this.chart10.Text = "chart10";
            // 
            // metroLabel51
            // 
            this.metroLabel51.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.metroLabel51.AutoSize = true;
            this.metroLabel51.Location = new System.Drawing.Point(123, 376);
            this.metroLabel51.Name = "metroLabel51";
            this.metroLabel51.Size = new System.Drawing.Size(88, 19);
            this.metroLabel51.TabIndex = 57;
            this.metroLabel51.Text = "metroLabel51";
            // 
            // metroButton3
            // 
            this.metroButton3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.metroButton3.Location = new System.Drawing.Point(566, 294);
            this.metroButton3.Name = "metroButton3";
            this.metroButton3.Size = new System.Drawing.Size(175, 23);
            this.metroButton3.TabIndex = 56;
            this.metroButton3.Text = "Improvement Percentage";
            this.metroButton3.UseSelectable = true;
            this.metroButton3.Click += new System.EventHandler(this.metroButton3_Click);
            // 
            // metroLabel39
            // 
            this.metroLabel39.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.metroLabel39.AutoSize = true;
            this.metroLabel39.Location = new System.Drawing.Point(47, 376);
            this.metroLabel39.Name = "metroLabel39";
            this.metroLabel39.Size = new System.Drawing.Size(70, 19);
            this.metroLabel39.TabIndex = 55;
            this.metroLabel39.Text = "percentile ";
            // 
            // metroLabel40
            // 
            this.metroLabel40.AutoSize = true;
            this.metroLabel40.Location = new System.Drawing.Point(566, 77);
            this.metroLabel40.Name = "metroLabel40";
            this.metroLabel40.Size = new System.Drawing.Size(0, 0);
            this.metroLabel40.TabIndex = 54;
            // 
            // metroLabel41
            // 
            this.metroLabel41.AutoSize = true;
            this.metroLabel41.Location = new System.Drawing.Point(566, 33);
            this.metroLabel41.Name = "metroLabel41";
            this.metroLabel41.Size = new System.Drawing.Size(60, 19);
            this.metroLabel41.TabIndex = 53;
            this.metroLabel41.Text = "Progress";
            // 
            // metroLabel42
            // 
            this.metroLabel42.AutoSize = true;
            this.metroLabel42.Location = new System.Drawing.Point(566, 49);
            this.metroLabel42.Name = "metroLabel42";
            this.metroLabel42.Size = new System.Drawing.Size(71, 19);
            this.metroLabel42.TabIndex = 52;
            this.metroLabel42.Text = "Retrogress";
            // 
            // metroLabel43
            // 
            this.metroLabel43.AutoSize = true;
            this.metroLabel43.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel43.Location = new System.Drawing.Point(580, 14);
            this.metroLabel43.Name = "metroLabel43";
            this.metroLabel43.Size = new System.Drawing.Size(34, 19);
            this.metroLabel43.TabIndex = 51;
            this.metroLabel43.Text = "Key";
            this.metroLabel43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // metroTile8
            // 
            this.metroTile8.ActiveControl = null;
            this.metroTile8.Location = new System.Drawing.Point(677, 39);
            this.metroTile8.Name = "metroTile8";
            this.metroTile8.Size = new System.Drawing.Size(15, 10);
            this.metroTile8.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTile8.TabIndex = 50;
            this.metroTile8.Text = "metroTile8";
            this.metroTile8.UseSelectable = true;
            // 
            // metroTile13
            // 
            this.metroTile13.ActiveControl = null;
            this.metroTile13.Location = new System.Drawing.Point(677, 54);
            this.metroTile13.Name = "metroTile13";
            this.metroTile13.Size = new System.Drawing.Size(15, 10);
            this.metroTile13.Style = MetroFramework.MetroColorStyle.Red;
            this.metroTile13.TabIndex = 49;
            this.metroTile13.Text = "metroTile13";
            this.metroTile13.UseSelectable = true;
            // 
            // circularProgressBar5
            // 
            this.circularProgressBar5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.circularProgressBar5.AnimationFunction = WinFormAnimation.KnownAnimationFunctions.CubicEaseIn;
            this.circularProgressBar5.AnimationSpeed = 500;
            this.circularProgressBar5.BackColor = System.Drawing.Color.Transparent;
            this.circularProgressBar5.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold);
            this.circularProgressBar5.ForeColor = System.Drawing.Color.Black;
            this.circularProgressBar5.InnerColor = System.Drawing.Color.White;
            this.circularProgressBar5.InnerMargin = 2;
            this.circularProgressBar5.InnerWidth = -1;
            this.circularProgressBar5.Location = new System.Drawing.Point(589, 115);
            this.circularProgressBar5.MarqueeAnimationSpeed = 2000;
            this.circularProgressBar5.Name = "circularProgressBar5";
            this.circularProgressBar5.OuterColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.circularProgressBar5.OuterMargin = -25;
            this.circularProgressBar5.OuterWidth = 26;
            this.circularProgressBar5.ProgressColor = System.Drawing.Color.DodgerBlue;
            this.circularProgressBar5.ProgressWidth = 25;
            this.circularProgressBar5.SecondaryFont = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
            this.circularProgressBar5.Size = new System.Drawing.Size(140, 140);
            this.circularProgressBar5.StartAngle = 270;
            this.circularProgressBar5.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.circularProgressBar5.SubscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.circularProgressBar5.SubscriptMargin = new System.Windows.Forms.Padding(10, -35, 0, 0);
            this.circularProgressBar5.SubscriptText = "%";
            this.circularProgressBar5.SuperscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.circularProgressBar5.SuperscriptMargin = new System.Windows.Forms.Padding(10, 35, 0, 0);
            this.circularProgressBar5.SuperscriptText = "";
            this.circularProgressBar5.TabIndex = 48;
            this.circularProgressBar5.Text = "0";
            this.circularProgressBar5.TextMargin = new System.Windows.Forms.Padding(-3, 8, 0, 0);
            this.circularProgressBar5.Value = 1;
            this.circularProgressBar5.Click += new System.EventHandler(this.circularProgressBar5_Click);
            // 
            // circularProgressBar6
            // 
            this.circularProgressBar6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.circularProgressBar6.AnimationFunction = WinFormAnimation.KnownAnimationFunctions.CubicEaseIn;
            this.circularProgressBar6.AnimationSpeed = 500;
            this.circularProgressBar6.BackColor = System.Drawing.Color.Transparent;
            this.circularProgressBar6.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold);
            this.circularProgressBar6.ForeColor = System.Drawing.Color.Black;
            this.circularProgressBar6.InnerColor = System.Drawing.Color.White;
            this.circularProgressBar6.InnerMargin = 2;
            this.circularProgressBar6.InnerWidth = -1;
            this.circularProgressBar6.Location = new System.Drawing.Point(589, 115);
            this.circularProgressBar6.MarqueeAnimationSpeed = 2000;
            this.circularProgressBar6.Name = "circularProgressBar6";
            this.circularProgressBar6.OuterColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.circularProgressBar6.OuterMargin = -25;
            this.circularProgressBar6.OuterWidth = 26;
            this.circularProgressBar6.ProgressColor = System.Drawing.Color.Crimson;
            this.circularProgressBar6.ProgressWidth = 25;
            this.circularProgressBar6.SecondaryFont = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
            this.circularProgressBar6.Size = new System.Drawing.Size(140, 140);
            this.circularProgressBar6.StartAngle = 270;
            this.circularProgressBar6.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.circularProgressBar6.SubscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.circularProgressBar6.SubscriptMargin = new System.Windows.Forms.Padding(10, -35, 0, 0);
            this.circularProgressBar6.SubscriptText = "%";
            this.circularProgressBar6.SuperscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.circularProgressBar6.SuperscriptMargin = new System.Windows.Forms.Padding(10, 35, 0, 0);
            this.circularProgressBar6.SuperscriptText = "";
            this.circularProgressBar6.TabIndex = 47;
            this.circularProgressBar6.Text = "0";
            this.circularProgressBar6.TextMargin = new System.Windows.Forms.Padding(-3, 8, 0, 0);
            this.circularProgressBar6.Value = 10;
            // 
            // metroTabPage11
            // 
            this.metroTabPage11.Controls.Add(this.metroButton6);
            this.metroTabPage11.Controls.Add(this.metroLabel52);
            this.metroTabPage11.Controls.Add(this.metroButton4);
            this.metroTabPage11.Controls.Add(this.metroLabel44);
            this.metroTabPage11.Controls.Add(this.metroLabel45);
            this.metroTabPage11.Controls.Add(this.metroLabel46);
            this.metroTabPage11.Controls.Add(this.metroLabel47);
            this.metroTabPage11.Controls.Add(this.metroLabel48);
            this.metroTabPage11.Controls.Add(this.metroTile15);
            this.metroTabPage11.Controls.Add(this.metroTile16);
            this.metroTabPage11.Controls.Add(this.circularProgressBar7);
            this.metroTabPage11.Controls.Add(this.circularProgressBar8);
            this.metroTabPage11.Controls.Add(this.metroComboBox7);
            this.metroTabPage11.Controls.Add(this.metroComboBox8);
            this.metroTabPage11.Controls.Add(this.chart8);
            this.metroTabPage11.HorizontalScrollbarBarColor = true;
            this.metroTabPage11.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage11.HorizontalScrollbarSize = 10;
            this.metroTabPage11.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage11.Name = "metroTabPage11";
            this.metroTabPage11.Size = new System.Drawing.Size(744, 410);
            this.metroTabPage11.TabIndex = 3;
            this.metroTabPage11.Text = "Interpersonal Skills";
            this.metroTabPage11.VerticalScrollbarBarColor = true;
            this.metroTabPage11.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage11.VerticalScrollbarSize = 10;
            // 
            // metroButton6
            // 
            this.metroButton6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.metroButton6.Location = new System.Drawing.Point(566, 323);
            this.metroButton6.Name = "metroButton6";
            this.metroButton6.Size = new System.Drawing.Size(75, 23);
            this.metroButton6.TabIndex = 73;
            this.metroButton6.Text = "Add";
            this.metroButton6.UseSelectable = true;
            this.metroButton6.Click += new System.EventHandler(this.metroButton6_Click);
            // 
            // metroLabel52
            // 
            this.metroLabel52.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.metroLabel52.AutoSize = true;
            this.metroLabel52.Location = new System.Drawing.Point(123, 376);
            this.metroLabel52.Name = "metroLabel52";
            this.metroLabel52.Size = new System.Drawing.Size(90, 19);
            this.metroLabel52.TabIndex = 72;
            this.metroLabel52.Text = "metroLabel52";
            // 
            // metroButton4
            // 
            this.metroButton4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.metroButton4.Location = new System.Drawing.Point(566, 294);
            this.metroButton4.Name = "metroButton4";
            this.metroButton4.Size = new System.Drawing.Size(175, 23);
            this.metroButton4.TabIndex = 71;
            this.metroButton4.Text = "Improvement Percentage";
            this.metroButton4.UseSelectable = true;
            this.metroButton4.Click += new System.EventHandler(this.metroButton4_Click);
            // 
            // metroLabel44
            // 
            this.metroLabel44.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.metroLabel44.AutoSize = true;
            this.metroLabel44.Location = new System.Drawing.Point(47, 376);
            this.metroLabel44.Name = "metroLabel44";
            this.metroLabel44.Size = new System.Drawing.Size(70, 19);
            this.metroLabel44.TabIndex = 70;
            this.metroLabel44.Text = "percentile ";
            // 
            // metroLabel45
            // 
            this.metroLabel45.AutoSize = true;
            this.metroLabel45.Location = new System.Drawing.Point(566, 77);
            this.metroLabel45.Name = "metroLabel45";
            this.metroLabel45.Size = new System.Drawing.Size(0, 0);
            this.metroLabel45.TabIndex = 69;
            // 
            // metroLabel46
            // 
            this.metroLabel46.AutoSize = true;
            this.metroLabel46.Location = new System.Drawing.Point(566, 33);
            this.metroLabel46.Name = "metroLabel46";
            this.metroLabel46.Size = new System.Drawing.Size(60, 19);
            this.metroLabel46.TabIndex = 68;
            this.metroLabel46.Text = "Progress";
            // 
            // metroLabel47
            // 
            this.metroLabel47.AutoSize = true;
            this.metroLabel47.Location = new System.Drawing.Point(566, 49);
            this.metroLabel47.Name = "metroLabel47";
            this.metroLabel47.Size = new System.Drawing.Size(71, 19);
            this.metroLabel47.TabIndex = 67;
            this.metroLabel47.Text = "Retrogress";
            // 
            // metroLabel48
            // 
            this.metroLabel48.AutoSize = true;
            this.metroLabel48.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel48.Location = new System.Drawing.Point(580, 14);
            this.metroLabel48.Name = "metroLabel48";
            this.metroLabel48.Size = new System.Drawing.Size(34, 19);
            this.metroLabel48.TabIndex = 66;
            this.metroLabel48.Text = "Key";
            this.metroLabel48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // metroTile15
            // 
            this.metroTile15.ActiveControl = null;
            this.metroTile15.Location = new System.Drawing.Point(677, 39);
            this.metroTile15.Name = "metroTile15";
            this.metroTile15.Size = new System.Drawing.Size(15, 10);
            this.metroTile15.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTile15.TabIndex = 65;
            this.metroTile15.Text = "metroTile15";
            this.metroTile15.UseSelectable = true;
            // 
            // metroTile16
            // 
            this.metroTile16.ActiveControl = null;
            this.metroTile16.Location = new System.Drawing.Point(677, 54);
            this.metroTile16.Name = "metroTile16";
            this.metroTile16.Size = new System.Drawing.Size(15, 10);
            this.metroTile16.Style = MetroFramework.MetroColorStyle.Red;
            this.metroTile16.TabIndex = 64;
            this.metroTile16.Text = "metroTile16";
            this.metroTile16.UseSelectable = true;
            // 
            // circularProgressBar7
            // 
            this.circularProgressBar7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.circularProgressBar7.AnimationFunction = WinFormAnimation.KnownAnimationFunctions.CubicEaseIn;
            this.circularProgressBar7.AnimationSpeed = 500;
            this.circularProgressBar7.BackColor = System.Drawing.Color.Transparent;
            this.circularProgressBar7.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold);
            this.circularProgressBar7.ForeColor = System.Drawing.Color.Black;
            this.circularProgressBar7.InnerColor = System.Drawing.Color.White;
            this.circularProgressBar7.InnerMargin = 2;
            this.circularProgressBar7.InnerWidth = -1;
            this.circularProgressBar7.Location = new System.Drawing.Point(589, 115);
            this.circularProgressBar7.MarqueeAnimationSpeed = 2000;
            this.circularProgressBar7.Name = "circularProgressBar7";
            this.circularProgressBar7.OuterColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.circularProgressBar7.OuterMargin = -25;
            this.circularProgressBar7.OuterWidth = 26;
            this.circularProgressBar7.ProgressColor = System.Drawing.Color.DodgerBlue;
            this.circularProgressBar7.ProgressWidth = 25;
            this.circularProgressBar7.SecondaryFont = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
            this.circularProgressBar7.Size = new System.Drawing.Size(140, 140);
            this.circularProgressBar7.StartAngle = 270;
            this.circularProgressBar7.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.circularProgressBar7.SubscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.circularProgressBar7.SubscriptMargin = new System.Windows.Forms.Padding(10, -35, 0, 0);
            this.circularProgressBar7.SubscriptText = "%";
            this.circularProgressBar7.SuperscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.circularProgressBar7.SuperscriptMargin = new System.Windows.Forms.Padding(10, 35, 0, 0);
            this.circularProgressBar7.SuperscriptText = "";
            this.circularProgressBar7.TabIndex = 63;
            this.circularProgressBar7.Text = "0";
            this.circularProgressBar7.TextMargin = new System.Windows.Forms.Padding(-3, 8, 0, 0);
            this.circularProgressBar7.Value = 1;
            // 
            // circularProgressBar8
            // 
            this.circularProgressBar8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.circularProgressBar8.AnimationFunction = WinFormAnimation.KnownAnimationFunctions.CubicEaseIn;
            this.circularProgressBar8.AnimationSpeed = 500;
            this.circularProgressBar8.BackColor = System.Drawing.Color.Transparent;
            this.circularProgressBar8.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold);
            this.circularProgressBar8.ForeColor = System.Drawing.Color.Black;
            this.circularProgressBar8.InnerColor = System.Drawing.Color.White;
            this.circularProgressBar8.InnerMargin = 2;
            this.circularProgressBar8.InnerWidth = -1;
            this.circularProgressBar8.Location = new System.Drawing.Point(589, 115);
            this.circularProgressBar8.MarqueeAnimationSpeed = 2000;
            this.circularProgressBar8.Name = "circularProgressBar8";
            this.circularProgressBar8.OuterColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.circularProgressBar8.OuterMargin = -25;
            this.circularProgressBar8.OuterWidth = 26;
            this.circularProgressBar8.ProgressColor = System.Drawing.Color.Crimson;
            this.circularProgressBar8.ProgressWidth = 25;
            this.circularProgressBar8.SecondaryFont = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
            this.circularProgressBar8.Size = new System.Drawing.Size(140, 140);
            this.circularProgressBar8.StartAngle = 270;
            this.circularProgressBar8.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.circularProgressBar8.SubscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.circularProgressBar8.SubscriptMargin = new System.Windows.Forms.Padding(10, -35, 0, 0);
            this.circularProgressBar8.SubscriptText = "%";
            this.circularProgressBar8.SuperscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.circularProgressBar8.SuperscriptMargin = new System.Windows.Forms.Padding(10, 35, 0, 0);
            this.circularProgressBar8.SuperscriptText = "";
            this.circularProgressBar8.TabIndex = 62;
            this.circularProgressBar8.Text = "0";
            this.circularProgressBar8.TextMargin = new System.Windows.Forms.Padding(-3, 8, 0, 0);
            this.circularProgressBar8.Value = 10;
            // 
            // metroComboBox7
            // 
            this.metroComboBox7.FormattingEnabled = true;
            this.metroComboBox7.ItemHeight = 23;
            this.metroComboBox7.Location = new System.Drawing.Point(316, 23);
            this.metroComboBox7.Name = "metroComboBox7";
            this.metroComboBox7.Size = new System.Drawing.Size(132, 29);
            this.metroComboBox7.TabIndex = 61;
            this.metroComboBox7.UseSelectable = true;
            this.metroComboBox7.SelectedIndexChanged += new System.EventHandler(this.metroComboBox7_SelectedIndexChanged);
            // 
            // metroComboBox8
            // 
            this.metroComboBox8.FormattingEnabled = true;
            this.metroComboBox8.ItemHeight = 23;
            this.metroComboBox8.Items.AddRange(new object[] {
            "2017",
            "2018"});
            this.metroComboBox8.Location = new System.Drawing.Point(18, 23);
            this.metroComboBox8.Name = "metroComboBox8";
            this.metroComboBox8.Size = new System.Drawing.Size(132, 29);
            this.metroComboBox8.TabIndex = 60;
            this.metroComboBox8.UseSelectable = true;
            this.metroComboBox8.SelectedIndexChanged += new System.EventHandler(this.metroComboBox8_SelectedIndexChanged);
            // 
            // chart8
            // 
            this.chart8.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            chartArea4.AxisX.TextOrientation = System.Windows.Forms.DataVisualization.Charting.TextOrientation.Rotated90;
            chartArea4.Name = "ChartArea1";
            this.chart8.ChartAreas.Add(chartArea4);
            legend4.Name = "Legend1";
            this.chart8.Legends.Add(legend4);
            this.chart8.Location = new System.Drawing.Point(-12, 77);
            this.chart8.Name = "chart8";
            this.chart8.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Grayscale;
            this.chart8.Size = new System.Drawing.Size(572, 296);
            this.chart8.TabIndex = 58;
            // 
            // metroTabPage4
            // 
            this.metroTabPage4.Controls.Add(this.metroButton11);
            this.metroTabPage4.Controls.Add(this.metroButton5);
            this.metroTabPage4.Controls.Add(this.metroLabel13);
            this.metroTabPage4.Controls.Add(this.attendanceOfEmployeeDateTime2);
            this.metroTabPage4.Controls.Add(this.attendanceOfEmployeeDateTime);
            this.metroTabPage4.Controls.Add(this.metroLabel12);
            this.metroTabPage4.Controls.Add(this.attendanceDataGrid);
            this.metroTabPage4.HorizontalScrollbarBarColor = true;
            this.metroTabPage4.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage4.HorizontalScrollbarSize = 10;
            this.metroTabPage4.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage4.Name = "metroTabPage4";
            this.metroTabPage4.Size = new System.Drawing.Size(762, 458);
            this.metroTabPage4.TabIndex = 3;
            this.metroTabPage4.Text = "Attendance";
            this.metroTabPage4.VerticalScrollbarBarColor = true;
            this.metroTabPage4.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage4.VerticalScrollbarSize = 10;
            this.metroTabPage4.Click += new System.EventHandler(this.metroTabPage4_Click);
            // 
            // metroButton11
            // 
            this.metroButton11.Location = new System.Drawing.Point(670, 44);
            this.metroButton11.Name = "metroButton11";
            this.metroButton11.Size = new System.Drawing.Size(75, 23);
            this.metroButton11.TabIndex = 13;
            this.metroButton11.Text = "Print";
            this.metroButton11.UseSelectable = true;
            this.metroButton11.Click += new System.EventHandler(this.metroButton11_Click);
            // 
            // metroButton5
            // 
            this.metroButton5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.metroButton5.Location = new System.Drawing.Point(589, 44);
            this.metroButton5.Name = "metroButton5";
            this.metroButton5.Size = new System.Drawing.Size(75, 23);
            this.metroButton5.TabIndex = 12;
            this.metroButton5.Text = "All";
            this.metroButton5.UseSelectable = true;
            this.metroButton5.Click += new System.EventHandler(this.metroButton5_Click);
            // 
            // metroLabel13
            // 
            this.metroLabel13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel13.AutoSize = true;
            this.metroLabel13.Location = new System.Drawing.Point(291, 48);
            this.metroLabel13.Name = "metroLabel13";
            this.metroLabel13.Size = new System.Drawing.Size(64, 19);
            this.metroLabel13.TabIndex = 11;
            this.metroLabel13.Text = "Out Time";
            // 
            // attendanceOfEmployeeDateTime2
            // 
            this.attendanceOfEmployeeDateTime2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.attendanceOfEmployeeDateTime2.Location = new System.Drawing.Point(361, 38);
            this.attendanceOfEmployeeDateTime2.MinimumSize = new System.Drawing.Size(0, 29);
            this.attendanceOfEmployeeDateTime2.Name = "attendanceOfEmployeeDateTime2";
            this.attendanceOfEmployeeDateTime2.Size = new System.Drawing.Size(220, 29);
            this.attendanceOfEmployeeDateTime2.TabIndex = 9;
            this.attendanceOfEmployeeDateTime2.ValueChanged += new System.EventHandler(this.attendanceOfEmployeeDateTime2_ValueChanged);
            // 
            // attendanceOfEmployeeDateTime
            // 
            this.attendanceOfEmployeeDateTime.Location = new System.Drawing.Point(65, 38);
            this.attendanceOfEmployeeDateTime.MinimumSize = new System.Drawing.Size(0, 29);
            this.attendanceOfEmployeeDateTime.Name = "attendanceOfEmployeeDateTime";
            this.attendanceOfEmployeeDateTime.Size = new System.Drawing.Size(220, 29);
            this.attendanceOfEmployeeDateTime.TabIndex = 8;
            this.attendanceOfEmployeeDateTime.ValueChanged += new System.EventHandler(this.metroDateTime1_ValueChanged_1);
            // 
            // metroLabel12
            // 
            this.metroLabel12.AutoSize = true;
            this.metroLabel12.Location = new System.Drawing.Point(7, 48);
            this.metroLabel12.Name = "metroLabel12";
            this.metroLabel12.Size = new System.Drawing.Size(52, 19);
            this.metroLabel12.TabIndex = 7;
            this.metroLabel12.Text = "In Time";
            // 
            // attendanceDataGrid
            // 
            this.attendanceDataGrid.AllowUserToResizeRows = false;
            this.attendanceDataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.attendanceDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.attendanceDataGrid.BackgroundColor = System.Drawing.Color.White;
            this.attendanceDataGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.attendanceDataGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.attendanceDataGrid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.attendanceDataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.attendanceDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.attendanceDataGrid.DefaultCellStyle = dataGridViewCellStyle11;
            this.attendanceDataGrid.EnableHeadersVisualStyles = false;
            this.attendanceDataGrid.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.attendanceDataGrid.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.attendanceDataGrid.Location = new System.Drawing.Point(7, 81);
            this.attendanceDataGrid.Name = "attendanceDataGrid";
            this.attendanceDataGrid.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.attendanceDataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.attendanceDataGrid.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.attendanceDataGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.attendanceDataGrid.Size = new System.Drawing.Size(738, 304);
            this.attendanceDataGrid.TabIndex = 5;
            this.attendanceDataGrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.attendanceDataGrid_CellContentClick);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(23, 60);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(117, 19);
            this.metroLabel1.TabIndex = 2;
            this.metroLabel1.Text = "Employee number";
            // 
            // shortComingsTimer
            // 
            this.shortComingsTimer.Enabled = true;
            this.shortComingsTimer.Interval = 2000;
            this.shortComingsTimer.Tick += new System.EventHandler(this.shortComingsTimer_Tick);
            // 
            // EvaluateEmployeeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 600);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.metroTabControl1);
            this.Name = "EvaluateEmployeeForm";
            this.Text = "Employee name";
            this.Load += new System.EventHandler(this.EvaluateEmployeeForm_Load);
            this.metroTabControl1.ResumeLayout(false);
            this.metroTabPage1.ResumeLayout(false);
            this.metroTabControl2.ResumeLayout(false);
            this.metroTabPage5.ResumeLayout(false);
            this.metroTabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataGrid)).EndInit();
            this.metroTabPage6.ResumeLayout(false);
            this.metroTabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tasksDataGrid)).EndInit();
            this.metroTabPage7.ResumeLayout(false);
            this.metroTabPage7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.projectShortcomingsGrid)).EndInit();
            this.metroTabPage2.ResumeLayout(false);
            this.metroTabControl3.ResumeLayout(false);
            this.metroTabPage8.ResumeLayout(false);
            this.metroTabPage8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).EndInit();
            this.metroTabPage9.ResumeLayout(false);
            this.metroTabPage9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).EndInit();
            this.metroTabPage10.ResumeLayout(false);
            this.metroTabPage10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart10)).EndInit();
            this.metroTabPage11.ResumeLayout(false);
            this.metroTabPage11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart8)).EndInit();
            this.metroTabPage4.ResumeLayout(false);
            this.metroTabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.attendanceDataGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroTabControl metroTabControl1;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroTabPage metroTabPage1;
        private MetroFramework.Controls.MetroTabControl metroTabControl2;
        private MetroFramework.Controls.MetroTabPage metroTabPage5;
        private MetroFramework.Controls.MetroTabPage metroTabPage6;
        private MetroFramework.Controls.MetroTabPage metroTabPage7;
        private MetroFramework.Controls.MetroGrid projectShortcomingsGrid;
        private MetroFramework.Controls.MetroTabPage metroTabPage2;
        private MetroFramework.Controls.MetroTabPage metroTabPage4;
        private MetroFramework.Controls.MetroTextBox searchProjectTxtBox;
        private MetroFramework.Controls.MetroDateTime startEventDateTime;
        private MetroFramework.Controls.MetroGrid projectDataGrid;
        private MetroFramework.Controls.MetroTextBox eventTxtbox1;
        private MetroFramework.Controls.MetroLabel metroLabel20;
        private MetroFramework.Controls.MetroGrid tasksDataGrid;
        private MetroFramework.Controls.MetroTabControl metroTabControl3;
        private MetroFramework.Controls.MetroTabPage metroTabPage8;
        private MetroFramework.Controls.MetroTabPage metroTabPage9;
        private MetroFramework.Controls.MetroTabPage metroTabPage11;
        private MetroFramework.Controls.MetroGrid attendanceDataGrid;
        private CircularProgressBar.CircularProgressBar circularProgressBar1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart2;
        private MetroFramework.Controls.MetroLabel metroLabel21;
        private MetroFramework.Controls.MetroComboBox metroComboBox1;
        private MetroFramework.Controls.MetroComboBox metroComboBox2;
        private MetroFramework.Controls.MetroButton metroButton1;
        private MetroFramework.Controls.MetroLabel metroLabel25;
        private MetroFramework.Controls.MetroLabel metroLabel26;
        private MetroFramework.Controls.MetroLabel metroLabel24;
        private MetroFramework.Controls.MetroLabel metroLabel27;
        private CircularProgressBar.CircularProgressBar circularProgressBar2;
        private MetroFramework.Controls.MetroLabel metroLabel30;
        private MetroFramework.Controls.MetroLabel metroLabel29;
        private MetroFramework.Controls.MetroLabel metroLabel28;
        private MetroFramework.Controls.MetroTile metroTile10;
        private MetroFramework.Controls.MetroTile metroTile4;
        private MetroFramework.Controls.MetroLabel metroLabel34;
        private MetroFramework.Controls.MetroLabel metroLabel35;
        private MetroFramework.Controls.MetroLabel metroLabel36;
        private MetroFramework.Controls.MetroLabel metroLabel37;
        private MetroFramework.Controls.MetroTile metroTile11;
        private MetroFramework.Controls.MetroTile metroTile12;
        private CircularProgressBar.CircularProgressBar circularProgressBar3;
        private CircularProgressBar.CircularProgressBar circularProgressBar4;
        private MetroFramework.Controls.MetroComboBox metroComboBox3;
        private MetroFramework.Controls.MetroComboBox metroComboBox4;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart3;
        private MetroFramework.Controls.MetroButton metroButton2;
        private MetroFramework.Controls.MetroLabel metroLabel38;
        private MetroFramework.Controls.MetroTabPage metroTabPage10;
        private MetroFramework.Controls.MetroButton metroButton3;
        private MetroFramework.Controls.MetroLabel metroLabel39;
        private MetroFramework.Controls.MetroLabel metroLabel40;
        private MetroFramework.Controls.MetroLabel metroLabel41;
        private MetroFramework.Controls.MetroLabel metroLabel42;
        private MetroFramework.Controls.MetroLabel metroLabel43;
        private MetroFramework.Controls.MetroTile metroTile8;
        private MetroFramework.Controls.MetroTile metroTile13;
        private CircularProgressBar.CircularProgressBar circularProgressBar5;
        private CircularProgressBar.CircularProgressBar circularProgressBar6;
        private MetroFramework.Controls.MetroButton metroButton4;
        private MetroFramework.Controls.MetroLabel metroLabel44;
        private MetroFramework.Controls.MetroLabel metroLabel46;
        private MetroFramework.Controls.MetroLabel metroLabel47;
        private MetroFramework.Controls.MetroLabel metroLabel48;
        private MetroFramework.Controls.MetroTile metroTile15;
        private MetroFramework.Controls.MetroTile metroTile16;
        private CircularProgressBar.CircularProgressBar circularProgressBar7;
        private CircularProgressBar.CircularProgressBar circularProgressBar8;
        private MetroFramework.Controls.MetroComboBox metroComboBox7;
        private MetroFramework.Controls.MetroComboBox metroComboBox8;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart8;
        private MetroFramework.Controls.MetroLabel metroLabel50;
        private MetroFramework.Controls.MetroLabel metroLabel51;
        private MetroFramework.Controls.MetroTile metroTile20;
        private MetroFramework.Controls.MetroTile metroTile19;
        private MetroFramework.Controls.MetroTile metroTile18;
        private MetroFramework.Controls.MetroTextBox EventIdTxtbox;
        private MetroFramework.Controls.MetroTextBox projectIdTxtbox;
        private MetroFramework.Controls.MetroLabel metroLabel16;
        private MetroFramework.Controls.MetroTextBox descriptionTxtbox;
        private MetroFramework.Controls.MetroLabel metroLabel15;
        private MetroFramework.Controls.MetroLabel metroLabel14;
        private MetroFramework.Controls.MetroLabel gradeETaskLbl;
        private MetroFramework.Controls.MetroLabel gradeDTaskLbl;
        private MetroFramework.Controls.MetroLabel gradeCTaskLbl;
        private MetroFramework.Controls.MetroLabel gradeBTaskLbl;
        private MetroFramework.Controls.MetroLabel gradeATaskLbl;
        private MetroFramework.Controls.MetroLink metroLink6;
        private MetroFramework.Controls.MetroLink metroLink7;
        private MetroFramework.Controls.MetroLink metroLink8;
        private MetroFramework.Controls.MetroLink metroLink9;
        private MetroFramework.Controls.MetroLink metroLink10;
        private MetroFramework.Controls.MetroLabel metroLabel53;
        private MetroFramework.Controls.MetroLabel metroLabel54;
        private MetroFramework.Controls.MetroDateTime deadlineDateTime;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroTextBox eventTxtbox;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroTextBox searchProjectTxtBox1;
        private MetroFramework.Controls.MetroLabel EventId;
        private MetroFramework.Controls.MetroLabel metroLabel52;
        private MetroFramework.Controls.MetroLabel metroLabel45;
        private MetroFramework.Controls.MetroTile metroTile21;
        private MetroFramework.Controls.MetroDateTime attendanceOfEmployeeDateTime;
        private MetroFramework.Controls.MetroLabel metroLabel12;
        private MetroFramework.Controls.MetroDateTime attendanceOfEmployeeDateTime2;
        private MetroFramework.Controls.MetroLabel metroLabel13;
        private System.Windows.Forms.Timer shortComingsTimer;
        private MetroFramework.Controls.MetroButton metroButton5;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart10;
        private MetroFramework.Controls.MetroComboBox wecom2;
        private MetroFramework.Controls.MetroComboBox wecom1;
        private MetroFramework.Controls.MetroLabel metroLabel32;
        private MetroFramework.Controls.MetroButton metroButton6;
        private MetroFramework.Controls.MetroButton metroButton7;
        private MetroFramework.Controls.MetroButton metroButton8;
        private MetroFramework.Controls.MetroButton metroButton9;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroButton metroButton10;
        private MetroFramework.Controls.MetroButton metroButton11;
    }
}