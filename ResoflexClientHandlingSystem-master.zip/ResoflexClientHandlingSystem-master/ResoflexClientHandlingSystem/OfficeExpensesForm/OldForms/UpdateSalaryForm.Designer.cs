﻿namespace ResoflexClientHandlingSystem.OfficeExpensesForm
{
    partial class UpdateSalaryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.empid = new MetroFramework.Controls.MetroComboBox();
            this.etf = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.allowance = new MetroFramework.Controls.MetroTextBox();
            this.hours = new MetroFramework.Controls.MetroTextBox();
            this.rate = new MetroFramework.Controls.MetroTextBox();
            this.basicsal = new MetroFramework.Controls.MetroTextBox();
            this.Gsal = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.add = new MetroFramework.Controls.MetroButton();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroTextBox13 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox12 = new MetroFramework.Controls.MetroTextBox();
            this.netSal = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel15 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel14 = new MetroFramework.Controls.MetroLabel();
            this.SuspendLayout();
            // 
            // empid
            // 
            this.empid.FormattingEnabled = true;
            this.empid.ItemHeight = 23;
            this.empid.Location = new System.Drawing.Point(228, 106);
            this.empid.Name = "empid";
            this.empid.Size = new System.Drawing.Size(200, 29);
            this.empid.TabIndex = 46;
            this.empid.UseSelectable = true;
            // 
            // etf
            // 
            // 
            // 
            // 
            this.etf.CustomButton.Image = null;
            this.etf.CustomButton.Location = new System.Drawing.Point(131, 1);
            this.etf.CustomButton.Name = "";
            this.etf.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.etf.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.etf.CustomButton.TabIndex = 1;
            this.etf.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.etf.CustomButton.UseSelectable = true;
            this.etf.CustomButton.Visible = false;
            this.etf.Lines = new string[0];
            this.etf.Location = new System.Drawing.Point(533, 137);
            this.etf.MaxLength = 32767;
            this.etf.Name = "etf";
            this.etf.PasswordChar = '\0';
            this.etf.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.etf.SelectedText = "";
            this.etf.SelectionLength = 0;
            this.etf.SelectionStart = 0;
            this.etf.ShortcutsEnabled = true;
            this.etf.Size = new System.Drawing.Size(153, 23);
            this.etf.TabIndex = 45;
            this.etf.UseSelectable = true;
            this.etf.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.etf.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.Location = new System.Drawing.Point(470, 137);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(48, 19);
            this.metroLabel10.TabIndex = 44;
            this.metroLabel10.Text = "Etf/Epf";
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.Location = new System.Drawing.Point(458, 99);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(184, 19);
            this.metroLabel9.TabIndex = 43;
            this.metroLabel9.Text = "DEDUCTION OF THE SALARY";
            // 
            // allowance
            // 
            // 
            // 
            // 
            this.allowance.CustomButton.Image = null;
            this.allowance.CustomButton.Location = new System.Drawing.Point(178, 1);
            this.allowance.CustomButton.Name = "";
            this.allowance.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.allowance.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.allowance.CustomButton.TabIndex = 1;
            this.allowance.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.allowance.CustomButton.UseSelectable = true;
            this.allowance.CustomButton.Visible = false;
            this.allowance.Lines = new string[0];
            this.allowance.Location = new System.Drawing.Point(228, 274);
            this.allowance.MaxLength = 32767;
            this.allowance.Name = "allowance";
            this.allowance.PasswordChar = '\0';
            this.allowance.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.allowance.SelectedText = "";
            this.allowance.SelectionLength = 0;
            this.allowance.SelectionStart = 0;
            this.allowance.ShortcutsEnabled = true;
            this.allowance.Size = new System.Drawing.Size(200, 23);
            this.allowance.TabIndex = 42;
            this.allowance.UseSelectable = true;
            this.allowance.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.allowance.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // hours
            // 
            // 
            // 
            // 
            this.hours.CustomButton.Image = null;
            this.hours.CustomButton.Location = new System.Drawing.Point(178, 1);
            this.hours.CustomButton.Name = "";
            this.hours.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.hours.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.hours.CustomButton.TabIndex = 1;
            this.hours.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.hours.CustomButton.UseSelectable = true;
            this.hours.CustomButton.Visible = false;
            this.hours.Lines = new string[0];
            this.hours.Location = new System.Drawing.Point(228, 217);
            this.hours.MaxLength = 32767;
            this.hours.Name = "hours";
            this.hours.PasswordChar = '\0';
            this.hours.ReadOnly = true;
            this.hours.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.hours.SelectedText = "";
            this.hours.SelectionLength = 0;
            this.hours.SelectionStart = 0;
            this.hours.ShortcutsEnabled = true;
            this.hours.Size = new System.Drawing.Size(200, 23);
            this.hours.TabIndex = 41;
            this.hours.UseSelectable = true;
            this.hours.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.hours.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // rate
            // 
            // 
            // 
            // 
            this.rate.CustomButton.Image = null;
            this.rate.CustomButton.Location = new System.Drawing.Point(178, 1);
            this.rate.CustomButton.Name = "";
            this.rate.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.rate.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.rate.CustomButton.TabIndex = 1;
            this.rate.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.rate.CustomButton.UseSelectable = true;
            this.rate.CustomButton.Visible = false;
            this.rate.Lines = new string[0];
            this.rate.Location = new System.Drawing.Point(228, 174);
            this.rate.MaxLength = 32767;
            this.rate.Name = "rate";
            this.rate.PasswordChar = '\0';
            this.rate.ReadOnly = true;
            this.rate.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.rate.SelectedText = "";
            this.rate.SelectionLength = 0;
            this.rate.SelectionStart = 0;
            this.rate.ShortcutsEnabled = true;
            this.rate.Size = new System.Drawing.Size(200, 23);
            this.rate.TabIndex = 40;
            this.rate.UseSelectable = true;
            this.rate.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.rate.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // basicsal
            // 
            // 
            // 
            // 
            this.basicsal.CustomButton.Image = null;
            this.basicsal.CustomButton.Location = new System.Drawing.Point(178, 1);
            this.basicsal.CustomButton.Name = "";
            this.basicsal.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.basicsal.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.basicsal.CustomButton.TabIndex = 1;
            this.basicsal.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.basicsal.CustomButton.UseSelectable = true;
            this.basicsal.CustomButton.Visible = false;
            this.basicsal.Lines = new string[0];
            this.basicsal.Location = new System.Drawing.Point(228, 141);
            this.basicsal.MaxLength = 32767;
            this.basicsal.Name = "basicsal";
            this.basicsal.PasswordChar = '\0';
            this.basicsal.ReadOnly = true;
            this.basicsal.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.basicsal.SelectedText = "";
            this.basicsal.SelectionLength = 0;
            this.basicsal.SelectionStart = 0;
            this.basicsal.ShortcutsEnabled = true;
            this.basicsal.Size = new System.Drawing.Size(200, 23);
            this.basicsal.TabIndex = 39;
            this.basicsal.UseSelectable = true;
            this.basicsal.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.basicsal.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Gsal
            // 
            // 
            // 
            // 
            this.Gsal.CustomButton.Image = null;
            this.Gsal.CustomButton.Location = new System.Drawing.Point(178, 1);
            this.Gsal.CustomButton.Name = "";
            this.Gsal.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.Gsal.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Gsal.CustomButton.TabIndex = 1;
            this.Gsal.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Gsal.CustomButton.UseSelectable = true;
            this.Gsal.CustomButton.Visible = false;
            this.Gsal.Lines = new string[0];
            this.Gsal.Location = new System.Drawing.Point(228, 329);
            this.Gsal.MaxLength = 32767;
            this.Gsal.Name = "Gsal";
            this.Gsal.PasswordChar = '\0';
            this.Gsal.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Gsal.SelectedText = "";
            this.Gsal.SelectionLength = 0;
            this.Gsal.SelectionStart = 0;
            this.Gsal.ShortcutsEnabled = true;
            this.Gsal.Size = new System.Drawing.Size(200, 23);
            this.Gsal.TabIndex = 38;
            this.Gsal.UseSelectable = true;
            this.Gsal.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Gsal.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(131, 278);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(73, 19);
            this.metroLabel8.TabIndex = 37;
            this.metroLabel8.Text = "Allowances";
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(126, 333);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(79, 19);
            this.metroLabel7.TabIndex = 36;
            this.metroLabel7.Text = "Gross salary";
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(157, 221);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(47, 19);
            this.metroLabel5.TabIndex = 35;
            this.metroLabel5.Text = "Hours ";
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(114, 174);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(90, 19);
            this.metroLabel4.TabIndex = 34;
            this.metroLabel4.Text = "Rate per hour";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(126, 141);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(78, 19);
            this.metroLabel3.TabIndex = 33;
            this.metroLabel3.Text = "Basic Salary";
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(122, 106);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(82, 19);
            this.metroLabel1.TabIndex = 32;
            this.metroLabel1.Text = "Employee id";
            // 
            // add
            // 
            this.add.Location = new System.Drawing.Point(126, 487);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(75, 23);
            this.add.TabIndex = 55;
            this.add.Text = "Update";
            this.add.UseSelectable = true;
            this.add.Click += new System.EventHandler(this.add_Click);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(404, 418);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(81, 19);
            this.metroLabel2.TabIndex = 53;
            this.metroLabel2.Text = "Gross Salary";
            // 
            // metroTextBox13
            // 
            // 
            // 
            // 
            this.metroTextBox13.CustomButton.Image = null;
            this.metroTextBox13.CustomButton.Location = new System.Drawing.Point(131, 1);
            this.metroTextBox13.CustomButton.Name = "";
            this.metroTextBox13.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.metroTextBox13.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox13.CustomButton.TabIndex = 1;
            this.metroTextBox13.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox13.CustomButton.UseSelectable = true;
            this.metroTextBox13.CustomButton.Visible = false;
            this.metroTextBox13.Lines = new string[0];
            this.metroTextBox13.Location = new System.Drawing.Point(502, 451);
            this.metroTextBox13.MaxLength = 32767;
            this.metroTextBox13.Name = "metroTextBox13";
            this.metroTextBox13.PasswordChar = '\0';
            this.metroTextBox13.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox13.SelectedText = "";
            this.metroTextBox13.SelectionLength = 0;
            this.metroTextBox13.SelectionStart = 0;
            this.metroTextBox13.ShortcutsEnabled = true;
            this.metroTextBox13.Size = new System.Drawing.Size(153, 23);
            this.metroTextBox13.TabIndex = 51;
            this.metroTextBox13.UseSelectable = true;
            this.metroTextBox13.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox13.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroTextBox12
            // 
            // 
            // 
            // 
            this.metroTextBox12.CustomButton.Image = null;
            this.metroTextBox12.CustomButton.Location = new System.Drawing.Point(131, 1);
            this.metroTextBox12.CustomButton.Name = "";
            this.metroTextBox12.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.metroTextBox12.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox12.CustomButton.TabIndex = 1;
            this.metroTextBox12.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox12.CustomButton.UseSelectable = true;
            this.metroTextBox12.CustomButton.Visible = false;
            this.metroTextBox12.Lines = new string[0];
            this.metroTextBox12.Location = new System.Drawing.Point(502, 414);
            this.metroTextBox12.MaxLength = 32767;
            this.metroTextBox12.Name = "metroTextBox12";
            this.metroTextBox12.PasswordChar = '\0';
            this.metroTextBox12.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox12.SelectedText = "";
            this.metroTextBox12.SelectionLength = 0;
            this.metroTextBox12.SelectionStart = 0;
            this.metroTextBox12.ShortcutsEnabled = true;
            this.metroTextBox12.Size = new System.Drawing.Size(153, 23);
            this.metroTextBox12.TabIndex = 50;
            this.metroTextBox12.UseSelectable = true;
            this.metroTextBox12.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox12.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // netSal
            // 
            // 
            // 
            // 
            this.netSal.CustomButton.Image = null;
            this.netSal.CustomButton.Location = new System.Drawing.Point(131, 1);
            this.netSal.CustomButton.Name = "";
            this.netSal.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.netSal.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.netSal.CustomButton.TabIndex = 1;
            this.netSal.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.netSal.CustomButton.UseSelectable = true;
            this.netSal.CustomButton.Visible = false;
            this.netSal.Lines = new string[0];
            this.netSal.Location = new System.Drawing.Point(502, 508);
            this.netSal.MaxLength = 32767;
            this.netSal.Name = "netSal";
            this.netSal.PasswordChar = '\0';
            this.netSal.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.netSal.SelectedText = "";
            this.netSal.SelectionLength = 0;
            this.netSal.SelectionStart = 0;
            this.netSal.ShortcutsEnabled = true;
            this.netSal.Size = new System.Drawing.Size(153, 23);
            this.netSal.TabIndex = 49;
            this.netSal.UseSelectable = true;
            this.netSal.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.netSal.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel15
            // 
            this.metroLabel15.AutoSize = true;
            this.metroLabel15.Location = new System.Drawing.Point(417, 508);
            this.metroLabel15.Name = "metroLabel15";
            this.metroLabel15.Size = new System.Drawing.Size(70, 19);
            this.metroLabel15.TabIndex = 48;
            this.metroLabel15.Text = "Net Salary";
            // 
            // metroLabel14
            // 
            this.metroLabel14.AutoSize = true;
            this.metroLabel14.Location = new System.Drawing.Point(417, 451);
            this.metroLabel14.Name = "metroLabel14";
            this.metroLabel14.Size = new System.Drawing.Size(68, 19);
            this.metroLabel14.TabIndex = 47;
            this.metroLabel14.Text = "Deduction";
            // 
            // UpdateSalaryForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 600);
            this.Controls.Add(this.add);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.metroTextBox13);
            this.Controls.Add(this.metroTextBox12);
            this.Controls.Add(this.netSal);
            this.Controls.Add(this.metroLabel15);
            this.Controls.Add(this.metroLabel14);
            this.Controls.Add(this.empid);
            this.Controls.Add(this.etf);
            this.Controls.Add(this.metroLabel10);
            this.Controls.Add(this.metroLabel9);
            this.Controls.Add(this.allowance);
            this.Controls.Add(this.hours);
            this.Controls.Add(this.rate);
            this.Controls.Add(this.basicsal);
            this.Controls.Add(this.Gsal);
            this.Controls.Add(this.metroLabel8);
            this.Controls.Add(this.metroLabel7);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.metroLabel1);
            this.MinimumSize = new System.Drawing.Size(800, 600);
            this.Name = "UpdateSalaryForm";
            this.Text = "Update Salary";
            this.Load += new System.EventHandler(this.UpdateSalaryForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroComboBox empid;
        private MetroFramework.Controls.MetroTextBox etf;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MetroFramework.Controls.MetroTextBox allowance;
        private MetroFramework.Controls.MetroTextBox hours;
        private MetroFramework.Controls.MetroTextBox rate;
        private MetroFramework.Controls.MetroTextBox basicsal;
        private MetroFramework.Controls.MetroTextBox Gsal;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroButton add;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroTextBox metroTextBox13;
        private MetroFramework.Controls.MetroTextBox metroTextBox12;
        private MetroFramework.Controls.MetroTextBox netSal;
        private MetroFramework.Controls.MetroLabel metroLabel15;
        private MetroFramework.Controls.MetroLabel metroLabel14;
    }
}