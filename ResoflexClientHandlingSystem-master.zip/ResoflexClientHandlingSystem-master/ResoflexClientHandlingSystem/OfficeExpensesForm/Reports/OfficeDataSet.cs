﻿namespace ResoflexClientHandlingSystem.OfficeExpensesForm.Reports
{
}

namespace ResoflexClientHandlingSystem.OfficeExpensesForm.Reports
{


    public partial class OfficeDataSet
    {
    }
}
namespace ResoflexClientHandlingSystem.OfficeExpensesForm.Reports {
    
    
    public partial class OfficeDataSet {
    }
}
