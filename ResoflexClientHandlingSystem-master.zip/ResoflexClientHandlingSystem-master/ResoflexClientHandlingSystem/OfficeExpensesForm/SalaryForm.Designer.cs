﻿namespace ResoflexClientHandlingSystem
{
    partial class SalaryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.Gsal = new MetroFramework.Controls.MetroTextBox();
            this.basicsal = new MetroFramework.Controls.MetroTextBox();
            this.rate = new MetroFramework.Controls.MetroTextBox();
            this.hours = new MetroFramework.Controls.MetroTextBox();
            this.allowance = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel14 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel15 = new MetroFramework.Controls.MetroLabel();
            this.netSal = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox12 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox13 = new MetroFramework.Controls.MetroTextBox();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.add = new MetroFramework.Controls.MetroButton();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroTextBox1 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox2 = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.metroButton3 = new MetroFramework.Controls.MetroButton();
            this.empid = new MetroFramework.Controls.MetroTextBox();
            this.metroComboBox1 = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel12 = new MetroFramework.Controls.MetroLabel();
            this.SuspendLayout();
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel1.Location = new System.Drawing.Point(43, 101);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(68, 19);
            this.metroLabel1.TabIndex = 0;
            this.metroLabel1.Text = "Employee";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel3.Location = new System.Drawing.Point(43, 167);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(79, 19);
            this.metroLabel3.TabIndex = 2;
            this.metroLabel3.Text = "Basic Salary";
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel4.Location = new System.Drawing.Point(418, 209);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(93, 19);
            this.metroLabel4.TabIndex = 3;
            this.metroLabel4.Text = "Rate per hour";
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel5.Location = new System.Drawing.Point(418, 165);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(50, 19);
            this.metroLabel5.TabIndex = 4;
            this.metroLabel5.Text = "Hours ";
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(43, 380);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(79, 19);
            this.metroLabel7.TabIndex = 6;
            this.metroLabel7.Text = "Gross salary";
            this.metroLabel7.Visible = false;
            this.metroLabel7.Click += new System.EventHandler(this.metroLabel7_Click);
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel8.Location = new System.Drawing.Point(43, 213);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(76, 19);
            this.metroLabel8.TabIndex = 7;
            this.metroLabel8.Text = "Allowances";
            // 
            // Gsal
            // 
            // 
            // 
            // 
            this.Gsal.CustomButton.Image = null;
            this.Gsal.CustomButton.Location = new System.Drawing.Point(178, 1);
            this.Gsal.CustomButton.Name = "";
            this.Gsal.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.Gsal.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Gsal.CustomButton.TabIndex = 1;
            this.Gsal.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Gsal.CustomButton.UseSelectable = true;
            this.Gsal.CustomButton.Visible = false;
            this.Gsal.Enabled = false;
            this.Gsal.Lines = new string[0];
            this.Gsal.Location = new System.Drawing.Point(137, 380);
            this.Gsal.MaxLength = 32767;
            this.Gsal.Name = "Gsal";
            this.Gsal.PasswordChar = '\0';
            this.Gsal.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Gsal.SelectedText = "";
            this.Gsal.SelectionLength = 0;
            this.Gsal.SelectionStart = 0;
            this.Gsal.ShortcutsEnabled = true;
            this.Gsal.Size = new System.Drawing.Size(200, 23);
            this.Gsal.TabIndex = 10;
            this.Gsal.UseSelectable = true;
            this.Gsal.Visible = false;
            this.Gsal.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Gsal.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.Gsal.Click += new System.EventHandler(this.metroTextBox3_Click);
            // 
            // basicsal
            // 
            // 
            // 
            // 
            this.basicsal.CustomButton.Image = null;
            this.basicsal.CustomButton.Location = new System.Drawing.Point(178, 1);
            this.basicsal.CustomButton.Name = "";
            this.basicsal.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.basicsal.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.basicsal.CustomButton.TabIndex = 1;
            this.basicsal.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.basicsal.CustomButton.UseSelectable = true;
            this.basicsal.CustomButton.Visible = false;
            this.basicsal.Enabled = false;
            this.basicsal.Lines = new string[0];
            this.basicsal.Location = new System.Drawing.Point(137, 163);
            this.basicsal.MaxLength = 32767;
            this.basicsal.Name = "basicsal";
            this.basicsal.PasswordChar = '\0';
            this.basicsal.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.basicsal.SelectedText = "";
            this.basicsal.SelectionLength = 0;
            this.basicsal.SelectionStart = 0;
            this.basicsal.ShortcutsEnabled = true;
            this.basicsal.Size = new System.Drawing.Size(200, 23);
            this.basicsal.TabIndex = 11;
            this.basicsal.UseSelectable = true;
            this.basicsal.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.basicsal.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.basicsal.Click += new System.EventHandler(this.metroTextBox4_Click);
            // 
            // rate
            // 
            // 
            // 
            // 
            this.rate.CustomButton.Image = null;
            this.rate.CustomButton.Location = new System.Drawing.Point(178, 1);
            this.rate.CustomButton.Name = "";
            this.rate.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.rate.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.rate.CustomButton.TabIndex = 1;
            this.rate.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.rate.CustomButton.UseSelectable = true;
            this.rate.CustomButton.Visible = false;
            this.rate.Enabled = false;
            this.rate.Lines = new string[0];
            this.rate.Location = new System.Drawing.Point(512, 205);
            this.rate.MaxLength = 32767;
            this.rate.Name = "rate";
            this.rate.PasswordChar = '\0';
            this.rate.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.rate.SelectedText = "";
            this.rate.SelectionLength = 0;
            this.rate.SelectionStart = 0;
            this.rate.ShortcutsEnabled = true;
            this.rate.Size = new System.Drawing.Size(200, 23);
            this.rate.TabIndex = 12;
            this.rate.UseSelectable = true;
            this.rate.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.rate.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // hours
            // 
            // 
            // 
            // 
            this.hours.CustomButton.Image = null;
            this.hours.CustomButton.Location = new System.Drawing.Point(178, 1);
            this.hours.CustomButton.Name = "";
            this.hours.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.hours.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.hours.CustomButton.TabIndex = 1;
            this.hours.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.hours.CustomButton.UseSelectable = true;
            this.hours.CustomButton.Visible = false;
            this.hours.Enabled = false;
            this.hours.Lines = new string[0];
            this.hours.Location = new System.Drawing.Point(512, 161);
            this.hours.MaxLength = 32767;
            this.hours.Name = "hours";
            this.hours.PasswordChar = '\0';
            this.hours.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.hours.SelectedText = "";
            this.hours.SelectionLength = 0;
            this.hours.SelectionStart = 0;
            this.hours.ShortcutsEnabled = true;
            this.hours.Size = new System.Drawing.Size(200, 23);
            this.hours.TabIndex = 13;
            this.hours.UseSelectable = true;
            this.hours.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.hours.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // allowance
            // 
            // 
            // 
            // 
            this.allowance.CustomButton.Image = null;
            this.allowance.CustomButton.Location = new System.Drawing.Point(178, 1);
            this.allowance.CustomButton.Name = "";
            this.allowance.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.allowance.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.allowance.CustomButton.TabIndex = 1;
            this.allowance.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.allowance.CustomButton.UseSelectable = true;
            this.allowance.CustomButton.Visible = false;
            this.allowance.Lines = new string[0];
            this.allowance.Location = new System.Drawing.Point(137, 209);
            this.allowance.MaxLength = 32767;
            this.allowance.Name = "allowance";
            this.allowance.PasswordChar = '\0';
            this.allowance.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.allowance.SelectedText = "";
            this.allowance.SelectionLength = 0;
            this.allowance.SelectionStart = 0;
            this.allowance.ShortcutsEnabled = true;
            this.allowance.Size = new System.Drawing.Size(200, 23);
            this.allowance.TabIndex = 15;
            this.allowance.UseSelectable = true;
            this.allowance.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.allowance.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.allowance.TextChanged += new System.EventHandler(this.allowance_TextChanged);
            this.allowance.Click += new System.EventHandler(this.allowance_Click);
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel10.Location = new System.Drawing.Point(43, 266);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(31, 19);
            this.metroLabel10.TabIndex = 18;
            this.metroLabel10.Text = "EPF";
            // 
            // metroLabel14
            // 
            this.metroLabel14.AutoSize = true;
            this.metroLabel14.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel14.Location = new System.Drawing.Point(418, 101);
            this.metroLabel14.Name = "metroLabel14";
            this.metroLabel14.Size = new System.Drawing.Size(72, 19);
            this.metroLabel14.TabIndex = 25;
            this.metroLabel14.Text = "Deduction";
            // 
            // metroLabel15
            // 
            this.metroLabel15.AutoSize = true;
            this.metroLabel15.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel15.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel15.Location = new System.Drawing.Point(422, 368);
            this.metroLabel15.Name = "metroLabel15";
            this.metroLabel15.Size = new System.Drawing.Size(101, 25);
            this.metroLabel15.TabIndex = 26;
            this.metroLabel15.Text = "Net Salary";
            this.metroLabel15.Click += new System.EventHandler(this.metroLabel15_Click);
            // 
            // netSal
            // 
            // 
            // 
            // 
            this.netSal.CustomButton.Image = null;
            this.netSal.CustomButton.Location = new System.Drawing.Point(145, 1);
            this.netSal.CustomButton.Name = "";
            this.netSal.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.netSal.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.netSal.CustomButton.TabIndex = 1;
            this.netSal.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.netSal.CustomButton.UseSelectable = true;
            this.netSal.CustomButton.Visible = false;
            this.netSal.Enabled = false;
            this.netSal.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.netSal.FontWeight = MetroFramework.MetroTextBoxWeight.Bold;
            this.netSal.Lines = new string[0];
            this.netSal.Location = new System.Drawing.Point(567, 364);
            this.netSal.MaxLength = 32767;
            this.netSal.Multiline = true;
            this.netSal.Name = "netSal";
            this.netSal.PasswordChar = '\0';
            this.netSal.ReadOnly = true;
            this.netSal.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.netSal.SelectedText = "";
            this.netSal.SelectionLength = 0;
            this.netSal.SelectionStart = 0;
            this.netSal.ShortcutsEnabled = true;
            this.netSal.Size = new System.Drawing.Size(150, 37);
            this.netSal.TabIndex = 27;
            this.netSal.UseSelectable = true;
            this.netSal.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.netSal.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroTextBox12
            // 
            // 
            // 
            // 
            this.metroTextBox12.CustomButton.Image = null;
            this.metroTextBox12.CustomButton.Location = new System.Drawing.Point(145, 1);
            this.metroTextBox12.CustomButton.Name = "";
            this.metroTextBox12.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.metroTextBox12.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox12.CustomButton.TabIndex = 1;
            this.metroTextBox12.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox12.CustomButton.UseSelectable = true;
            this.metroTextBox12.CustomButton.Visible = false;
            this.metroTextBox12.Enabled = false;
            this.metroTextBox12.Lines = new string[0];
            this.metroTextBox12.Location = new System.Drawing.Point(567, 321);
            this.metroTextBox12.MaxLength = 32767;
            this.metroTextBox12.Name = "metroTextBox12";
            this.metroTextBox12.PasswordChar = '\0';
            this.metroTextBox12.ReadOnly = true;
            this.metroTextBox12.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox12.SelectedText = "";
            this.metroTextBox12.SelectionLength = 0;
            this.metroTextBox12.SelectionStart = 0;
            this.metroTextBox12.ShortcutsEnabled = true;
            this.metroTextBox12.Size = new System.Drawing.Size(150, 23);
            this.metroTextBox12.TabIndex = 28;
            this.metroTextBox12.UseSelectable = true;
            this.metroTextBox12.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox12.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroTextBox13
            // 
            // 
            // 
            // 
            this.metroTextBox13.CustomButton.Image = null;
            this.metroTextBox13.CustomButton.Location = new System.Drawing.Point(178, 1);
            this.metroTextBox13.CustomButton.Name = "";
            this.metroTextBox13.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.metroTextBox13.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox13.CustomButton.TabIndex = 1;
            this.metroTextBox13.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox13.CustomButton.UseSelectable = true;
            this.metroTextBox13.CustomButton.Visible = false;
            this.metroTextBox13.Lines = new string[0];
            this.metroTextBox13.Location = new System.Drawing.Point(512, 101);
            this.metroTextBox13.MaxLength = 32767;
            this.metroTextBox13.Name = "metroTextBox13";
            this.metroTextBox13.PasswordChar = '\0';
            this.metroTextBox13.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox13.SelectedText = "";
            this.metroTextBox13.SelectionLength = 0;
            this.metroTextBox13.SelectionStart = 0;
            this.metroTextBox13.ShortcutsEnabled = true;
            this.metroTextBox13.Size = new System.Drawing.Size(200, 23);
            this.metroTextBox13.TabIndex = 29;
            this.metroTextBox13.UseSelectable = true;
            this.metroTextBox13.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox13.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroButton1
            // 
            this.metroButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.metroButton1.Location = new System.Drawing.Point(532, 258);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(109, 27);
            this.metroButton1.TabIndex = 30;
            this.metroButton1.Text = "Calculate Salary";
            this.metroButton1.UseCustomBackColor = true;
            this.metroButton1.UseSelectable = true;
            this.metroButton1.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel2.Location = new System.Drawing.Point(418, 319);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(105, 25);
            this.metroLabel2.TabIndex = 32;
            this.metroLabel2.Text = "Gross Salary";
            // 
            // add
            // 
            this.add.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.add.Location = new System.Drawing.Point(584, 442);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(86, 27);
            this.add.TabIndex = 34;
            this.add.Text = "Update";
            this.add.UseSelectable = true;
            this.add.Click += new System.EventHandler(this.add_Click);
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel6.Location = new System.Drawing.Point(43, 335);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(30, 19);
            this.metroLabel6.TabIndex = 35;
            this.metroLabel6.Text = "ETF";
            // 
            // metroTextBox1
            // 
            // 
            // 
            // 
            this.metroTextBox1.CustomButton.Image = null;
            this.metroTextBox1.CustomButton.Location = new System.Drawing.Point(178, 1);
            this.metroTextBox1.CustomButton.Name = "";
            this.metroTextBox1.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.metroTextBox1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox1.CustomButton.TabIndex = 1;
            this.metroTextBox1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox1.CustomButton.UseSelectable = true;
            this.metroTextBox1.CustomButton.Visible = false;
            this.metroTextBox1.Enabled = false;
            this.metroTextBox1.Lines = new string[0];
            this.metroTextBox1.Location = new System.Drawing.Point(137, 266);
            this.metroTextBox1.MaxLength = 32767;
            this.metroTextBox1.Name = "metroTextBox1";
            this.metroTextBox1.PasswordChar = '\0';
            this.metroTextBox1.ReadOnly = true;
            this.metroTextBox1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox1.SelectedText = "";
            this.metroTextBox1.SelectionLength = 0;
            this.metroTextBox1.SelectionStart = 0;
            this.metroTextBox1.ShortcutsEnabled = true;
            this.metroTextBox1.Size = new System.Drawing.Size(200, 23);
            this.metroTextBox1.TabIndex = 38;
            this.metroTextBox1.UseSelectable = true;
            this.metroTextBox1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.metroTextBox1.Click += new System.EventHandler(this.metroTextBox1_Click);
            // 
            // metroTextBox2
            // 
            // 
            // 
            // 
            this.metroTextBox2.CustomButton.Image = null;
            this.metroTextBox2.CustomButton.Location = new System.Drawing.Point(178, 1);
            this.metroTextBox2.CustomButton.Name = "";
            this.metroTextBox2.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.metroTextBox2.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox2.CustomButton.TabIndex = 1;
            this.metroTextBox2.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox2.CustomButton.UseSelectable = true;
            this.metroTextBox2.CustomButton.Visible = false;
            this.metroTextBox2.Enabled = false;
            this.metroTextBox2.Lines = new string[0];
            this.metroTextBox2.Location = new System.Drawing.Point(137, 331);
            this.metroTextBox2.MaxLength = 32767;
            this.metroTextBox2.Name = "metroTextBox2";
            this.metroTextBox2.PasswordChar = '\0';
            this.metroTextBox2.ReadOnly = true;
            this.metroTextBox2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox2.SelectedText = "";
            this.metroTextBox2.SelectionLength = 0;
            this.metroTextBox2.SelectionStart = 0;
            this.metroTextBox2.ShortcutsEnabled = true;
            this.metroTextBox2.Size = new System.Drawing.Size(200, 23);
            this.metroTextBox2.TabIndex = 39;
            this.metroTextBox2.UseSelectable = true;
            this.metroTextBox2.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox2.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.metroLabel9.Location = new System.Drawing.Point(137, 357);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(112, 19);
            this.metroLabel9.TabIndex = 40;
            this.metroLabel9.Text = "From Govenment";
            this.metroLabel9.UseCustomForeColor = true;
            // 
            // metroLabel11
            // 
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.metroLabel11.Location = new System.Drawing.Point(137, 292);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(81, 19);
            this.metroLabel11.TabIndex = 41;
            this.metroLabel11.Text = "From Salary";
            this.metroLabel11.UseCustomForeColor = true;
            // 
            // metroButton3
            // 
            this.metroButton3.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.metroButton3.Location = new System.Drawing.Point(461, 442);
            this.metroButton3.Name = "metroButton3";
            this.metroButton3.Size = new System.Drawing.Size(86, 27);
            this.metroButton3.TabIndex = 42;
            this.metroButton3.Text = "Clear";
            this.metroButton3.UseSelectable = true;
            this.metroButton3.Click += new System.EventHandler(this.metroButton3_Click_1);
            // 
            // empid
            // 
            // 
            // 
            // 
            this.empid.CustomButton.Image = null;
            this.empid.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.empid.CustomButton.Name = "";
            this.empid.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.empid.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.empid.CustomButton.TabIndex = 1;
            this.empid.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.empid.CustomButton.UseSelectable = true;
            this.empid.CustomButton.Visible = false;
            this.empid.Lines = new string[0];
            this.empid.Location = new System.Drawing.Point(137, 72);
            this.empid.MaxLength = 32767;
            this.empid.Name = "empid";
            this.empid.PasswordChar = '\0';
            this.empid.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.empid.SelectedText = "";
            this.empid.SelectionLength = 0;
            this.empid.SelectionStart = 0;
            this.empid.ShortcutsEnabled = true;
            this.empid.Size = new System.Drawing.Size(75, 23);
            this.empid.TabIndex = 43;
            this.empid.UseSelectable = true;
            this.empid.Visible = false;
            this.empid.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.empid.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroComboBox1
            // 
            this.metroComboBox1.FormattingEnabled = true;
            this.metroComboBox1.ItemHeight = 23;
            this.metroComboBox1.Location = new System.Drawing.Point(137, 101);
            this.metroComboBox1.Name = "metroComboBox1";
            this.metroComboBox1.Size = new System.Drawing.Size(200, 29);
            this.metroComboBox1.TabIndex = 44;
            this.metroComboBox1.UseSelectable = true;
            this.metroComboBox1.SelectedIndexChanged += new System.EventHandler(this.metroComboBox1_SelectedIndexChanged);
            // 
            // metroLabel12
            // 
            this.metroLabel12.AutoSize = true;
            this.metroLabel12.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel12.Location = new System.Drawing.Point(537, 374);
            this.metroLabel12.Name = "metroLabel12";
            this.metroLabel12.Size = new System.Drawing.Size(26, 19);
            this.metroLabel12.TabIndex = 45;
            this.metroLabel12.Text = "Rs.";
            // 
            // SalaryForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(760, 502);
            this.Controls.Add(this.metroLabel12);
            this.Controls.Add(this.metroComboBox1);
            this.Controls.Add(this.empid);
            this.Controls.Add(this.metroButton3);
            this.Controls.Add(this.metroLabel11);
            this.Controls.Add(this.metroLabel9);
            this.Controls.Add(this.metroTextBox2);
            this.Controls.Add(this.metroTextBox1);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.add);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.metroButton1);
            this.Controls.Add(this.metroTextBox13);
            this.Controls.Add(this.metroTextBox12);
            this.Controls.Add(this.netSal);
            this.Controls.Add(this.metroLabel15);
            this.Controls.Add(this.metroLabel14);
            this.Controls.Add(this.metroLabel10);
            this.Controls.Add(this.allowance);
            this.Controls.Add(this.hours);
            this.Controls.Add(this.rate);
            this.Controls.Add(this.basicsal);
            this.Controls.Add(this.Gsal);
            this.Controls.Add(this.metroLabel8);
            this.Controls.Add(this.metroLabel7);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.metroLabel1);
            this.Name = "SalaryForm";
            this.Text = "Salary";
            this.Load += new System.EventHandler(this.Sal_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroTextBox Gsal;
        private MetroFramework.Controls.MetroTextBox basicsal;
        private MetroFramework.Controls.MetroTextBox rate;
        private MetroFramework.Controls.MetroTextBox hours;
        private MetroFramework.Controls.MetroTextBox allowance;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private MetroFramework.Controls.MetroLabel metroLabel14;
        private MetroFramework.Controls.MetroLabel metroLabel15;
        private MetroFramework.Controls.MetroTextBox netSal;
        private MetroFramework.Controls.MetroTextBox metroTextBox12;
        private MetroFramework.Controls.MetroTextBox metroTextBox13;
        private MetroFramework.Controls.MetroButton metroButton1;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroButton add;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroTextBox metroTextBox1;
        private MetroFramework.Controls.MetroTextBox metroTextBox2;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        private MetroFramework.Controls.MetroButton metroButton3;
        private MetroFramework.Controls.MetroTextBox empid;
        private MetroFramework.Controls.MetroComboBox metroComboBox1;
        private MetroFramework.Controls.MetroLabel metroLabel12;
    }
}