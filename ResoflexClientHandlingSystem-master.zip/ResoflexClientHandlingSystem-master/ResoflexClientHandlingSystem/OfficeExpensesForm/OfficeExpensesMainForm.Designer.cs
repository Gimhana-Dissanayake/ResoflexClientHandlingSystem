﻿namespace ResoflexClientHandlingSystem.OfficeExpensesForm
{
    partial class OfficeExpensesMainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OfficeExpensesMainForm));
            this.tile3 = new MetroFramework.Controls.MetroTile();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.tile2 = new MetroFramework.Controls.MetroTile();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.tile1 = new MetroFramework.Controls.MetroTile();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.metroButton2 = new MetroFramework.Controls.MetroButton();
            this.metroButton4 = new MetroFramework.Controls.MetroButton();
            this.metroGrid1 = new MetroFramework.Controls.MetroGrid();
            this.metroButton5 = new MetroFramework.Controls.MetroButton();
            this.profilebtn = new MetroFramework.Controls.MetroButton();
            this.searchBtn = new MetroFramework.Controls.MetroButton();
            this.searchProjectTxtBox = new MetroFramework.Controls.MetroTextBox();
            this.homeBtn = new MetroFramework.Controls.MetroButton();
            this.tile3.SuspendLayout();
            this.tile2.SuspendLayout();
            this.tile1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid1)).BeginInit();
            this.SuspendLayout();
            // 
            // tile3
            // 
            this.tile3.ActiveControl = null;
            this.tile3.Controls.Add(this.metroLabel3);
            this.tile3.Location = new System.Drawing.Point(660, 100);
            this.tile3.Name = "tile3";
            this.tile3.Size = new System.Drawing.Size(222, 124);
            this.tile3.TabIndex = 21;
            this.tile3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.tile3.TileTextFontSize = MetroFramework.MetroTileTextSize.Tall;
            this.tile3.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Bold;
            this.tile3.UseSelectable = true;
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel3.Location = new System.Drawing.Point(3, 105);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(120, 19);
            this.metroLabel3.TabIndex = 1;
            this.metroLabel3.Text = "Max Spent Event";
            // 
            // tile2
            // 
            this.tile2.ActiveControl = null;
            this.tile2.Controls.Add(this.metroLabel2);
            this.tile2.Location = new System.Drawing.Point(363, 100);
            this.tile2.Name = "tile2";
            this.tile2.Size = new System.Drawing.Size(222, 124);
            this.tile2.TabIndex = 20;
            this.tile2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.tile2.TileTextFontSize = MetroFramework.MetroTileTextSize.Tall;
            this.tile2.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Bold;
            this.tile2.UseSelectable = true;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel2.Location = new System.Drawing.Point(3, 105);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(181, 19);
            this.metroLabel2.TabIndex = 1;
            this.metroLabel2.Text = "This month Direct amount";
            // 
            // tile1
            // 
            this.tile1.ActiveControl = null;
            this.tile1.Controls.Add(this.metroLabel1);
            this.tile1.Location = new System.Drawing.Point(67, 100);
            this.tile1.Name = "tile1";
            this.tile1.Size = new System.Drawing.Size(222, 124);
            this.tile1.TabIndex = 19;
            this.tile1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.tile1.TileTextFontSize = MetroFramework.MetroTileTextSize.Tall;
            this.tile1.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Bold;
            this.tile1.UseSelectable = true;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel1.Location = new System.Drawing.Point(4, 105);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(177, 19);
            this.metroLabel1.TabIndex = 0;
            this.metroLabel1.Text = "Office. Exp. of this Month";
            // 
            // metroButton1
            // 
            this.metroButton1.BackColor = System.Drawing.Color.LightSkyBlue;
            this.metroButton1.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.metroButton1.Location = new System.Drawing.Point(726, 411);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(184, 43);
            this.metroButton1.TabIndex = 25;
            this.metroButton1.Text = "IOU";
            this.metroButton1.UseCustomBackColor = true;
            this.metroButton1.UseSelectable = true;
            this.metroButton1.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // metroButton2
            // 
            this.metroButton2.BackColor = System.Drawing.Color.LightSkyBlue;
            this.metroButton2.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.metroButton2.Location = new System.Drawing.Point(726, 476);
            this.metroButton2.Name = "metroButton2";
            this.metroButton2.Size = new System.Drawing.Size(184, 43);
            this.metroButton2.TabIndex = 26;
            this.metroButton2.Text = "Salary";
            this.metroButton2.UseCustomBackColor = true;
            this.metroButton2.UseSelectable = true;
            this.metroButton2.Click += new System.EventHandler(this.metroButton2_Click);
            // 
            // metroButton4
            // 
            this.metroButton4.BackColor = System.Drawing.Color.LightSkyBlue;
            this.metroButton4.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.metroButton4.Location = new System.Drawing.Point(726, 547);
            this.metroButton4.Name = "metroButton4";
            this.metroButton4.Size = new System.Drawing.Size(184, 43);
            this.metroButton4.TabIndex = 28;
            this.metroButton4.Text = "Reports";
            this.metroButton4.UseCustomBackColor = true;
            this.metroButton4.UseSelectable = true;
            this.metroButton4.Click += new System.EventHandler(this.metroButton4_Click);
            // 
            // metroGrid1
            // 
            this.metroGrid1.AllowUserToResizeRows = false;
            this.metroGrid1.BackgroundColor = System.Drawing.Color.White;
            this.metroGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.metroGrid1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.metroGrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.metroGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.metroGrid1.DefaultCellStyle = dataGridViewCellStyle2;
            this.metroGrid1.EnableHeadersVisualStyles = false;
            this.metroGrid1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGrid1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid1.Location = new System.Drawing.Point(71, 316);
            this.metroGrid1.Name = "metroGrid1";
            this.metroGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.metroGrid1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.metroGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.metroGrid1.Size = new System.Drawing.Size(600, 274);
            this.metroGrid1.TabIndex = 29;
            this.metroGrid1.UseCustomBackColor = true;
            this.metroGrid1.UseCustomForeColor = true;
            // 
            // metroButton5
            // 
            this.metroButton5.BackColor = System.Drawing.Color.LightSkyBlue;
            this.metroButton5.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.metroButton5.Location = new System.Drawing.Point(726, 344);
            this.metroButton5.Name = "metroButton5";
            this.metroButton5.Size = new System.Drawing.Size(184, 43);
            this.metroButton5.TabIndex = 30;
            this.metroButton5.Text = "Add Direct Expence";
            this.metroButton5.UseCustomBackColor = true;
            this.metroButton5.UseSelectable = true;
            this.metroButton5.Click += new System.EventHandler(this.metroButton5_Click);
            // 
            // profilebtn
            // 
            this.profilebtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.profilebtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.profilebtn.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.profilebtn.Location = new System.Drawing.Point(872, 37);
            this.profilebtn.Name = "profilebtn";
            this.profilebtn.Size = new System.Drawing.Size(105, 29);
            this.profilebtn.TabIndex = 31;
            this.profilebtn.UseCustomBackColor = true;
            this.profilebtn.UseSelectable = true;
            // 
            // searchBtn
            // 
            this.searchBtn.Location = new System.Drawing.Point(309, 273);
            this.searchBtn.Margin = new System.Windows.Forms.Padding(2);
            this.searchBtn.Name = "searchBtn";
            this.searchBtn.Size = new System.Drawing.Size(89, 24);
            this.searchBtn.TabIndex = 33;
            this.searchBtn.Text = "Search";
            this.searchBtn.UseSelectable = true;
            // 
            // searchProjectTxtBox
            // 
            // 
            // 
            // 
            this.searchProjectTxtBox.CustomButton.Image = null;
            this.searchProjectTxtBox.CustomButton.Location = new System.Drawing.Point(196, 2);
            this.searchProjectTxtBox.CustomButton.Margin = new System.Windows.Forms.Padding(2);
            this.searchProjectTxtBox.CustomButton.Name = "";
            this.searchProjectTxtBox.CustomButton.Size = new System.Drawing.Size(19, 19);
            this.searchProjectTxtBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.searchProjectTxtBox.CustomButton.TabIndex = 1;
            this.searchProjectTxtBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.searchProjectTxtBox.CustomButton.UseSelectable = true;
            this.searchProjectTxtBox.CustomButton.Visible = false;
            this.searchProjectTxtBox.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.searchProjectTxtBox.Lines = new string[0];
            this.searchProjectTxtBox.Location = new System.Drawing.Point(71, 273);
            this.searchProjectTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.searchProjectTxtBox.MaxLength = 32767;
            this.searchProjectTxtBox.Multiline = true;
            this.searchProjectTxtBox.Name = "searchProjectTxtBox";
            this.searchProjectTxtBox.PasswordChar = '\0';
            this.searchProjectTxtBox.PromptText = "Search by Staff name/Category";
            this.searchProjectTxtBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.searchProjectTxtBox.SelectedText = "";
            this.searchProjectTxtBox.SelectionLength = 0;
            this.searchProjectTxtBox.SelectionStart = 0;
            this.searchProjectTxtBox.ShortcutsEnabled = true;
            this.searchProjectTxtBox.Size = new System.Drawing.Size(218, 24);
            this.searchProjectTxtBox.TabIndex = 32;
            this.searchProjectTxtBox.UseSelectable = true;
            this.searchProjectTxtBox.WaterMark = "Search by Staff name/Category";
            this.searchProjectTxtBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.searchProjectTxtBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.searchProjectTxtBox.TextChanged += new System.EventHandler(this.searchProjectTxtBox_TextChanged);
            // 
            // homeBtn
            // 
            this.homeBtn.BackColor = System.Drawing.Color.Transparent;
            this.homeBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("homeBtn.BackgroundImage")));
            this.homeBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.homeBtn.Location = new System.Drawing.Point(511, 16);
            this.homeBtn.Margin = new System.Windows.Forms.Padding(2);
            this.homeBtn.Name = "homeBtn";
            this.homeBtn.Size = new System.Drawing.Size(33, 31);
            this.homeBtn.TabIndex = 24;
            this.homeBtn.UseSelectable = true;
            this.homeBtn.Click += new System.EventHandler(this.homeBtn_Click);
            // 
            // OfficeExpensesMainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 650);
            this.Controls.Add(this.searchBtn);
            this.Controls.Add(this.searchProjectTxtBox);
            this.Controls.Add(this.profilebtn);
            this.Controls.Add(this.metroButton5);
            this.Controls.Add(this.metroGrid1);
            this.Controls.Add(this.metroButton4);
            this.Controls.Add(this.metroButton2);
            this.Controls.Add(this.metroButton1);
            this.Controls.Add(this.homeBtn);
            this.Controls.Add(this.tile3);
            this.Controls.Add(this.tile2);
            this.Controls.Add(this.tile1);
            this.Name = "OfficeExpensesMainForm";
            this.Text = "Office Expenses ";
            this.Load += new System.EventHandler(this.OfficeExpensesMainForm_Load);
            this.tile3.ResumeLayout(false);
            this.tile3.PerformLayout();
            this.tile2.ResumeLayout(false);
            this.tile2.PerformLayout();
            this.tile1.ResumeLayout(false);
            this.tile1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroTile tile3;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroTile tile2;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroTile tile1;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroButton homeBtn;
        private MetroFramework.Controls.MetroButton metroButton1;
        private MetroFramework.Controls.MetroButton metroButton2;
        private MetroFramework.Controls.MetroButton metroButton4;
        private MetroFramework.Controls.MetroGrid metroGrid1;
        private MetroFramework.Controls.MetroButton metroButton5;
        private MetroFramework.Controls.MetroButton profilebtn;
        private MetroFramework.Controls.MetroButton searchBtn;
        private MetroFramework.Controls.MetroTextBox searchProjectTxtBox;
    }
}