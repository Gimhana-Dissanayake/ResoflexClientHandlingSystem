﻿namespace ResoflexClientHandlingSystem
{
    partial class StaffForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StaffForm));
            this.metroTabControl1 = new MetroFramework.Controls.MetroTabControl();
            this.AddMemberTab = new MetroFramework.Controls.MetroTabPage();
            this.htmlLabel2 = new MetroFramework.Drawing.Html.HtmlLabel();
            this.fNameTxtBox = new MetroFramework.Controls.MetroTextBox();
            this.htmlLabel12 = new MetroFramework.Drawing.Html.HtmlLabel();
            this.basicSalTxtBox = new MetroFramework.Controls.MetroTextBox();
            this.htmlLabel11 = new MetroFramework.Drawing.Html.HtmlLabel();
            this.otRateTxtBox = new MetroFramework.Controls.MetroTextBox();
            this.htmlLabel5 = new MetroFramework.Drawing.Html.HtmlLabel();
            this.linkedTxtBox = new MetroFramework.Controls.MetroTextBox();
            this.lNameTxtBox = new MetroFramework.Controls.MetroTextBox();
            this.htmlLabel4 = new MetroFramework.Drawing.Html.HtmlLabel();
            this.fbTxtBox = new MetroFramework.Controls.MetroTextBox();
            this.telMobileTxtBox = new MetroFramework.Controls.MetroTextBox();
            this.htmlLabel10 = new MetroFramework.Drawing.Html.HtmlLabel();
            this.telLanTxtBox = new MetroFramework.Controls.MetroTextBox();
            this.htmlLabel7 = new MetroFramework.Drawing.Html.HtmlLabel();
            this.emailTxtBox = new MetroFramework.Controls.MetroTextBox();
            this.sAddTxtBox = new MetroFramework.Controls.MetroTextBox();
            this.htmlLabel6 = new MetroFramework.Drawing.Html.HtmlLabel();
            this.desgCmbBox = new MetroFramework.Controls.MetroComboBox();
            this.htmlLabel9 = new MetroFramework.Drawing.Html.HtmlLabel();
            this.htmlLabel8 = new MetroFramework.Drawing.Html.HtmlLabel();
            this.metroLink2 = new MetroFramework.Controls.MetroLink();
            this.pAddTxtBox = new MetroFramework.Controls.MetroTextBox();
            this.staffAddBtn = new MetroFramework.Controls.MetroButton();
            this.addNICtxtBox = new MetroFramework.Controls.MetroTextBox();
            this.htmlLabel1 = new MetroFramework.Drawing.Html.HtmlLabel();
            this.staffClearBtn = new MetroFramework.Controls.MetroButton();
            this.htmlLabel3 = new MetroFramework.Drawing.Html.HtmlLabel();
            this.htmlLabel13 = new MetroFramework.Drawing.Html.HtmlLabel();
            this.AddDesignationTab = new MetroFramework.Controls.MetroTabPage();
            this.htmlLabel16 = new MetroFramework.Drawing.Html.HtmlLabel();
            this.clearNewDesBtn = new MetroFramework.Controls.MetroButton();
            this.addNewDesBtn = new MetroFramework.Controls.MetroButton();
            this.htmlLabel14 = new MetroFramework.Drawing.Html.HtmlLabel();
            this.addNewDesTxtBox = new MetroFramework.Controls.MetroTextBox();
            this.errorProviderAddStaff = new System.Windows.Forms.ErrorProvider(this.components);
            this.homeBtn = new MetroFramework.Controls.MetroButton();
            this.demo_stf_btn = new MetroFramework.Controls.MetroButton();
            this.profilebtn = new MetroFramework.Controls.MetroButton();
            this.metroTabControl1.SuspendLayout();
            this.AddMemberTab.SuspendLayout();
            this.htmlLabel2.SuspendLayout();
            this.htmlLabel12.SuspendLayout();
            this.htmlLabel11.SuspendLayout();
            this.htmlLabel5.SuspendLayout();
            this.htmlLabel4.SuspendLayout();
            this.htmlLabel10.SuspendLayout();
            this.htmlLabel7.SuspendLayout();
            this.htmlLabel6.SuspendLayout();
            this.htmlLabel8.SuspendLayout();
            this.AddDesignationTab.SuspendLayout();
            this.htmlLabel16.SuspendLayout();
            this.htmlLabel14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderAddStaff)).BeginInit();
            this.SuspendLayout();
            // 
            // metroTabControl1
            // 
            this.metroTabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroTabControl1.Controls.Add(this.AddMemberTab);
            this.metroTabControl1.Controls.Add(this.AddDesignationTab);
            this.metroTabControl1.Location = new System.Drawing.Point(11, 50);
            this.metroTabControl1.Name = "metroTabControl1";
            this.metroTabControl1.SelectedIndex = 0;
            this.metroTabControl1.Size = new System.Drawing.Size(771, 453);
            this.metroTabControl1.TabIndex = 0;
            this.metroTabControl1.UseSelectable = true;
            // 
            // AddMemberTab
            // 
            this.AddMemberTab.Controls.Add(this.demo_stf_btn);
            this.AddMemberTab.Controls.Add(this.htmlLabel2);
            this.AddMemberTab.Controls.Add(this.htmlLabel12);
            this.AddMemberTab.Controls.Add(this.htmlLabel11);
            this.AddMemberTab.Controls.Add(this.htmlLabel5);
            this.AddMemberTab.Controls.Add(this.lNameTxtBox);
            this.AddMemberTab.Controls.Add(this.htmlLabel4);
            this.AddMemberTab.Controls.Add(this.telMobileTxtBox);
            this.AddMemberTab.Controls.Add(this.htmlLabel10);
            this.AddMemberTab.Controls.Add(this.htmlLabel7);
            this.AddMemberTab.Controls.Add(this.sAddTxtBox);
            this.AddMemberTab.Controls.Add(this.htmlLabel6);
            this.AddMemberTab.Controls.Add(this.htmlLabel9);
            this.AddMemberTab.Controls.Add(this.htmlLabel8);
            this.AddMemberTab.Controls.Add(this.pAddTxtBox);
            this.AddMemberTab.Controls.Add(this.staffAddBtn);
            this.AddMemberTab.Controls.Add(this.addNICtxtBox);
            this.AddMemberTab.Controls.Add(this.htmlLabel1);
            this.AddMemberTab.Controls.Add(this.staffClearBtn);
            this.AddMemberTab.Controls.Add(this.htmlLabel3);
            this.AddMemberTab.Controls.Add(this.htmlLabel13);
            this.AddMemberTab.HorizontalScrollbarBarColor = true;
            this.AddMemberTab.HorizontalScrollbarHighlightOnWheel = false;
            this.AddMemberTab.HorizontalScrollbarSize = 10;
            this.AddMemberTab.Location = new System.Drawing.Point(4, 38);
            this.AddMemberTab.Name = "AddMemberTab";
            this.AddMemberTab.Size = new System.Drawing.Size(763, 411);
            this.AddMemberTab.TabIndex = 0;
            this.AddMemberTab.Text = "Add New Member";
            this.AddMemberTab.VerticalScrollbarBarColor = true;
            this.AddMemberTab.VerticalScrollbarHighlightOnWheel = false;
            this.AddMemberTab.VerticalScrollbarSize = 10;
            this.AddMemberTab.Click += new System.EventHandler(this.AddMemberTab_Click);
            // 
            // htmlLabel2
            // 
            this.htmlLabel2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.htmlLabel2.AutoScroll = true;
            this.htmlLabel2.AutoScrollMinSize = new System.Drawing.Size(63, 23);
            this.htmlLabel2.AutoSize = false;
            this.htmlLabel2.BackColor = System.Drawing.SystemColors.Window;
            this.htmlLabel2.Controls.Add(this.fNameTxtBox);
            this.htmlLabel2.Location = new System.Drawing.Point(7, 0);
            this.htmlLabel2.Name = "htmlLabel2";
            this.htmlLabel2.Size = new System.Drawing.Size(341, 29);
            this.htmlLabel2.TabIndex = 42;
            this.htmlLabel2.Text = "First name";
            // 
            // fNameTxtBox
            // 
            this.fNameTxtBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            // 
            // 
            // 
            this.fNameTxtBox.CustomButton.Image = null;
            this.fNameTxtBox.CustomButton.Location = new System.Drawing.Point(162, 2);
            this.fNameTxtBox.CustomButton.Name = "";
            this.fNameTxtBox.CustomButton.Size = new System.Drawing.Size(15, 15);
            this.fNameTxtBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.fNameTxtBox.CustomButton.TabIndex = 1;
            this.fNameTxtBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.fNameTxtBox.CustomButton.UseSelectable = true;
            this.fNameTxtBox.CustomButton.Visible = false;
            this.fNameTxtBox.Lines = new string[0];
            this.fNameTxtBox.Location = new System.Drawing.Point(161, 7);
            this.fNameTxtBox.MaxLength = 32767;
            this.fNameTxtBox.Name = "fNameTxtBox";
            this.fNameTxtBox.PasswordChar = '\0';
            this.fNameTxtBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.fNameTxtBox.SelectedText = "";
            this.fNameTxtBox.SelectionLength = 0;
            this.fNameTxtBox.SelectionStart = 0;
            this.fNameTxtBox.ShortcutsEnabled = true;
            this.fNameTxtBox.Size = new System.Drawing.Size(180, 20);
            this.fNameTxtBox.TabIndex = 43;
            this.fNameTxtBox.UseSelectable = true;
            this.fNameTxtBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.fNameTxtBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.fNameTxtBox.Click += new System.EventHandler(this.fNameTxtBox_Click);
            // 
            // htmlLabel12
            // 
            this.htmlLabel12.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.htmlLabel12.AutoScroll = true;
            this.htmlLabel12.AutoScrollMinSize = new System.Drawing.Size(73, 23);
            this.htmlLabel12.AutoSize = false;
            this.htmlLabel12.BackColor = System.Drawing.SystemColors.Window;
            this.htmlLabel12.Controls.Add(this.basicSalTxtBox);
            this.htmlLabel12.Location = new System.Drawing.Point(7, 356);
            this.htmlLabel12.Name = "htmlLabel12";
            this.htmlLabel12.Size = new System.Drawing.Size(341, 29);
            this.htmlLabel12.TabIndex = 57;
            this.htmlLabel12.Text = "Basic Salary";
            // 
            // basicSalTxtBox
            // 
            this.basicSalTxtBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            // 
            // 
            // 
            this.basicSalTxtBox.CustomButton.Image = null;
            this.basicSalTxtBox.CustomButton.Location = new System.Drawing.Point(162, 2);
            this.basicSalTxtBox.CustomButton.Name = "";
            this.basicSalTxtBox.CustomButton.Size = new System.Drawing.Size(15, 15);
            this.basicSalTxtBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.basicSalTxtBox.CustomButton.TabIndex = 1;
            this.basicSalTxtBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.basicSalTxtBox.CustomButton.UseSelectable = true;
            this.basicSalTxtBox.CustomButton.Visible = false;
            this.basicSalTxtBox.Lines = new string[0];
            this.basicSalTxtBox.Location = new System.Drawing.Point(161, 3);
            this.basicSalTxtBox.MaxLength = 32767;
            this.basicSalTxtBox.Name = "basicSalTxtBox";
            this.basicSalTxtBox.PasswordChar = '\0';
            this.basicSalTxtBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.basicSalTxtBox.SelectedText = "";
            this.basicSalTxtBox.SelectionLength = 0;
            this.basicSalTxtBox.SelectionStart = 0;
            this.basicSalTxtBox.ShortcutsEnabled = true;
            this.basicSalTxtBox.Size = new System.Drawing.Size(180, 20);
            this.basicSalTxtBox.TabIndex = 11;
            this.basicSalTxtBox.UseSelectable = true;
            this.basicSalTxtBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.basicSalTxtBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // htmlLabel11
            // 
            this.htmlLabel11.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.htmlLabel11.AutoScroll = true;
            this.htmlLabel11.AutoScrollMinSize = new System.Drawing.Size(52, 23);
            this.htmlLabel11.AutoSize = false;
            this.htmlLabel11.BackColor = System.Drawing.SystemColors.Window;
            this.htmlLabel11.Controls.Add(this.otRateTxtBox);
            this.htmlLabel11.Location = new System.Drawing.Point(7, 387);
            this.htmlLabel11.Name = "htmlLabel11";
            this.htmlLabel11.Size = new System.Drawing.Size(341, 29);
            this.htmlLabel11.TabIndex = 54;
            this.htmlLabel11.Text = "OT Rate";
            // 
            // otRateTxtBox
            // 
            this.otRateTxtBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            // 
            // 
            // 
            this.otRateTxtBox.CustomButton.Image = null;
            this.otRateTxtBox.CustomButton.Location = new System.Drawing.Point(162, 2);
            this.otRateTxtBox.CustomButton.Name = "";
            this.otRateTxtBox.CustomButton.Size = new System.Drawing.Size(15, 15);
            this.otRateTxtBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.otRateTxtBox.CustomButton.TabIndex = 1;
            this.otRateTxtBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.otRateTxtBox.CustomButton.UseSelectable = true;
            this.otRateTxtBox.CustomButton.Visible = false;
            this.otRateTxtBox.Lines = new string[0];
            this.otRateTxtBox.Location = new System.Drawing.Point(161, 3);
            this.otRateTxtBox.MaxLength = 32767;
            this.otRateTxtBox.Name = "otRateTxtBox";
            this.otRateTxtBox.PasswordChar = '\0';
            this.otRateTxtBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.otRateTxtBox.SelectedText = "";
            this.otRateTxtBox.SelectionLength = 0;
            this.otRateTxtBox.SelectionStart = 0;
            this.otRateTxtBox.ShortcutsEnabled = true;
            this.otRateTxtBox.Size = new System.Drawing.Size(180, 20);
            this.otRateTxtBox.TabIndex = 11;
            this.otRateTxtBox.UseSelectable = true;
            this.otRateTxtBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.otRateTxtBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // htmlLabel5
            // 
            this.htmlLabel5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.htmlLabel5.AutoScroll = true;
            this.htmlLabel5.AutoScrollMinSize = new System.Drawing.Size(52, 23);
            this.htmlLabel5.AutoSize = false;
            this.htmlLabel5.BackColor = System.Drawing.SystemColors.Window;
            this.htmlLabel5.Controls.Add(this.linkedTxtBox);
            this.htmlLabel5.Location = new System.Drawing.Point(7, 285);
            this.htmlLabel5.Name = "htmlLabel5";
            this.htmlLabel5.Size = new System.Drawing.Size(341, 29);
            this.htmlLabel5.TabIndex = 53;
            this.htmlLabel5.Text = "LinkedIn";
            // 
            // linkedTxtBox
            // 
            this.linkedTxtBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            // 
            // 
            // 
            this.linkedTxtBox.CustomButton.Image = null;
            this.linkedTxtBox.CustomButton.Location = new System.Drawing.Point(162, 2);
            this.linkedTxtBox.CustomButton.Name = "";
            this.linkedTxtBox.CustomButton.Size = new System.Drawing.Size(15, 15);
            this.linkedTxtBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.linkedTxtBox.CustomButton.TabIndex = 1;
            this.linkedTxtBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.linkedTxtBox.CustomButton.UseSelectable = true;
            this.linkedTxtBox.CustomButton.Visible = false;
            this.linkedTxtBox.Lines = new string[0];
            this.linkedTxtBox.Location = new System.Drawing.Point(161, 3);
            this.linkedTxtBox.MaxLength = 32767;
            this.linkedTxtBox.Name = "linkedTxtBox";
            this.linkedTxtBox.PasswordChar = '\0';
            this.linkedTxtBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.linkedTxtBox.SelectedText = "";
            this.linkedTxtBox.SelectionLength = 0;
            this.linkedTxtBox.SelectionStart = 0;
            this.linkedTxtBox.ShortcutsEnabled = true;
            this.linkedTxtBox.Size = new System.Drawing.Size(180, 20);
            this.linkedTxtBox.TabIndex = 11;
            this.linkedTxtBox.UseSelectable = true;
            this.linkedTxtBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.linkedTxtBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // lNameTxtBox
            // 
            this.lNameTxtBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            // 
            // 
            // 
            this.lNameTxtBox.CustomButton.Image = null;
            this.lNameTxtBox.CustomButton.Location = new System.Drawing.Point(162, 2);
            this.lNameTxtBox.CustomButton.Name = "";
            this.lNameTxtBox.CustomButton.Size = new System.Drawing.Size(15, 15);
            this.lNameTxtBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.lNameTxtBox.CustomButton.TabIndex = 1;
            this.lNameTxtBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.lNameTxtBox.CustomButton.UseSelectable = true;
            this.lNameTxtBox.CustomButton.Visible = false;
            this.lNameTxtBox.Lines = new string[0];
            this.lNameTxtBox.Location = new System.Drawing.Point(168, 35);
            this.lNameTxtBox.MaxLength = 32767;
            this.lNameTxtBox.Name = "lNameTxtBox";
            this.lNameTxtBox.PasswordChar = '\0';
            this.lNameTxtBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.lNameTxtBox.SelectedText = "";
            this.lNameTxtBox.SelectionLength = 0;
            this.lNameTxtBox.SelectionStart = 0;
            this.lNameTxtBox.ShortcutsEnabled = true;
            this.lNameTxtBox.Size = new System.Drawing.Size(180, 20);
            this.lNameTxtBox.TabIndex = 47;
            this.lNameTxtBox.UseSelectable = true;
            this.lNameTxtBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.lNameTxtBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // htmlLabel4
            // 
            this.htmlLabel4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.htmlLabel4.AutoScroll = true;
            this.htmlLabel4.AutoScrollMinSize = new System.Drawing.Size(59, 23);
            this.htmlLabel4.AutoSize = false;
            this.htmlLabel4.BackColor = System.Drawing.SystemColors.Window;
            this.htmlLabel4.Controls.Add(this.fbTxtBox);
            this.htmlLabel4.Location = new System.Drawing.Point(7, 256);
            this.htmlLabel4.Name = "htmlLabel4";
            this.htmlLabel4.Size = new System.Drawing.Size(341, 29);
            this.htmlLabel4.TabIndex = 51;
            this.htmlLabel4.Text = "Facebook";
            // 
            // fbTxtBox
            // 
            this.fbTxtBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            // 
            // 
            // 
            this.fbTxtBox.CustomButton.Image = null;
            this.fbTxtBox.CustomButton.Location = new System.Drawing.Point(162, 2);
            this.fbTxtBox.CustomButton.Name = "";
            this.fbTxtBox.CustomButton.Size = new System.Drawing.Size(15, 15);
            this.fbTxtBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.fbTxtBox.CustomButton.TabIndex = 1;
            this.fbTxtBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.fbTxtBox.CustomButton.UseSelectable = true;
            this.fbTxtBox.CustomButton.Visible = false;
            this.fbTxtBox.Lines = new string[0];
            this.fbTxtBox.Location = new System.Drawing.Point(161, 3);
            this.fbTxtBox.MaxLength = 32767;
            this.fbTxtBox.Name = "fbTxtBox";
            this.fbTxtBox.PasswordChar = '\0';
            this.fbTxtBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.fbTxtBox.SelectedText = "";
            this.fbTxtBox.SelectionLength = 0;
            this.fbTxtBox.SelectionStart = 0;
            this.fbTxtBox.ShortcutsEnabled = true;
            this.fbTxtBox.Size = new System.Drawing.Size(180, 20);
            this.fbTxtBox.TabIndex = 11;
            this.fbTxtBox.UseSelectable = true;
            this.fbTxtBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.fbTxtBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // telMobileTxtBox
            // 
            this.telMobileTxtBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            // 
            // 
            // 
            this.telMobileTxtBox.CustomButton.Image = null;
            this.telMobileTxtBox.CustomButton.Location = new System.Drawing.Point(162, 2);
            this.telMobileTxtBox.CustomButton.Name = "";
            this.telMobileTxtBox.CustomButton.Size = new System.Drawing.Size(15, 15);
            this.telMobileTxtBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.telMobileTxtBox.CustomButton.TabIndex = 1;
            this.telMobileTxtBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.telMobileTxtBox.CustomButton.UseSelectable = true;
            this.telMobileTxtBox.CustomButton.Visible = false;
            this.telMobileTxtBox.Lines = new string[0];
            this.telMobileTxtBox.Location = new System.Drawing.Point(168, 172);
            this.telMobileTxtBox.MaxLength = 32767;
            this.telMobileTxtBox.Name = "telMobileTxtBox";
            this.telMobileTxtBox.PasswordChar = '\0';
            this.telMobileTxtBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.telMobileTxtBox.SelectedText = "";
            this.telMobileTxtBox.SelectionLength = 0;
            this.telMobileTxtBox.SelectionStart = 0;
            this.telMobileTxtBox.ShortcutsEnabled = true;
            this.telMobileTxtBox.Size = new System.Drawing.Size(180, 20);
            this.telMobileTxtBox.TabIndex = 62;
            this.telMobileTxtBox.UseSelectable = true;
            this.telMobileTxtBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.telMobileTxtBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.telMobileTxtBox.Validating += new System.ComponentModel.CancelEventHandler(this.telMobileTxtBox_Validating);
            this.telMobileTxtBox.Validated += new System.EventHandler(this.telMobileTxtBox_Validated);
            // 
            // htmlLabel10
            // 
            this.htmlLabel10.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.htmlLabel10.AutoScroll = true;
            this.htmlLabel10.AutoScrollMinSize = new System.Drawing.Size(65, 23);
            this.htmlLabel10.AutoSize = false;
            this.htmlLabel10.BackColor = System.Drawing.SystemColors.Window;
            this.htmlLabel10.Controls.Add(this.telLanTxtBox);
            this.htmlLabel10.Location = new System.Drawing.Point(7, 172);
            this.htmlLabel10.Name = "htmlLabel10";
            this.htmlLabel10.Size = new System.Drawing.Size(341, 49);
            this.htmlLabel10.TabIndex = 61;
            this.htmlLabel10.Text = "Contact No";
            // 
            // telLanTxtBox
            // 
            this.telLanTxtBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            // 
            // 
            // 
            this.telLanTxtBox.CustomButton.Image = null;
            this.telLanTxtBox.CustomButton.Location = new System.Drawing.Point(162, 2);
            this.telLanTxtBox.CustomButton.Name = "";
            this.telLanTxtBox.CustomButton.Size = new System.Drawing.Size(15, 15);
            this.telLanTxtBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.telLanTxtBox.CustomButton.TabIndex = 1;
            this.telLanTxtBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.telLanTxtBox.CustomButton.UseSelectable = true;
            this.telLanTxtBox.CustomButton.Visible = false;
            this.telLanTxtBox.Lines = new string[0];
            this.telLanTxtBox.Location = new System.Drawing.Point(161, 29);
            this.telLanTxtBox.MaxLength = 32767;
            this.telLanTxtBox.Name = "telLanTxtBox";
            this.telLanTxtBox.PasswordChar = '\0';
            this.telLanTxtBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.telLanTxtBox.SelectedText = "";
            this.telLanTxtBox.SelectionLength = 0;
            this.telLanTxtBox.SelectionStart = 0;
            this.telLanTxtBox.ShortcutsEnabled = true;
            this.telLanTxtBox.Size = new System.Drawing.Size(180, 20);
            this.telLanTxtBox.TabIndex = 21;
            this.telLanTxtBox.UseSelectable = true;
            this.telLanTxtBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.telLanTxtBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.telLanTxtBox.Validating += new System.ComponentModel.CancelEventHandler(this.telLanTxtBox_Validating);
            this.telLanTxtBox.Validated += new System.EventHandler(this.telLanTxtBox_Validated);
            // 
            // htmlLabel7
            // 
            this.htmlLabel7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.htmlLabel7.AutoScroll = true;
            this.htmlLabel7.AutoScrollMinSize = new System.Drawing.Size(48, 23);
            this.htmlLabel7.AutoSize = false;
            this.htmlLabel7.BackColor = System.Drawing.SystemColors.Window;
            this.htmlLabel7.Controls.Add(this.emailTxtBox);
            this.htmlLabel7.Location = new System.Drawing.Point(7, 227);
            this.htmlLabel7.Name = "htmlLabel7";
            this.htmlLabel7.Size = new System.Drawing.Size(341, 29);
            this.htmlLabel7.TabIndex = 50;
            this.htmlLabel7.Text = "E - mail";
            // 
            // emailTxtBox
            // 
            this.emailTxtBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            // 
            // 
            // 
            this.emailTxtBox.CustomButton.Image = null;
            this.emailTxtBox.CustomButton.Location = new System.Drawing.Point(162, 2);
            this.emailTxtBox.CustomButton.Name = "";
            this.emailTxtBox.CustomButton.Size = new System.Drawing.Size(15, 15);
            this.emailTxtBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.emailTxtBox.CustomButton.TabIndex = 1;
            this.emailTxtBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.emailTxtBox.CustomButton.UseSelectable = true;
            this.emailTxtBox.CustomButton.Visible = false;
            this.emailTxtBox.Lines = new string[0];
            this.emailTxtBox.Location = new System.Drawing.Point(161, 3);
            this.emailTxtBox.MaxLength = 32767;
            this.emailTxtBox.Name = "emailTxtBox";
            this.emailTxtBox.PasswordChar = '\0';
            this.emailTxtBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.emailTxtBox.SelectedText = "";
            this.emailTxtBox.SelectionLength = 0;
            this.emailTxtBox.SelectionStart = 0;
            this.emailTxtBox.ShortcutsEnabled = true;
            this.emailTxtBox.Size = new System.Drawing.Size(180, 20);
            this.emailTxtBox.TabIndex = 11;
            this.emailTxtBox.UseSelectable = true;
            this.emailTxtBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.emailTxtBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // sAddTxtBox
            // 
            this.sAddTxtBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            // 
            // 
            // 
            this.sAddTxtBox.CustomButton.Image = null;
            this.sAddTxtBox.CustomButton.Location = new System.Drawing.Point(152, 2);
            this.sAddTxtBox.CustomButton.Name = "";
            this.sAddTxtBox.CustomButton.Size = new System.Drawing.Size(25, 25);
            this.sAddTxtBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.sAddTxtBox.CustomButton.TabIndex = 1;
            this.sAddTxtBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.sAddTxtBox.CustomButton.UseSelectable = true;
            this.sAddTxtBox.CustomButton.Visible = false;
            this.sAddTxtBox.Lines = new string[0];
            this.sAddTxtBox.Location = new System.Drawing.Point(168, 128);
            this.sAddTxtBox.MaxLength = 32767;
            this.sAddTxtBox.Name = "sAddTxtBox";
            this.sAddTxtBox.PasswordChar = '\0';
            this.sAddTxtBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.sAddTxtBox.SelectedText = "";
            this.sAddTxtBox.SelectionLength = 0;
            this.sAddTxtBox.SelectionStart = 0;
            this.sAddTxtBox.ShortcutsEnabled = true;
            this.sAddTxtBox.Size = new System.Drawing.Size(180, 30);
            this.sAddTxtBox.TabIndex = 60;
            this.sAddTxtBox.UseSelectable = true;
            this.sAddTxtBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.sAddTxtBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // htmlLabel6
            // 
            this.htmlLabel6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.htmlLabel6.AutoScroll = true;
            this.htmlLabel6.AutoScrollMinSize = new System.Drawing.Size(69, 23);
            this.htmlLabel6.AutoSize = false;
            this.htmlLabel6.BackColor = System.Drawing.SystemColors.Window;
            this.htmlLabel6.Controls.Add(this.desgCmbBox);
            this.htmlLabel6.Location = new System.Drawing.Point(7, 320);
            this.htmlLabel6.Name = "htmlLabel6";
            this.htmlLabel6.Size = new System.Drawing.Size(341, 39);
            this.htmlLabel6.TabIndex = 52;
            this.htmlLabel6.Text = "Designation";
            // 
            // desgCmbBox
            // 
            this.desgCmbBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.desgCmbBox.FormattingEnabled = true;
            this.desgCmbBox.ItemHeight = 23;
            this.desgCmbBox.Location = new System.Drawing.Point(161, 1);
            this.desgCmbBox.Name = "desgCmbBox";
            this.desgCmbBox.Size = new System.Drawing.Size(180, 29);
            this.desgCmbBox.TabIndex = 0;
            this.desgCmbBox.UseSelectable = true;
            this.desgCmbBox.SelectedIndexChanged += new System.EventHandler(this.desgCmbBox_SelectedIndexChanged);
            // 
            // htmlLabel9
            // 
            this.htmlLabel9.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.htmlLabel9.AutoScroll = true;
            this.htmlLabel9.AutoScrollMinSize = new System.Drawing.Size(107, 23);
            this.htmlLabel9.AutoSize = false;
            this.htmlLabel9.BackColor = System.Drawing.SystemColors.Window;
            this.htmlLabel9.Location = new System.Drawing.Point(7, 128);
            this.htmlLabel9.Name = "htmlLabel9";
            this.htmlLabel9.Size = new System.Drawing.Size(341, 30);
            this.htmlLabel9.TabIndex = 59;
            this.htmlLabel9.Text = "Secondary Address";
            // 
            // htmlLabel8
            // 
            this.htmlLabel8.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.htmlLabel8.AutoScroll = true;
            this.htmlLabel8.AutoScrollMinSize = new System.Drawing.Size(10, 0);
            this.htmlLabel8.AutoSize = false;
            this.htmlLabel8.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.htmlLabel8.Controls.Add(this.metroLink2);
            this.htmlLabel8.Location = new System.Drawing.Point(441, 25);
            this.htmlLabel8.Name = "htmlLabel8";
            this.htmlLabel8.Size = new System.Drawing.Size(250, 250);
            this.htmlLabel8.TabIndex = 55;
            // 
            // metroLink2
            // 
            this.metroLink2.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.metroLink2.BackColor = System.Drawing.Color.White;
            this.metroLink2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroLink2.BackgroundImage")));
            this.metroLink2.Location = new System.Drawing.Point(13, 13);
            this.metroLink2.Name = "metroLink2";
            this.metroLink2.Size = new System.Drawing.Size(225, 225);
            this.metroLink2.TabIndex = 15;
            this.metroLink2.UseSelectable = true;
            // 
            // pAddTxtBox
            // 
            this.pAddTxtBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            // 
            // 
            // 
            this.pAddTxtBox.CustomButton.Image = null;
            this.pAddTxtBox.CustomButton.Location = new System.Drawing.Point(152, 2);
            this.pAddTxtBox.CustomButton.Name = "";
            this.pAddTxtBox.CustomButton.Size = new System.Drawing.Size(25, 25);
            this.pAddTxtBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.pAddTxtBox.CustomButton.TabIndex = 1;
            this.pAddTxtBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.pAddTxtBox.CustomButton.UseSelectable = true;
            this.pAddTxtBox.CustomButton.Visible = false;
            this.pAddTxtBox.Lines = new string[0];
            this.pAddTxtBox.Location = new System.Drawing.Point(168, 91);
            this.pAddTxtBox.MaxLength = 32767;
            this.pAddTxtBox.Name = "pAddTxtBox";
            this.pAddTxtBox.PasswordChar = '\0';
            this.pAddTxtBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.pAddTxtBox.SelectedText = "";
            this.pAddTxtBox.SelectionLength = 0;
            this.pAddTxtBox.SelectionStart = 0;
            this.pAddTxtBox.ShortcutsEnabled = true;
            this.pAddTxtBox.Size = new System.Drawing.Size(180, 30);
            this.pAddTxtBox.TabIndex = 49;
            this.pAddTxtBox.UseSelectable = true;
            this.pAddTxtBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.pAddTxtBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // staffAddBtn
            // 
            this.staffAddBtn.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.staffAddBtn.Location = new System.Drawing.Point(441, 323);
            this.staffAddBtn.Name = "staffAddBtn";
            this.staffAddBtn.Size = new System.Drawing.Size(106, 42);
            this.staffAddBtn.TabIndex = 56;
            this.staffAddBtn.Text = "Add";
            this.staffAddBtn.UseSelectable = true;
            this.staffAddBtn.Click += new System.EventHandler(this.staffAddBtn_Click);
            // 
            // addNICtxtBox
            // 
            this.addNICtxtBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            // 
            // 
            // 
            this.addNICtxtBox.CustomButton.Image = null;
            this.addNICtxtBox.CustomButton.Location = new System.Drawing.Point(162, 2);
            this.addNICtxtBox.CustomButton.Name = "";
            this.addNICtxtBox.CustomButton.Size = new System.Drawing.Size(15, 15);
            this.addNICtxtBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.addNICtxtBox.CustomButton.TabIndex = 1;
            this.addNICtxtBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.addNICtxtBox.CustomButton.UseSelectable = true;
            this.addNICtxtBox.CustomButton.Visible = false;
            this.addNICtxtBox.Lines = new string[0];
            this.addNICtxtBox.Location = new System.Drawing.Point(168, 63);
            this.addNICtxtBox.MaxLength = 32767;
            this.addNICtxtBox.Name = "addNICtxtBox";
            this.addNICtxtBox.PasswordChar = '\0';
            this.addNICtxtBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.addNICtxtBox.SelectedText = "";
            this.addNICtxtBox.SelectionLength = 0;
            this.addNICtxtBox.SelectionStart = 0;
            this.addNICtxtBox.ShortcutsEnabled = true;
            this.addNICtxtBox.Size = new System.Drawing.Size(180, 20);
            this.addNICtxtBox.TabIndex = 46;
            this.addNICtxtBox.UseSelectable = true;
            this.addNICtxtBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.addNICtxtBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.addNICtxtBox.Click += new System.EventHandler(this.addNICtxtBox_Click);
            this.addNICtxtBox.Validating += new System.ComponentModel.CancelEventHandler(this.addNICtxtBox_Validating);
            this.addNICtxtBox.Validated += new System.EventHandler(this.addNICtxtBox_Validated);
            // 
            // htmlLabel1
            // 
            this.htmlLabel1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.htmlLabel1.AutoScroll = true;
            this.htmlLabel1.AutoScrollMinSize = new System.Drawing.Size(61, 23);
            this.htmlLabel1.AutoSize = false;
            this.htmlLabel1.BackColor = System.Drawing.SystemColors.Window;
            this.htmlLabel1.Location = new System.Drawing.Point(7, 35);
            this.htmlLabel1.Name = "htmlLabel1";
            this.htmlLabel1.Size = new System.Drawing.Size(341, 30);
            this.htmlLabel1.TabIndex = 44;
            this.htmlLabel1.Text = "Last name";
            // 
            // staffClearBtn
            // 
            this.staffClearBtn.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.staffClearBtn.Location = new System.Drawing.Point(585, 323);
            this.staffClearBtn.Name = "staffClearBtn";
            this.staffClearBtn.Size = new System.Drawing.Size(106, 42);
            this.staffClearBtn.TabIndex = 58;
            this.staffClearBtn.Text = "Clear";
            this.staffClearBtn.UseSelectable = true;
            this.staffClearBtn.Click += new System.EventHandler(this.staffClearBtn_Click);
            // 
            // htmlLabel3
            // 
            this.htmlLabel3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.htmlLabel3.AutoScroll = true;
            this.htmlLabel3.AutoScrollMinSize = new System.Drawing.Size(93, 23);
            this.htmlLabel3.AutoSize = false;
            this.htmlLabel3.BackColor = System.Drawing.SystemColors.Window;
            this.htmlLabel3.Location = new System.Drawing.Point(7, 91);
            this.htmlLabel3.Name = "htmlLabel3";
            this.htmlLabel3.Size = new System.Drawing.Size(341, 30);
            this.htmlLabel3.TabIndex = 48;
            this.htmlLabel3.Text = "Primary Address";
            // 
            // htmlLabel13
            // 
            this.htmlLabel13.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.htmlLabel13.AutoScroll = true;
            this.htmlLabel13.AutoScrollMinSize = new System.Drawing.Size(29, 23);
            this.htmlLabel13.AutoSize = false;
            this.htmlLabel13.BackColor = System.Drawing.SystemColors.Window;
            this.htmlLabel13.Location = new System.Drawing.Point(7, 63);
            this.htmlLabel13.Name = "htmlLabel13";
            this.htmlLabel13.Size = new System.Drawing.Size(341, 30);
            this.htmlLabel13.TabIndex = 45;
            this.htmlLabel13.Text = "NIC";
            // 
            // AddDesignationTab
            // 
            this.AddDesignationTab.Controls.Add(this.htmlLabel16);
            this.AddDesignationTab.HorizontalScrollbarBarColor = true;
            this.AddDesignationTab.HorizontalScrollbarHighlightOnWheel = false;
            this.AddDesignationTab.HorizontalScrollbarSize = 10;
            this.AddDesignationTab.Location = new System.Drawing.Point(4, 38);
            this.AddDesignationTab.Name = "AddDesignationTab";
            this.AddDesignationTab.Size = new System.Drawing.Size(763, 411);
            this.AddDesignationTab.TabIndex = 1;
            this.AddDesignationTab.Text = "Add New Designation";
            this.AddDesignationTab.VerticalScrollbarBarColor = true;
            this.AddDesignationTab.VerticalScrollbarHighlightOnWheel = false;
            this.AddDesignationTab.VerticalScrollbarSize = 10;
            // 
            // htmlLabel16
            // 
            this.htmlLabel16.AutoScroll = true;
            this.htmlLabel16.AutoScrollMinSize = new System.Drawing.Size(10, 0);
            this.htmlLabel16.AutoSize = false;
            this.htmlLabel16.BackColor = System.Drawing.Color.LightSkyBlue;
            this.htmlLabel16.Controls.Add(this.clearNewDesBtn);
            this.htmlLabel16.Controls.Add(this.addNewDesBtn);
            this.htmlLabel16.Controls.Add(this.htmlLabel14);
            this.htmlLabel16.Location = new System.Drawing.Point(142, 104);
            this.htmlLabel16.Name = "htmlLabel16";
            this.htmlLabel16.Size = new System.Drawing.Size(451, 213);
            this.htmlLabel16.TabIndex = 2;
            this.htmlLabel16.Click += new System.EventHandler(this.htmlLabel16_Click);
            // 
            // clearNewDesBtn
            // 
            this.clearNewDesBtn.Location = new System.Drawing.Point(252, 140);
            this.clearNewDesBtn.Name = "clearNewDesBtn";
            this.clearNewDesBtn.Size = new System.Drawing.Size(104, 33);
            this.clearNewDesBtn.TabIndex = 4;
            this.clearNewDesBtn.Text = "Clear";
            this.clearNewDesBtn.UseSelectable = true;
            this.clearNewDesBtn.Click += new System.EventHandler(this.clearNewDesBtn_Click);
            // 
            // addNewDesBtn
            // 
            this.addNewDesBtn.Location = new System.Drawing.Point(99, 140);
            this.addNewDesBtn.Name = "addNewDesBtn";
            this.addNewDesBtn.Size = new System.Drawing.Size(104, 33);
            this.addNewDesBtn.TabIndex = 3;
            this.addNewDesBtn.Text = "Add";
            this.addNewDesBtn.UseSelectable = true;
            this.addNewDesBtn.Click += new System.EventHandler(this.addNewDesBtn_Click);
            // 
            // htmlLabel14
            // 
            this.htmlLabel14.AutoScroll = true;
            this.htmlLabel14.AutoScrollMinSize = new System.Drawing.Size(39, 23);
            this.htmlLabel14.AutoSize = false;
            this.htmlLabel14.BackColor = System.Drawing.Color.LightSkyBlue;
            this.htmlLabel14.Controls.Add(this.addNewDesTxtBox);
            this.htmlLabel14.Location = new System.Drawing.Point(78, 66);
            this.htmlLabel14.Name = "htmlLabel14";
            this.htmlLabel14.Size = new System.Drawing.Size(291, 47);
            this.htmlLabel14.TabIndex = 2;
            this.htmlLabel14.Text = "Name";
            // 
            // addNewDesTxtBox
            // 
            // 
            // 
            // 
            this.addNewDesTxtBox.CustomButton.Image = null;
            this.addNewDesTxtBox.CustomButton.Location = new System.Drawing.Point(187, 2);
            this.addNewDesTxtBox.CustomButton.Name = "";
            this.addNewDesTxtBox.CustomButton.Size = new System.Drawing.Size(31, 31);
            this.addNewDesTxtBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.addNewDesTxtBox.CustomButton.TabIndex = 1;
            this.addNewDesTxtBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.addNewDesTxtBox.CustomButton.UseSelectable = true;
            this.addNewDesTxtBox.CustomButton.Visible = false;
            this.addNewDesTxtBox.Lines = new string[0];
            this.addNewDesTxtBox.Location = new System.Drawing.Point(61, 0);
            this.addNewDesTxtBox.MaxLength = 32767;
            this.addNewDesTxtBox.Name = "addNewDesTxtBox";
            this.addNewDesTxtBox.PasswordChar = '\0';
            this.addNewDesTxtBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.addNewDesTxtBox.SelectedText = "";
            this.addNewDesTxtBox.SelectionLength = 0;
            this.addNewDesTxtBox.SelectionStart = 0;
            this.addNewDesTxtBox.ShortcutsEnabled = true;
            this.addNewDesTxtBox.Size = new System.Drawing.Size(221, 36);
            this.addNewDesTxtBox.TabIndex = 4;
            this.addNewDesTxtBox.UseSelectable = true;
            this.addNewDesTxtBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.addNewDesTxtBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.addNewDesTxtBox.Click += new System.EventHandler(this.addNewDesTxtBox_Click);
            // 
            // errorProviderAddStaff
            // 
            this.errorProviderAddStaff.ContainerControl = this;
            // 
            // homeBtn
            // 
            this.homeBtn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.homeBtn.BackColor = System.Drawing.Color.Transparent;
            this.homeBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("homeBtn.BackgroundImage")));
            this.homeBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.homeBtn.Location = new System.Drawing.Point(392, 8);
            this.homeBtn.Margin = new System.Windows.Forms.Padding(2);
            this.homeBtn.Name = "homeBtn";
            this.homeBtn.Size = new System.Drawing.Size(30, 24);
            this.homeBtn.TabIndex = 16;
            this.homeBtn.UseSelectable = true;
            this.homeBtn.Click += new System.EventHandler(this.homeBtn_Click);
            // 
            // demo_stf_btn
            // 
            this.demo_stf_btn.Location = new System.Drawing.Point(519, 283);
            this.demo_stf_btn.Name = "demo_stf_btn";
            this.demo_stf_btn.Size = new System.Drawing.Size(92, 28);
            this.demo_stf_btn.TabIndex = 63;
            this.demo_stf_btn.Text = "Demo";
            this.demo_stf_btn.UseSelectable = true;
            this.demo_stf_btn.Click += new System.EventHandler(this.demo_stf_btn_Click);
            // profilebtn
            // 
            this.profilebtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.profilebtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.profilebtn.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.profilebtn.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.profilebtn.Location = new System.Drawing.Point(673, 15);
            this.profilebtn.Name = "profilebtn";
            this.profilebtn.Size = new System.Drawing.Size(105, 29);
            this.profilebtn.TabIndex = 17;
            this.profilebtn.UseCustomBackColor = true;
            this.profilebtn.UseSelectable = true;
            this.profilebtn.Click += new System.EventHandler(this.profilebtn_Click);
            // 
            // StaffForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(815, 538);
            this.Controls.Add(this.profilebtn);
            this.Controls.Add(this.homeBtn);
            this.Controls.Add(this.metroTabControl1);
            this.Name = "StaffForm";
            this.Text = "Add Member";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.metroTabControl1.ResumeLayout(false);
            this.AddMemberTab.ResumeLayout(false);
            this.htmlLabel2.ResumeLayout(false);
            this.htmlLabel12.ResumeLayout(false);
            this.htmlLabel11.ResumeLayout(false);
            this.htmlLabel5.ResumeLayout(false);
            this.htmlLabel4.ResumeLayout(false);
            this.htmlLabel10.ResumeLayout(false);
            this.htmlLabel7.ResumeLayout(false);
            this.htmlLabel6.ResumeLayout(false);
            this.htmlLabel8.ResumeLayout(false);
            this.AddDesignationTab.ResumeLayout(false);
            this.htmlLabel16.ResumeLayout(false);
            this.htmlLabel14.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderAddStaff)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroTabControl metroTabControl1;
        private MetroFramework.Controls.MetroTabPage AddMemberTab;
        private MetroFramework.Controls.MetroTabPage AddDesignationTab;
        private MetroFramework.Drawing.Html.HtmlLabel htmlLabel12;
        private MetroFramework.Controls.MetroTextBox basicSalTxtBox;
        private MetroFramework.Drawing.Html.HtmlLabel htmlLabel11;
        private MetroFramework.Controls.MetroTextBox otRateTxtBox;
        private MetroFramework.Drawing.Html.HtmlLabel htmlLabel5;
        private MetroFramework.Controls.MetroTextBox linkedTxtBox;
        private MetroFramework.Controls.MetroTextBox lNameTxtBox;
        private MetroFramework.Drawing.Html.HtmlLabel htmlLabel4;
        private MetroFramework.Controls.MetroTextBox fbTxtBox;
        private MetroFramework.Drawing.Html.HtmlLabel htmlLabel2;
        private MetroFramework.Controls.MetroTextBox telMobileTxtBox;
        private MetroFramework.Controls.MetroTextBox fNameTxtBox;
        private MetroFramework.Drawing.Html.HtmlLabel htmlLabel10;
        private MetroFramework.Controls.MetroTextBox telLanTxtBox;
        private MetroFramework.Drawing.Html.HtmlLabel htmlLabel7;
        private MetroFramework.Controls.MetroTextBox emailTxtBox;
        private MetroFramework.Controls.MetroTextBox sAddTxtBox;
        private MetroFramework.Drawing.Html.HtmlLabel htmlLabel6;
        private MetroFramework.Controls.MetroComboBox desgCmbBox;
        private MetroFramework.Drawing.Html.HtmlLabel htmlLabel9;
        private MetroFramework.Drawing.Html.HtmlLabel htmlLabel8;
        private MetroFramework.Controls.MetroLink metroLink2;
        private MetroFramework.Controls.MetroTextBox pAddTxtBox;
        private MetroFramework.Controls.MetroButton staffAddBtn;
        private MetroFramework.Controls.MetroTextBox addNICtxtBox;
        private MetroFramework.Drawing.Html.HtmlLabel htmlLabel1;
        private MetroFramework.Controls.MetroButton staffClearBtn;
        private MetroFramework.Drawing.Html.HtmlLabel htmlLabel3;
        private MetroFramework.Drawing.Html.HtmlLabel htmlLabel13;
        private MetroFramework.Controls.MetroTextBox addNewDesTxtBox;
        private MetroFramework.Drawing.Html.HtmlLabel htmlLabel16;
        private MetroFramework.Controls.MetroButton clearNewDesBtn;
        private MetroFramework.Controls.MetroButton addNewDesBtn;
        private MetroFramework.Drawing.Html.HtmlLabel htmlLabel14;
        private System.Windows.Forms.ErrorProvider errorProviderAddStaff;
        private MetroFramework.Controls.MetroButton homeBtn;
        private MetroFramework.Controls.MetroButton demo_stf_btn;
        private MetroFramework.Controls.MetroButton profilebtn;
    }
}