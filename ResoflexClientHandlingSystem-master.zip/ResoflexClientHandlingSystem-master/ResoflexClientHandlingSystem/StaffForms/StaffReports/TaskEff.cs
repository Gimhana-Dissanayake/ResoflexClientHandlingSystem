﻿namespace ResoflexClientHandlingSystem.StaffForms.StaffReports
{
}

namespace ResoflexClientHandlingSystem.StaffForms.StaffReports
{


    public partial class TaskEff
    {
    }
}
namespace ResoflexClientHandlingSystem.StaffForms.StaffReports {
    
    
    public partial class TaskEff {
    }
}
