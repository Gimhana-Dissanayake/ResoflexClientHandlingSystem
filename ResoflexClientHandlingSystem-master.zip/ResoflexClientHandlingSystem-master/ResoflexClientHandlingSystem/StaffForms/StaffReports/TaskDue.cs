﻿namespace ResoflexClientHandlingSystem.StaffForms.StaffReports
{


    partial class TaskDue
    {
        partial class TaskDataTable
        {
        }
    }
}
