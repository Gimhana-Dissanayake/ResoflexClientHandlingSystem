﻿namespace ResoflexClientHandlingSystem
{
    partial class resourceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(resourceForm));
            this.nameResTxtBox = new MetroFramework.Controls.MetroTextBox();
            this.htmlLabel2 = new MetroFramework.Drawing.Html.HtmlLabel();
            this.htmlLabel1 = new MetroFramework.Drawing.Html.HtmlLabel();
            this.valueResTxtBox = new MetroFramework.Controls.MetroTextBox();
            this.htmlLabel3 = new MetroFramework.Drawing.Html.HtmlLabel();
            this.qtyResTxtBox = new MetroFramework.Controls.MetroTextBox();
            this.resClearBtn = new MetroFramework.Controls.MetroButton();
            this.resAddBtn = new MetroFramework.Controls.MetroButton();
            this.ResGrid = new MetroFramework.Controls.MetroGrid();
            this.UpdateResBtn = new MetroFramework.Controls.MetroButton();
            this.DelResBtn = new MetroFramework.Controls.MetroButton();
            this.homeBtn = new MetroFramework.Controls.MetroButton();
            this.selectResourceTxtbox = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.demo_res_btn = new MetroFramework.Controls.MetroButton();
            this.profilebtn = new MetroFramework.Controls.MetroButton();
            ((System.ComponentModel.ISupportInitialize)(this.ResGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // nameResTxtBox
            // 
            // 
            // 
            // 
            this.nameResTxtBox.CustomButton.Image = null;
            this.nameResTxtBox.CustomButton.Location = new System.Drawing.Point(162, 2);
            this.nameResTxtBox.CustomButton.Name = "";
            this.nameResTxtBox.CustomButton.Size = new System.Drawing.Size(15, 15);
            this.nameResTxtBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.nameResTxtBox.CustomButton.TabIndex = 1;
            this.nameResTxtBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.nameResTxtBox.CustomButton.UseSelectable = true;
            this.nameResTxtBox.CustomButton.Visible = false;
            this.nameResTxtBox.Lines = new string[0];
            this.nameResTxtBox.Location = new System.Drawing.Point(115, 103);
            this.nameResTxtBox.MaxLength = 32767;
            this.nameResTxtBox.Name = "nameResTxtBox";
            this.nameResTxtBox.PasswordChar = '\0';
            this.nameResTxtBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.nameResTxtBox.SelectedText = "";
            this.nameResTxtBox.SelectionLength = 0;
            this.nameResTxtBox.SelectionStart = 0;
            this.nameResTxtBox.ShortcutsEnabled = true;
            this.nameResTxtBox.Size = new System.Drawing.Size(180, 20);
            this.nameResTxtBox.TabIndex = 5;
            this.nameResTxtBox.UseSelectable = true;
            this.nameResTxtBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.nameResTxtBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // htmlLabel2
            // 
            this.htmlLabel2.AutoScroll = true;
            this.htmlLabel2.AutoScrollMinSize = new System.Drawing.Size(39, 23);
            this.htmlLabel2.AutoSize = false;
            this.htmlLabel2.BackColor = System.Drawing.SystemColors.Window;
            this.htmlLabel2.Location = new System.Drawing.Point(23, 103);
            this.htmlLabel2.Name = "htmlLabel2";
            this.htmlLabel2.Size = new System.Drawing.Size(304, 29);
            this.htmlLabel2.TabIndex = 4;
            this.htmlLabel2.Text = "Name";
            // 
            // htmlLabel1
            // 
            this.htmlLabel1.AutoScroll = true;
            this.htmlLabel1.AutoScrollMinSize = new System.Drawing.Size(38, 23);
            this.htmlLabel1.AutoSize = false;
            this.htmlLabel1.BackColor = System.Drawing.SystemColors.Window;
            this.htmlLabel1.Location = new System.Drawing.Point(23, 138);
            this.htmlLabel1.Name = "htmlLabel1";
            this.htmlLabel1.Size = new System.Drawing.Size(304, 29);
            this.htmlLabel1.TabIndex = 4;
            this.htmlLabel1.Text = "Value";
            // 
            // valueResTxtBox
            // 
            // 
            // 
            // 
            this.valueResTxtBox.CustomButton.Image = null;
            this.valueResTxtBox.CustomButton.Location = new System.Drawing.Point(162, 2);
            this.valueResTxtBox.CustomButton.Name = "";
            this.valueResTxtBox.CustomButton.Size = new System.Drawing.Size(15, 15);
            this.valueResTxtBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.valueResTxtBox.CustomButton.TabIndex = 1;
            this.valueResTxtBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.valueResTxtBox.CustomButton.UseSelectable = true;
            this.valueResTxtBox.CustomButton.Visible = false;
            this.valueResTxtBox.Lines = new string[0];
            this.valueResTxtBox.Location = new System.Drawing.Point(115, 138);
            this.valueResTxtBox.MaxLength = 32767;
            this.valueResTxtBox.Name = "valueResTxtBox";
            this.valueResTxtBox.PasswordChar = '\0';
            this.valueResTxtBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.valueResTxtBox.SelectedText = "";
            this.valueResTxtBox.SelectionLength = 0;
            this.valueResTxtBox.SelectionStart = 0;
            this.valueResTxtBox.ShortcutsEnabled = true;
            this.valueResTxtBox.Size = new System.Drawing.Size(180, 20);
            this.valueResTxtBox.TabIndex = 5;
            this.valueResTxtBox.UseSelectable = true;
            this.valueResTxtBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.valueResTxtBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // htmlLabel3
            // 
            this.htmlLabel3.AutoScroll = true;
            this.htmlLabel3.AutoScrollMinSize = new System.Drawing.Size(52, 23);
            this.htmlLabel3.AutoSize = false;
            this.htmlLabel3.BackColor = System.Drawing.SystemColors.Window;
            this.htmlLabel3.Location = new System.Drawing.Point(23, 173);
            this.htmlLabel3.Name = "htmlLabel3";
            this.htmlLabel3.Size = new System.Drawing.Size(304, 29);
            this.htmlLabel3.TabIndex = 4;
            this.htmlLabel3.Text = "Quantity";
            // 
            // qtyResTxtBox
            // 
            // 
            // 
            // 
            this.qtyResTxtBox.CustomButton.Image = null;
            this.qtyResTxtBox.CustomButton.Location = new System.Drawing.Point(162, 2);
            this.qtyResTxtBox.CustomButton.Name = "";
            this.qtyResTxtBox.CustomButton.Size = new System.Drawing.Size(15, 15);
            this.qtyResTxtBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.qtyResTxtBox.CustomButton.TabIndex = 1;
            this.qtyResTxtBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.qtyResTxtBox.CustomButton.UseSelectable = true;
            this.qtyResTxtBox.CustomButton.Visible = false;
            this.qtyResTxtBox.Lines = new string[0];
            this.qtyResTxtBox.Location = new System.Drawing.Point(115, 173);
            this.qtyResTxtBox.MaxLength = 32767;
            this.qtyResTxtBox.Name = "qtyResTxtBox";
            this.qtyResTxtBox.PasswordChar = '\0';
            this.qtyResTxtBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.qtyResTxtBox.SelectedText = "";
            this.qtyResTxtBox.SelectionLength = 0;
            this.qtyResTxtBox.SelectionStart = 0;
            this.qtyResTxtBox.ShortcutsEnabled = true;
            this.qtyResTxtBox.Size = new System.Drawing.Size(180, 20);
            this.qtyResTxtBox.TabIndex = 5;
            this.qtyResTxtBox.UseSelectable = true;
            this.qtyResTxtBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.qtyResTxtBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // resClearBtn
            // 
            this.resClearBtn.Location = new System.Drawing.Point(193, 263);
            this.resClearBtn.Name = "resClearBtn";
            this.resClearBtn.Size = new System.Drawing.Size(110, 36);
            this.resClearBtn.TabIndex = 17;
            this.resClearBtn.Text = "Clear";
            this.resClearBtn.UseSelectable = true;
            this.resClearBtn.Click += new System.EventHandler(this.resClearBtn_Click);
            // 
            // resAddBtn
            // 
            this.resAddBtn.Location = new System.Drawing.Point(52, 263);
            this.resAddBtn.Name = "resAddBtn";
            this.resAddBtn.Size = new System.Drawing.Size(110, 36);
            this.resAddBtn.TabIndex = 17;
            this.resAddBtn.Text = "Add";
            this.resAddBtn.UseSelectable = true;
            this.resAddBtn.Click += new System.EventHandler(this.resAddBtn_Click);
            // 
            // ResGrid
            // 
            this.ResGrid.AllowUserToResizeRows = false;
            this.ResGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ResGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.ResGrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ResGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ResGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.ResGrid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ResGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.ResGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ResGrid.DefaultCellStyle = dataGridViewCellStyle2;
            this.ResGrid.EnableHeadersVisualStyles = false;
            this.ResGrid.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ResGrid.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ResGrid.Location = new System.Drawing.Point(333, 104);
            this.ResGrid.Name = "ResGrid";
            this.ResGrid.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ResGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.ResGrid.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.ResGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ResGrid.Size = new System.Drawing.Size(530, 445);
            this.ResGrid.TabIndex = 18;
            this.ResGrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.metroGrid1_CellContentClick);
            // 
            // UpdateResBtn
            // 
            this.UpdateResBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.UpdateResBtn.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.UpdateResBtn.Location = new System.Drawing.Point(754, 66);
            this.UpdateResBtn.Name = "UpdateResBtn";
            this.UpdateResBtn.Size = new System.Drawing.Size(108, 26);
            this.UpdateResBtn.TabIndex = 19;
            this.UpdateResBtn.Text = "Update";
            this.UpdateResBtn.UseSelectable = true;
            this.UpdateResBtn.Click += new System.EventHandler(this.Update_Click);
            // 
            // DelResBtn
            // 
            this.DelResBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.DelResBtn.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.DelResBtn.Location = new System.Drawing.Point(640, 66);
            this.DelResBtn.Name = "DelResBtn";
            this.DelResBtn.Size = new System.Drawing.Size(108, 26);
            this.DelResBtn.TabIndex = 20;
            this.DelResBtn.Text = "Delete";
            this.DelResBtn.UseSelectable = true;
            this.DelResBtn.Click += new System.EventHandler(this.DelResBtn_Click);
            // 
            // homeBtn
            // 
            this.homeBtn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.homeBtn.BackColor = System.Drawing.Color.Transparent;
            this.homeBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("homeBtn.BackgroundImage")));
            this.homeBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.homeBtn.Location = new System.Drawing.Point(428, 7);
            this.homeBtn.Margin = new System.Windows.Forms.Padding(2);
            this.homeBtn.Name = "homeBtn";
            this.homeBtn.Size = new System.Drawing.Size(30, 24);
            this.homeBtn.TabIndex = 21;
            this.homeBtn.UseSelectable = true;
            this.homeBtn.Click += new System.EventHandler(this.homeBtn_Click);
            // 
            // selectResourceTxtbox
            // 
            // 
            // 
            // 
            this.selectResourceTxtbox.CustomButton.Image = null;
            this.selectResourceTxtbox.CustomButton.Location = new System.Drawing.Point(224, 1);
            this.selectResourceTxtbox.CustomButton.Name = "";
            this.selectResourceTxtbox.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.selectResourceTxtbox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.selectResourceTxtbox.CustomButton.TabIndex = 1;
            this.selectResourceTxtbox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.selectResourceTxtbox.CustomButton.UseSelectable = true;
            this.selectResourceTxtbox.CustomButton.Visible = false;
            this.selectResourceTxtbox.Lines = new string[0];
            this.selectResourceTxtbox.Location = new System.Drawing.Point(388, 69);
            this.selectResourceTxtbox.MaxLength = 32767;
            this.selectResourceTxtbox.Name = "selectResourceTxtbox";
            this.selectResourceTxtbox.PasswordChar = '\0';
            this.selectResourceTxtbox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.selectResourceTxtbox.SelectedText = "";
            this.selectResourceTxtbox.SelectionLength = 0;
            this.selectResourceTxtbox.SelectionStart = 0;
            this.selectResourceTxtbox.ShortcutsEnabled = true;
            this.selectResourceTxtbox.Size = new System.Drawing.Size(246, 23);
            this.selectResourceTxtbox.TabIndex = 26;
            this.selectResourceTxtbox.UseSelectable = true;
            this.selectResourceTxtbox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.selectResourceTxtbox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.selectResourceTxtbox.TextChanged += new System.EventHandler(this.selectResourceTxtbox_TextChanged);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(334, 73);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(48, 19);
            this.metroLabel2.TabIndex = 25;
            this.metroLabel2.Text = "Search";
            // 
            // demo_res_btn
            // 
            this.demo_res_btn.Location = new System.Drawing.Point(128, 357);
            this.demo_res_btn.Name = "demo_res_btn";
            this.demo_res_btn.Size = new System.Drawing.Size(96, 29);
            this.demo_res_btn.TabIndex = 27;
            this.demo_res_btn.Text = "Demo";
            this.demo_res_btn.UseSelectable = true;
            this.demo_res_btn.Click += new System.EventHandler(this.demo_res_btn_Click);
            //
            // profilebtn
            // 
            this.profilebtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.profilebtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.profilebtn.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.profilebtn.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.profilebtn.Location = new System.Drawing.Point(668, 22);
            this.profilebtn.Name = "profilebtn";
            this.profilebtn.Size = new System.Drawing.Size(105, 29);
            this.profilebtn.TabIndex = 27;
            this.profilebtn.UseCustomBackColor = true;
            this.profilebtn.UseSelectable = true;
            this.profilebtn.Click += new System.EventHandler(this.profilebtn_Click);
            // 
            // resourceForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(889, 578);
            this.Controls.Add(this.demo_res_btn);
            this.ClientSize = new System.Drawing.Size(800, 454);
            this.Controls.Add(this.profilebtn);
            this.Controls.Add(this.selectResourceTxtbox);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.homeBtn);
            this.Controls.Add(this.DelResBtn);
            this.Controls.Add(this.UpdateResBtn);
            this.Controls.Add(this.ResGrid);
            this.Controls.Add(this.resAddBtn);
            this.Controls.Add(this.resClearBtn);
            this.Controls.Add(this.qtyResTxtBox);
            this.Controls.Add(this.htmlLabel3);
            this.Controls.Add(this.valueResTxtBox);
            this.Controls.Add(this.htmlLabel1);
            this.Controls.Add(this.nameResTxtBox);
            this.Controls.Add(this.htmlLabel2);
            this.Name = "resourceForm";
            this.Load += new System.EventHandler(this.resourceForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ResGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroTextBox nameResTxtBox;
        private MetroFramework.Drawing.Html.HtmlLabel htmlLabel2;
        private MetroFramework.Drawing.Html.HtmlLabel htmlLabel1;
        private MetroFramework.Controls.MetroTextBox valueResTxtBox;
        private MetroFramework.Drawing.Html.HtmlLabel htmlLabel3;
        private MetroFramework.Controls.MetroTextBox qtyResTxtBox;
        private MetroFramework.Controls.MetroButton resClearBtn;
        private MetroFramework.Controls.MetroButton resAddBtn;
        private MetroFramework.Controls.MetroGrid ResGrid;
        private MetroFramework.Controls.MetroButton UpdateResBtn;
        private MetroFramework.Controls.MetroButton DelResBtn;
        private MetroFramework.Controls.MetroButton homeBtn;
        private MetroFramework.Controls.MetroTextBox selectResourceTxtbox;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroButton demo_res_btn;
        private MetroFramework.Controls.MetroButton profilebtn;
    }
}