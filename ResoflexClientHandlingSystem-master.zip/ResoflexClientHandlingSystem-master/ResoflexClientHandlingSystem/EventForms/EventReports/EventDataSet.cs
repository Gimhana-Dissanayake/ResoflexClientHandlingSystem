﻿namespace ResoflexClientHandlingSystem.EventForms.EventReports
{


    public partial class EventDataSet
    {
    }
}
namespace ResoflexClientHandlingSystem.EventForms.EventReports {
    
    
    public partial class EventDataSet {
    }
}
