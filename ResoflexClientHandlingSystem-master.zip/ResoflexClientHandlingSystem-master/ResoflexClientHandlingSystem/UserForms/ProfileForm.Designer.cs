﻿namespace ResoflexClientHandlingSystem.UserForms
{
    partial class ProfileForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProfileForm));
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.txtUname = new MetroFramework.Controls.MetroTextBox();
            this.txtCurPass = new MetroFramework.Controls.MetroTextBox();
            this.txtConPass = new MetroFramework.Controls.MetroTextBox();
            this.metroLink2 = new MetroFramework.Controls.MetroLink();
            this.metroLink3 = new MetroFramework.Controls.MetroLink();
            this.metroLink4 = new MetroFramework.Controls.MetroLink();
            this.metroLink5 = new MetroFramework.Controls.MetroLink();
            this.metroButton2 = new MetroFramework.Controls.MetroButton();
            this.metroLink6 = new MetroFramework.Controls.MetroLink();
            this.txtPass = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.schHome = new MetroFramework.Controls.MetroButton();
            this.SuspendLayout();
            // 
            // metroButton1
            // 
            this.metroButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.metroButton1.Location = new System.Drawing.Point(482, 26);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(75, 23);
            this.metroButton1.TabIndex = 2;
            this.metroButton1.Text = "Log out";
            this.metroButton1.UseSelectable = true;
            this.metroButton1.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // txtUname
            // 
            this.txtUname.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            this.txtUname.CustomButton.Image = null;
            this.txtUname.CustomButton.Location = new System.Drawing.Point(119, 1);
            this.txtUname.CustomButton.Name = "";
            this.txtUname.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtUname.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtUname.CustomButton.TabIndex = 1;
            this.txtUname.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtUname.CustomButton.UseSelectable = true;
            this.txtUname.CustomButton.Visible = false;
            this.txtUname.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.txtUname.Lines = new string[0];
            this.txtUname.Location = new System.Drawing.Point(238, 162);
            this.txtUname.MaxLength = 32767;
            this.txtUname.Name = "txtUname";
            this.txtUname.PasswordChar = '\0';
            this.txtUname.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtUname.SelectedText = "";
            this.txtUname.SelectionLength = 0;
            this.txtUname.SelectionStart = 0;
            this.txtUname.ShortcutsEnabled = true;
            this.txtUname.Size = new System.Drawing.Size(141, 23);
            this.txtUname.TabIndex = 3;
            this.txtUname.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtUname.UseSelectable = true;
            this.txtUname.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtUname.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtUname.Click += new System.EventHandler(this.metroTextBox1_Click);
            // 
            // txtCurPass
            // 
            this.txtCurPass.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            this.txtCurPass.CustomButton.Image = null;
            this.txtCurPass.CustomButton.Location = new System.Drawing.Point(119, 1);
            this.txtCurPass.CustomButton.Name = "";
            this.txtCurPass.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtCurPass.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtCurPass.CustomButton.TabIndex = 1;
            this.txtCurPass.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtCurPass.CustomButton.UseSelectable = true;
            this.txtCurPass.CustomButton.Visible = false;
            this.txtCurPass.Lines = new string[0];
            this.txtCurPass.Location = new System.Drawing.Point(238, 221);
            this.txtCurPass.MaxLength = 32767;
            this.txtCurPass.Name = "txtCurPass";
            this.txtCurPass.PasswordChar = '*';
            this.txtCurPass.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCurPass.SelectedText = "";
            this.txtCurPass.SelectionLength = 0;
            this.txtCurPass.SelectionStart = 0;
            this.txtCurPass.ShortcutsEnabled = true;
            this.txtCurPass.Size = new System.Drawing.Size(141, 23);
            this.txtCurPass.TabIndex = 4;
            this.txtCurPass.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCurPass.UseSelectable = true;
            this.txtCurPass.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtCurPass.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtCurPass.Click += new System.EventHandler(this.metroTextBox2_Click);
            // 
            // txtConPass
            // 
            this.txtConPass.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            this.txtConPass.CustomButton.Image = null;
            this.txtConPass.CustomButton.Location = new System.Drawing.Point(119, 1);
            this.txtConPass.CustomButton.Name = "";
            this.txtConPass.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtConPass.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtConPass.CustomButton.TabIndex = 1;
            this.txtConPass.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtConPass.CustomButton.UseSelectable = true;
            this.txtConPass.CustomButton.Visible = false;
            this.txtConPass.Lines = new string[0];
            this.txtConPass.Location = new System.Drawing.Point(238, 339);
            this.txtConPass.MaxLength = 32767;
            this.txtConPass.Name = "txtConPass";
            this.txtConPass.PasswordChar = '*';
            this.txtConPass.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtConPass.SelectedText = "";
            this.txtConPass.SelectionLength = 0;
            this.txtConPass.SelectionStart = 0;
            this.txtConPass.ShortcutsEnabled = true;
            this.txtConPass.Size = new System.Drawing.Size(141, 23);
            this.txtConPass.TabIndex = 6;
            this.txtConPass.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtConPass.UseSelectable = true;
            this.txtConPass.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtConPass.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLink2
            // 
            this.metroLink2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLink2.FontSize = MetroFramework.MetroLinkSize.Medium;
            this.metroLink2.Location = new System.Drawing.Point(36, 221);
            this.metroLink2.Name = "metroLink2";
            this.metroLink2.Size = new System.Drawing.Size(141, 30);
            this.metroLink2.TabIndex = 8;
            this.metroLink2.Text = "Current Password";
            this.metroLink2.UseSelectable = true;
            // 
            // metroLink3
            // 
            this.metroLink3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLink3.FontSize = MetroFramework.MetroLinkSize.Medium;
            this.metroLink3.Location = new System.Drawing.Point(36, 162);
            this.metroLink3.Name = "metroLink3";
            this.metroLink3.Size = new System.Drawing.Size(141, 30);
            this.metroLink3.TabIndex = 9;
            this.metroLink3.Text = "Username";
            this.metroLink3.UseSelectable = true;
            // 
            // metroLink4
            // 
            this.metroLink4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLink4.FontSize = MetroFramework.MetroLinkSize.Medium;
            this.metroLink4.Location = new System.Drawing.Point(36, 100);
            this.metroLink4.Name = "metroLink4";
            this.metroLink4.Size = new System.Drawing.Size(141, 30);
            this.metroLink4.TabIndex = 10;
            this.metroLink4.Text = "Name";
            this.metroLink4.UseSelectable = true;
            // 
            // metroLink5
            // 
            this.metroLink5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLink5.FontSize = MetroFramework.MetroLinkSize.Medium;
            this.metroLink5.Location = new System.Drawing.Point(36, 339);
            this.metroLink5.Name = "metroLink5";
            this.metroLink5.Size = new System.Drawing.Size(141, 30);
            this.metroLink5.TabIndex = 11;
            this.metroLink5.Text = "Confirm Password";
            this.metroLink5.UseSelectable = true;
            this.metroLink5.Click += new System.EventHandler(this.metroLink5_Click);
            // 
            // metroButton2
            // 
            this.metroButton2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.metroButton2.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.metroButton2.Location = new System.Drawing.Point(185, 393);
            this.metroButton2.Name = "metroButton2";
            this.metroButton2.Size = new System.Drawing.Size(111, 31);
            this.metroButton2.TabIndex = 13;
            this.metroButton2.Text = "Update";
            this.metroButton2.UseSelectable = true;
            this.metroButton2.Click += new System.EventHandler(this.metroButton2_Click);
            // 
            // metroLink6
            // 
            this.metroLink6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLink6.FontSize = MetroFramework.MetroLinkSize.Medium;
            this.metroLink6.Location = new System.Drawing.Point(36, 280);
            this.metroLink6.Name = "metroLink6";
            this.metroLink6.Size = new System.Drawing.Size(141, 30);
            this.metroLink6.TabIndex = 15;
            this.metroLink6.Text = "New Password";
            this.metroLink6.UseSelectable = true;
            // 
            // txtPass
            // 
            this.txtPass.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            this.txtPass.CustomButton.Image = null;
            this.txtPass.CustomButton.Location = new System.Drawing.Point(119, 1);
            this.txtPass.CustomButton.Name = "";
            this.txtPass.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtPass.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtPass.CustomButton.TabIndex = 1;
            this.txtPass.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtPass.CustomButton.UseSelectable = true;
            this.txtPass.CustomButton.Visible = false;
            this.txtPass.Lines = new string[0];
            this.txtPass.Location = new System.Drawing.Point(238, 280);
            this.txtPass.MaxLength = 32767;
            this.txtPass.Name = "txtPass";
            this.txtPass.PasswordChar = '*';
            this.txtPass.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtPass.SelectedText = "";
            this.txtPass.SelectionLength = 0;
            this.txtPass.SelectionStart = 0;
            this.txtPass.ShortcutsEnabled = true;
            this.txtPass.Size = new System.Drawing.Size(141, 23);
            this.txtPass.TabIndex = 14;
            this.txtPass.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtPass.UseSelectable = true;
            this.txtPass.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtPass.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(238, 107);
            this.metroLabel1.MinimumSize = new System.Drawing.Size(140, 23);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(0, 0);
            this.metroLabel1.TabIndex = 16;
            this.metroLabel1.WrapToLine = true;
            // 
            // schHome
            // 
            this.schHome.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.schHome.BackColor = System.Drawing.Color.Transparent;
            this.schHome.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("schHome.BackgroundImage")));
            this.schHome.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.schHome.Location = new System.Drawing.Point(438, 26);
            this.schHome.Margin = new System.Windows.Forms.Padding(2);
            this.schHome.Name = "schHome";
            this.schHome.Size = new System.Drawing.Size(30, 24);
            this.schHome.TabIndex = 17;
            this.schHome.UseSelectable = true;
            this.schHome.Click += new System.EventHandler(this.schHome_Click);
            // 
            // ProfileForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 488);
            this.Controls.Add(this.schHome);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.metroLink6);
            this.Controls.Add(this.txtPass);
            this.Controls.Add(this.metroButton2);
            this.Controls.Add(this.metroLink5);
            this.Controls.Add(this.metroLink4);
            this.Controls.Add(this.metroLink3);
            this.Controls.Add(this.metroLink2);
            this.Controls.Add(this.txtConPass);
            this.Controls.Add(this.txtCurPass);
            this.Controls.Add(this.txtUname);
            this.Controls.Add(this.metroButton1);
            this.MinimumSize = new System.Drawing.Size(600, 488);
            this.Name = "ProfileForm";
            this.Padding = new System.Windows.Forms.Padding(15, 60, 15, 16);
            this.Text = "My Profile";
            this.Load += new System.EventHandler(this.ProfileForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private MetroFramework.Controls.MetroButton metroButton1;
        private MetroFramework.Controls.MetroTextBox txtUname;
        private MetroFramework.Controls.MetroTextBox txtCurPass;
        private MetroFramework.Controls.MetroTextBox txtConPass;
        private MetroFramework.Controls.MetroLink metroLink2;
        private MetroFramework.Controls.MetroLink metroLink3;
        private MetroFramework.Controls.MetroLink metroLink4;
        private MetroFramework.Controls.MetroLink metroLink5;
        private MetroFramework.Controls.MetroButton metroButton2;
        private MetroFramework.Controls.MetroLink metroLink6;
        private MetroFramework.Controls.MetroTextBox txtPass;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroButton schHome;
    }
}